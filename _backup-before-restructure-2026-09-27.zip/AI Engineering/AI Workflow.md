
Idea -> #/Scope -> #/Architect -> #/Develop (Scaffold) -> #/Audit
New feature -> #/Develop -> #/Check-Verify -> #/Test -> #/Check-Review -> #/Document -> #/Sync

#/debug if anything breaks
## Decision one: the build approach

#/scope makes the choice explicit. Four approaches, all long-standing engineering ideas rather than invented workflow settings.

| Approach          | Pick it when                                                                    |
| ----------------- | ------------------------------------------------------------------------------- |
| **Tracer Bullet** | The integration risk is the scary part and you need it proven early             |
| **Skateboard**    | You need real users on it fast, to learn whether it's worth continuing          |
| **Facade**        | It has to be seen and approved before the backend is worth building             |
| **Journey**       | One flow has to feel finished, edge cases included, before anything else starts |

**Tracer Bullet** is the walking skeleton, associated with Alistair Cockburn, and the #tracer_bullet approach from _The #Pragmatic Programmer_. You build one narrow path through the entire system, from the interface through the application to the database. It does very little at first, but it works end to end. Then you thicken it. Another action, another state, another behaviour. Instead of building disconnected layers and hoping they meet, you start with one real path and grow from something already proven.

**Skateboard** is the MVP approach, from Henrik Kniberg's #skateboard to bicycle to car illustration. The smallest version a real person could genuinely use. Not a collection of unfinished systems, and not half of every planned feature. One useful product, kept as small as possible, then expanded.

**Facade** builds the interface with temporary data before committing to the backend underneath. Right when the product needs to be seen, tested, or approved before deeper infrastructure is worth paying for. You explore layout, interaction, and feel while those decisions are still cheap to change.

**Journey** takes one complete user path and finishes every part of it before starting the next. The happy path, the loading state, the empty state, the failures, the edge cases. That journey isn't merely connected. It feels finished.

## Decision two: the workflow tier

The second default is how much proof a feature needs before it's finished.

You wouldn't treat a weekend experiment the way you treat a payment flow. A throwaway script might only need to run once. A login system needs stronger evidence. A compliance feature might need verification, tests, independent review, and documentation before anyone should trust it.

Good teams have always matched process to risk. #/scope turns that into one explicit setting instead of reopening the argument every feature.

Four tiers, and each one adds to the last.

| Tier          | #/develop | #/check-verify | #/test | #/check-review |
| ------------- | --------- | -------------- | ------ | -------------- |
| **Prototype** | ✓         |                |        |                |
| **Alpha**     | ✓         | ✓              |        |                |
| **Beta**      | ✓         | ✓              | ✓      |                |
| **GA**        | ✓         | ✓              | ✓      | ✓              |

**Prototype** is /develop implementing the feature, checking its own work, and marking it complete. Experiments, spikes, personal tools, anything that costs almost nothing if it fails.

**Alpha** adds /check verify. The feature has to run inside the real application, and it's only marked complete once the expected behaviour has actually been demonstrated. For low-risk work that still deserves better evidence than the agent that built it saying "should work."

**Beta** adds /test. A real suite before it closes. This is the right level for most production products: the feature works today, and the tests protect it from tomorrow's changes.

**GA** adds /check review run on a different model from the one that wrote the code, then /document. For work that hurts when it breaks. Payments. Auth. Permissions. Compliance. Anything a team shares.

At GA, the agent that wrote the implementation is not allowed to be the only agent deciding whether that implementation is safe.

## It's a recommendation, not a track

Worth being plain about this, because it's easy to read the above as a system that boxes you in.

#/scope reads your idea, recommends an approach and a tier from the risk and size of the feature mix, and records what you choose. Every box it writes is a suggestion. You can run any of them, skip any of them, and mark a feature done when you decide it's done. The workflow records what you actually did, including what you skipped.

The plan isn't written once and abandoned. As features ship, #/sync reconciles the scope against what's actually in the repo, updating statuses and flagging what the change made stale.