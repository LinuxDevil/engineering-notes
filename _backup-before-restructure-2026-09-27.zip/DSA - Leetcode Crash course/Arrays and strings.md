---
notion-id: 302d91f9-7a99-8077-bc6b-e586429468eb
cover: "[[Arrays and strings.jpeg]]"
---

## Two pointer technique

There’s a couple of ways to implement the two pointers technique

1. Start at the edge of the array, and move until they meet, this will move one pointer from the start and another pointer from the end of the array.
