---
notion-id: 302d91f9-7a99-8090-acc2-f5d770b33af2
cover: "[[DSA - Leetcode Crash course.jpeg]]"
---
## Topics covered

[[Arrays and strings]]

[[Hashmaps and sets]]

[[Linked lists]]

[[Stacks and queues]]

[[Trees and graphs]]

[[Heaps]]

[[Greedy algorithms]]

[[Binary search]]

[[Backtracking]]

[[Dynamic programming]]

