---
notion-id: 23771164-fc60-4ddf-950c-53e907f6c359
base: "[[Inner vs Natural joins.base]]"
INNER JOIN: SYNTAX: SELECT * FROM table1 INNER JOIN table2 ON table1.Column_Name = table2.Column_Name;
SR.NO.: 4
---
