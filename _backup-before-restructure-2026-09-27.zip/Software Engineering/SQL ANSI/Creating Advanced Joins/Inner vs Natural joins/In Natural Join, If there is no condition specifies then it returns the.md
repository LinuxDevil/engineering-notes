---
notion-id: 322e6a1d-9c22-4962-b4ea-8698b3ef9e30
base: "[[Inner vs Natural joins.base]]"
INNER JOIN: In Inner Join, only those records will return which exists in both the tables
SR.NO.: 3
---
