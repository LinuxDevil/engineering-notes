---
notion-id: 20432784-a4e5-41e5-9715-5cb2dde05db8
base: "[[Inner vs Natural joins.base]]"
INNER JOIN: In Inner Join, The resulting table will contain all the attribute of both the tables including duplicate columns also
SR.NO.: 2
---
