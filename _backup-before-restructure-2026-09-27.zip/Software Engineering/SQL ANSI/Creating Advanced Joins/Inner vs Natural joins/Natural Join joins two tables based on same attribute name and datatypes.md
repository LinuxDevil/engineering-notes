---
notion-id: 1b1dd808-a727-4799-b6f7-ddcd2f9c9931
base: "[[Inner vs Natural joins.base]]"
INNER JOIN: Inner Join joins two table on the basis of the column which is explicitly specified in the ON clause.
SR.NO.: 1
---
