---
notion-id: 8e92b6bb-1293-4c7a-88d9-9084470d13b5
cover: "[[Creating Advanced Joins.jpeg]]"
---

**Using Table Aliases**
    Example 1:
```sql
SELECT cust_name, cust_contact
FROM Customers AS C, Orders AS O, OrderItems AS OI
WHERE C.cust_id = O.cust_id
 AND OI.order_num = O.order_num
 AND prod_id = 'RGAN01';
```
    Analysis:
        You’ll notice that the three tables in the `FROM` clauses all have aliases. `Customers AS C` establishes `C` as an alias for `Customers`, and so on. This approach enables you to use the abbreviated `C` instead of the full text `Customers`. In this example, the table aliases were used only in the `WHERE` clause, but aliases are not limited to just `WHERE`. You can use aliases in the `SELECT` list, the `ORDER BY` clause, and in any other part of the statement as well.

    **Note**: It is also worth noting that table aliases are only used during query execution. Unlike column aliases, table aliases are <u>never returned to the client</u>.

    **Using Different Join Types**
        Let’s look at self join, the natural join, and the outer join.

        What is **Self Joins**
            The self join, as its name implies, joins a table to itself. To use a self join, the table must contain a column (call it X) that acts as the primary key and a different column (call it Y) that stores values that can be matched up with the values in Column X. The values of Columns X and Y do not have to be the same for any given row, and the value in Column Y may even be `**null**`

        Example 2:
        Suppose you wanted to send a mailing to all the customer contacts who work for the same company for which Jim Jones works. This query requires that you first find out which company Jim Jones works for and next which customers work for that company. The following is one way to approach this problem:
```sql
SELECT c1.cust_id, c1.cust_name, c1.cust_contact
FROM Customers AS c1, Customers AS c2
WHERE c1.cust_name = c2.cust_name
   AND c2.cust_contact = 'Jim Jones';
```
        Analysis:
            The two tables needed in this query are actually the same table, and so the `Customers` table appears in the `FROM` clause twice. Although this is perfectly legal, any references to table `Customers` would be ambiguous because the DBMS does not know which `Customers` table you are referring to.
            To resolve this problem, table aliases are used. The first occurrence of `Customers` has an alias of `C1`, and the second has an alias of `C2`. Now those aliases can be used as table names. The `SELECT` statement, for example, uses the `C1` prefix to explicitly state the full name of the desired columns. If it did not, the DBMS would return an error because there are two of each column named `cust_id`, `cust_name`, and `cust_contact`. It cannot know which one you want. (Even though they are the same.) The `WHERE` clause first joins the tables and then filters the data by `cust_contact` in the second table to return only the wanted data.

        **Note**: Self joins are often used to replace statements using subqueries that retrieve data from the same table as the outer statement. Although the end result is the same, many DBMSs process joins far more quickly than they do subqueries. It is usually worth experimenting with both to determine which performs better.

        What is **Natural Joins**
            Natural join is a join in which you select only columns that are unique. This is typically done using a wildcard (`SELECT *`) for one table and explicit subsets of the columns for all other tables.
            Natural Join joins two tables based on same attribute name and datatypes. The resulting table will contain all the attributes of both the table but keep only one copy of each common column.

        **INNER** vs **NATURAL** joins 
            Inner Join joins two table on the basis of the column which is explicitly specified in the ON clause. The resulting table will contain all the attributes from both the tables including common column also.
            ![[Inner vs Natural joins.base]]
        Example 3:
```sql
SELECT C.*, O.order_num, O.order_date,
       OI.prod_id, OI.quantity, OI.item_price
FROM Customers AS C, Orders AS O,
     OrderItems AS OI
WHERE C.cust_id = O.cust_id
 AND OI.order_num = O.order_num
 AND prod_id = 'RGAN01';
```
        Analysis:
            In this example, a wildcard is used for the first table only. All other columns are explicitly listed so that no duplicate columns are retrieved.
            The truth is, every inner join you have created thus far is actually a natural join, and you will probably never need an inner join that is not a natural join.

    **Outer Joins**
        Most joins <u>relate</u> rows in one table with rows in another. But occasionally, you want to include rows that have <u>no related</u> rows, and thus you use **Outer** joins.

        Example 4:
```sql
SELECT Customers.cust_id, Orders.order_num
FROM Customers
 LEFT OUTER JOIN Orders ON Customers.cust_id = Orders.cust_id;
```
        Analysis:
            Like the inner join seen in the last lesson, this `SELECT` statement uses the keywords `OUTER JOIN` to specify the join type (instead of specifying it in the `WHERE` clause). But unlike inner joins, which relate rows in both tables, outer joins also include rows with no related rows. When using `OUTER JOIN` syntax, you must use the `RIGHT` or `LEFT` keywords to specify the table from which to include all rows (`RIGHT` for the one on the right of `OUTER JOIN` and `LEFT` for the one on the left). The previous example uses `LEFT OUTER JOIN` to select all the rows from the table on the left in the `FROM` clause (the `Customers` table).

        **Note**: **SQLite Outer Joins**
            SQLite supports `LEFT OUTER JOIN`, but not `RIGHT OUTER JOIN`. Fortunately, if you do need `RIGHT OUTER JOIN` functionality in SQLite, there is a very simple solution just flip the table order.

    **Full Outer Joins**
        The `FULL OUTER JOIN` keyword returns all records when there is a match in left (table1) or right (table2) table records.

        Example 5:
```sql
SELECT Customers.cust_id, Orders.order_num
FROM Customers
 FULL OUTER JOIN Orders ON Customers.cust_id = Orders.cust_id;
```
        Analysis:
            There is one other variant of the outer join, one that tends to be rarely used. The full outer join retrieves all rows from both tables and relates those that can be related. Unlike a left outer join or right outer join, which includes unrelated rows from a single table, the full outer join includes unrelated rows from both tables.

        **Note**: The `FULL OUTER JOIN` syntax is not supported by <u>MariaDB</u>, <u>MySQL</u>, or <u>SQLite</u>.
        **Note**: The `FULL OUTER JOIN` keyword returns all matching records from both tables whether the other table matches or not. So, if there are rows in "Customers" that do not have matches in "Orders", or if there are rows in "Orders" that do not have matches in "Customers", those rows will be listed as well.

    **Using Joins with Aggregate Functions**
        Example 6:
```sql
SELECT Customers.cust_id,
       COUNT(Orders.order_num) AS num_ord
FROM Customers
 INNER JOIN Orders ON Customers.cust_id = Orders.cust_id
GROUP BY Customers.cust_id;
```
        Analysis:
            This `SELECT` statement uses `INNER JOIN` to relate the `Customers` and `Orders` tables to each other. The `GROUP BY` clause groups the data by customer, and so the function call `COUNT(Orders.order_num)` counts the number of orders for each customer and returns it as `num_ord`.

        Example 7:
```sql
SELECT Customers.cust_id,
       COUNT(Orders.order_num) AS num_ord
FROM Customers
 LEFT OUTER JOIN Orders ON Customers.cust_id = Orders.cust_id
GROUP BY Customers.cust_id;
```
        Analysis:
            This example uses a left outer join to include all customers, even those who have not placed any orders. The results show that customer `1000000002` with `0` orders is included this time, unlike when the `INNER JOIN` was used.


# Joins Summary

![[Untitled 35.png]]

Joins in SQL can be of <u>**four**</u> different types, subjected to the outcome expected by combining records from two or more tables by making use of the common columns from tables involved in the Join function. <u>Inner Join</u> is used to get records with same values In both tables, <u>Left Join</u> is used to get all records from Left side table and only matching values from right table and <u>Right Join </u>is used to get all records from Right table and only matching records in left table. finally <u>Full Join</u> to get all the records from both tables irrespective of matching records.

**Inner Join**
    In an inner join, we only select the data which is common in both the tables. (ie, part <u>3</u> here) In order to make it more precise, all the records from both the tables matching up the condition mentioned with the join are picked in this join.
    `SELECT column-names FROM table-name1 INNER JOIN table-name2 ON column-name1 = column-name2 WHERE condition`
![[Untitled 36.png]]

**Left Join**
    In left join, we select all the data from the left table and from the right table only select the data set which matches up with the condition mentioned with the join (here area <u>1+3</u>)
    `SELECT column-names FROM table-name1 LEFT JOIN table-name2 ON column-name1 = column-name2 WHERE condition`
![[Untitled 37.png]]

**Right Join**
    In right join, we select all the data from the right table and from the left table only select the data set which matches up with the condition mentioned with the join (here <u>3+2</u>)
    `SELECT column-names FROM table-name1 RIGHT JOIN table-name2 ON column-name1 = column-name2 WHERE condition`
![[Untitled 38.png]]


**Full Join**
    In full join, all the records form both the tables are merged and selected irrespective of the condition mentioned with the join having met or not. (here <u>1+2+3</u>)
    `SELECT column-names FROM table-name1 FULL JOIN table-name2 ON column-name1 = column-name2 WHERE condition`
![[Untitled 39.png]]

![[Untitled 40.png]]

![[Untitled 41.png]]

![[Screen_Shot_2022-07-02_at_6.59.18_PM.png]]

![[Screen_Shot_2022-07-02_at_6.59.37_PM.png]]