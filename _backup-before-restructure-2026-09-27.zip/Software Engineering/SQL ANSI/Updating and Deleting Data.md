---
notion-id: 64a2c187-2049-417c-aab3-26a542f287a4
cover: "[[Updating and Deleting Data.jpeg]]"
---
*In this lesson, you will learn how to use the* `UPDATE` *and* `DELETE` *statements to enable you to further manipulate your table data*.

**Updating Data**
    To update (modify) data in a table, you use the `UPDATE` statement. `UPDATE` can be used in two ways:
		1. To update specific rows in a table.
		2. To update all rows in a table.

    Let’s take a look at a simple example. Customer `1000000005` has no email address on file and now has an address, so that record needs updating. The following statement performs this update:
    Example 1:
```sql
UPDATE Customers
SET cust_email = 'kim@thetoystore.com'
WHERE cust_id = 1000000005;
```
        Analysis:
            The `UPDATE` statement always begins with the name of the table being updated. In this example, it is the `Customers` table. The `SET` command is then used to assign the new value to a column. As used here, the `SET` clause sets the `cust_email` column to the specified value:
```sql
SET cust_email = 'kim@thetoystore.com'
```
            The `UPDATE` statement finishes with a `WHERE` clause that tells the DBMS which row to update. Without a `WHERE` clause, the DBMS would update all the rows in the `Customers` table with this new email address—definitely not the desired outcome.


**Deleting Data**
    To delete (remove) data from a table, you use the `DELETE` statement. `DELETE` can be used in two ways:
		1. To delete specific rows from a table.
		2. To delete all rows from a table.
    The following statement deletes a single row from the `Customers` table (the row you added in the last lesson):
    Example 2:
```sql
DELETE FROM Customers
WHERE cust_id = 1000000006;
```
        Analysis:
            This statement should be self-explanatory. `DELETE FROM` requires that you specify the name of the table from which the data is to be deleted. The `WHERE` clause filters which rows are to be deleted. In this example, only customer `1000000006` will be deleted. If the `WHERE` clause were omitted, this statement would have deleted every customer in the table!
    **Note**: **Faster Deletes**
        If you really do want to delete all rows from a table, don’t use `DELETE`. Instead, use the `TRUNCATE TABLE` statement, which accomplishes the same thing but does it much quicker (because data changes are not logged).

**Guidelines for Updating and Deleting Data**
    The `UPDATE` and `DELETE` statements used in the previous section all have `WHERE` clauses, and there is a very good reason for this. If you omit the `WHERE` clause, the `UPDATE` or `DELETE` will be applied to every row in the table. In other words, if you execute an `UPDATE` without a `WHERE` clause, every row in the table will be updated with the new values. Similarly, if you execute `DELETE` without a `WHERE` clause, all the contents of the table will be deleted.

    Here are some important <u>guidelines</u> that many SQL programmers follow:
		1. Never execute an `UPDATE` or a `DELETE` without a `WHERE` clause unless you really do intend to update and delete every row.
		2. Make sure every table has a primary key, and use it as the `WHERE` clause whenever possible. (You may specify individual primary keys, multiple values, or value ranges.)
		3. Before you use a `WHERE` clause with an `UPDATE` or a `DELETE`, first test it with a `SELECT` to make sure it is filtering the right records; it is far too easy to write incorrect `WHERE` clauses.
		4. Use database-enforced referential integrity so that the DBMS will not allow the deletion of rows that have data in other tables related to them.
		5. Some DBMSs allow database administrators to impose restrictions that prevent the execution of `UPDATE` or `DELETE` without a `WHERE` clause. If your DBMS supports this feature, consider using it.
