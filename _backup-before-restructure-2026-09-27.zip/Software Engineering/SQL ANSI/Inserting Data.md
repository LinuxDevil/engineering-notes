---
notion-id: 3443241a-6263-486d-9bfb-d7e95939b8e2
cover: "[[Inserting Data.jpeg]]"
---

What is `**Insert**` 
    As its name suggests, `INSERT` is used to insert (add) rows to a database table. Insert can be used in several ways:
		1. Inserting a single complete row
		2. Inserting a single partial row
		3. Inserting the results of a query

**Inserting Complete Row**

Example 1:
```sql
INSERT INTO Customers(cust_id,
                      cust_name,
                      cust_address,
                      cust_city,
                      cust_state,
                      cust_zip,
                      cust_country,
                      cust_contact,
                      cust_email)
VALUES(1000000006,
       'Toy Land',
       '123 Any Street',
       'New York',
       'NY',
       '11111',
       'USA',
       NULL,
       NULL);
```
    Analysis:
        The above example inserts a new customer into the `Customers` table. The data to be stored in each table column is specified in the `VALUES` clause, and a value must be provided for every column. If a column has no value (for example, the `cust_contact` and `cust_email` columns above), the `NULL` value should be used (assuming the table allows no value to be specified for that column). The columns must be populated in the order in which they appear in the table definition.


**Inserting Partial Rows**

Example 2:
```sql
INSERT INTO Customers(cust_id,
                      cust_name,
                      cust_address,
                      cust_city,
                      cust_state,
                      cust_zip,
                      cust_country)
VALUES(1000000006,
       'Toy Land',
       '123 Any Street',
       'New York',
       'NY',
       '11111',
       'USA');
```
    Analysis:
        In the examples given earlier in this lesson, values were not provided for two of the columns, `cust_contact` and `cust_email`. This means there is no reason to include those columns in the `INSERT` statement. This `INSERT` statement, therefore, omits the two columns and the two corresponding values.

**Inserting Retrieved Data**
    `INSERT` is usually used to add a row to a table using specified values. There is another form of `INSERT` that can be used to insert the result of a `SELECT` statement into a table. This is known as `INSERT SELECT`, and, as its name suggests, it is made up of an `INSERT` statement and a `SELECT` statement.

Example 3:
```sql
INSERT INTO Customers(cust_id,
                      cust_contact,
                      cust_email,
                      cust_name,
                      cust_address,
                      cust_city,
                      cust_state,
                      cust_zip,
                      cust_country)
SELECT cust_id,
       cust_contact,
       cust_email,
       cust_name,
       cust_address,
       cust_city,
       cust_state,
       cust_zip,
       cust_country
FROM CustNew;
```
    Analysis:
        This example uses `INSERT SELECT` to import all the data from `CustNew` into `Customers`. Instead of listing the `VALUES` to be inserted, the `SELECT` statement retrieves them from `CustNew`. Each column in the `SELECT` corresponds to a column in the specified columns list. How many rows will this statement insert? That depends on how many rows are in the `CustNew` table. If the table is empty, no rows will be inserted (and no error will be generated because the operation is still valid). If the table does, in fact, contain data, all that data will be inserted into `Customers`.


**Copying from One Table to Another**
    Unlike `INSERT SELECT`, which appends data to an existing table, `CREATE SELECT` copies data into a new table (and, depending on the DBMS being used, can overwrite the table if it already exists).

Example 4:
```sql
CREATE TABLE CustCopy AS SELECT * FROM Customers;
```
    Analysis:
        This `SELECT` statement creates a new table named `CustCopy` and copies the entire contents of the `Customers` table into it. Because `SELECT *` was used, every column in the `Customers` table will be created (and populated) in the `CustCopy` table. To copy only a subset of the available columns, you can specify explicit column names instead of the `*` wildcard character.
