---
notion-id: 5ed07054-653a-48d7-af66-0c4c43c1b589
cover: "[[Sorting Data.jpeg]]"
---
## The `ORDER BY` clause

What is a **Clause**
    SQL statements are made up of clauses, some required and some optional. A clause usually consists of a keyword and supplied data. An example of this is the `SELECT` statement’s `FROM` clause, which you saw in the last lesson.

**Sorting by One Column**

Example 1:
```sql
SELECT prod_name
FROM Products
ORDER BY prod_name;
```

Analysis:
    This statement is identical to the earlier statement, except it also specifies an `ORDER BY` clause instructing the DBMS software to sort the data by the `prod_name` column.

**Sorting by Multiple Columns**

Example 2: 

```sql
SELECT prod_id, prod_price, prod_name
FROM Products
ORDER BY prod_price, prod_name;
```

Analysis: 
    It is important to understand that when you are sorting by multiple columns, the sort sequence is exactly as specified. In other words, using the output in the example above, the products are sorted by the `prod_name` column only when multiple rows have the same `prod_price` value. If all the values in the `prod_price` column had been unique, no data would have been sorted by `prod_name`.

**Sorting by Column Position**
    In addition to being able to specify sort order using column names, ORDER BY also supports ordering specified by relative column position.

Example 3:

```sql
SELECT prod_id, prod_price, prod_name
FROM Products
ORDER BY 2, 3;
```

Analysis: 
    The output is identical to that of the query above. The difference here is in the `ORDER BY` clause. Instead of specifying column names, you specify the relative positions of selected columns in the `SELECT` list. `ORDER BY 2` means sort by the second column in the `SELECT` list, the `prod_price` column. `ORDER BY 2, 3` means sort by `prod_price` and then by `prod_name`.


**Specifying Sort Direction**
    Data sorting is not limited to ascending sort orders (from `A` to `Z`). Although this is the <u>default</u> sort order, the `ORDER BY` clause can also be used to sort in descending order (from `Z` to `A`). To sort by descending order, you must specify the keyword `DESC`.

Example 4:

```sql
# example sorts the products in 
# descending order (most expensive first),
# plus product name
SELECT prod_id, prod_price, prod_name
FROM Products
ORDER BY prod_price DESC, prod_name;
```

Analysis:
    The `DESC` keyword only applies to the column name that directly precedes it. In the example above, DESC was specified for the `prod_price` column, but not for the `prod_name` column. Therefore, the `prod_price` column is sorted in descending order, but the `prod_name` column (within each price) is still sorted in standard ascending order.