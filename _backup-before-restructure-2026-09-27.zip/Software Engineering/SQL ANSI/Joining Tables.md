---
notion-id: 85bb6530-2927-4f86-a6cc-c8b85095ea2b
cover: "[[Joining Tables.jpeg]]"
---
<u>*INNER, OUTER, RIGHT, LEFT, FULL, CROSS, SELF*</u>

There are mainly <u>two</u> types of joins in DBMS:
	1. **Inner Joins**: Theta, Natural, EQUI
	2. **Outer Joins**: Left, Right, Full

**Understanding Joins**
    **Understanding Relational Tables**

    To better understand the relational tables and database design let’s look at an example:
    Suppose you had a database table containing a product list, with each product in its own row. The kind of information you would store with each product would include a description and price, along with vendor information about the company that creates the product.
    Now suppose that you had multiple products created by the same vendor. Where would you store the vendor information (things like vendor name, address, and contact information)? You wouldn’t want to store that data along with the products for several reasons:
		1. Because the vendor information is the same for each product that vendor produces, repeating the information for each product is a waste of time and storage space.
		2. If vendor information changes (for example, if the vendor moves or the contact info changes), you would need to update every occurrence of the vendor information.
		3. When data is repeated (that is, the vendor information is used with each product), there is a high likelihood that the data will not be entered identically each time. Inconsistent data is extremely difficult to use in reporting.
    The key here is that having multiple occurrences of the same data is never a good thing, and that principle is the basis for relational database design. Relational tables are designed so that information is split into multiple tables, one for each data type. The tables are related to each other through common values (and thus the relational in relational design).

    In our example, you can create two tables—one for vendor information and one for product information. The `Vendors` table contains all the vendor information, one table row per vendor, along with a unique identifier for each vendor. This value, called a *primary key*, can be a vendor ID or any other unique value.
    The `Products` table stores only product information and no vendor-specific information other than the vendor ID (the `Vendors` table’s primary key). This key relates the `Vendors` table to the `Products` table, and using this vendor ID enables you to use the `Vendors` table to find the details about the appropriate vendor.

    The bottom line is that relational data can be stored efficiently and manipulated easily. Because of this, relational databases *scale* far better than nonrelational databases.

    What is the **scale** ?
        Able to handle an increasing load without failing. A well-designed database or application is said to *scale well*.

    Why Joins ?
        As just explained, breaking data into multiple tables enables more efficient storage, easier manipulation, and greater scalability. But these benefits come with a price.

    What is a **Join** ?
        A join is a mechanism used to associate, or join, tables within a `SELECT` statement (and thus the name *join*). By using a special syntax, you can join multiple tables so that a single set of output is returned, and the join associates the correct rows in each table on the fly.

    **Note**: Understand that a join table is not a <u>physical entity</u>; in other words, it does not exist in the actual database tables. A join is created by the DBMS as needed, <u>and it persists for the duration of the query execution</u>.


**Creating a Join**
    Creating a join is very simple. You must specify all the tables to be included and how they are related to each other.

Example 1:

```sql
SELECT vend_name, prod_name, prod_price
FROM Vendors, Products
WHERE Vendors.vend_id = Products.vend_id;
```

Analysis:
    Let’s take a look at the preceding code. The `SELECT` statement starts in the same way as all the statements you’ve looked at thus far, by specifying the columns to be retrieved. The big difference here is that two of the specified columns (`prod_name` and `prod_price`) are in one table, whereas the other (`vend_name`) is in another table.
    Now look at the `FROM` clause. Unlike all the prior `SELECT` statements, this one has two tables listed in the `FROM` clause, `Vendors` and `Products`. These are the names of the two tables that are being joined in this `SELECT` statement. The tables are correctly joined with a `WHERE` clause that instructs the DBMS to match `vend_id` in the `Vendors` table with `vend_id` in the `Products` table.
    You’ll notice that the columns are specified as `Vendors.vend_id` and `Products.vend_id`. This fully qualified column name is required here because if you just specified `vend_id`, the DBMS cannot tell which `vend_id` columns you are referring to. (There are two of them, one in each table.) As you can see in the preceding output, a single `SELECT` statement returns data from two different tables.

What is a **Cartesian Product**
    The results returned by a table relationship without a join condition. The number of rows retrieved will be the number of rows in the first table multiplied by the number of rows in the second table.

What is a **Cross Joins**
    Sometimes you’ll hear the type of join that returns a Cartesian Product referred to as a *cross join*.

What is **Inner Joins**
    E*quijoin *—a join based on the testing of equality between two tables. This kind of join is also called an *inner join*. In fact, you may use a slightly different syntax for these joins, specifying the type of join explicitly.
    **Inner Join** is used to return rows from both tables which satisfy the given condition. It is the most widely used join operation and can be considered as a default join-type
    Inner Join further divided into three subtypes:
		1. Theta Join
		2. Natural Join
		3. EQUI Join

        **Theta Join**
            **Theta Join** allows you to merge two tables based on the condition represented by theta. Theta joins work for all comparison operators. It is denoted by symbol **θ**. The general case of JOIN operation is called a Theta join.
            `A ⋈ A.column 2 >  B.column 2 (B)`

        **EQUI Join**
            **EQUI Join** is done when a Theta join uses only the equivalence condition. EQUI join is the most difficult operation to implement efficiently in an RDBMS, and one reason why RDBMS have essential performance problems.
            `A ⋈ A.column 2 =  B.column 2 (B)`

        **Natural Join**
            **Natural Join** does not utilize any of the comparison operators. In this type of join, the attributes should have the same name and domain. In Natural Join, there should be at least one common attribute between two relations.
            It performs selection forming equality on those attributes which appear in both relations and eliminates the duplicate attributes.



Example 2:

```sql
SELECT vend_name, prod_name, prod_price
FROM Vendors
INNER JOIN Products ON Vendors.vend_id = Products.vend_id;
```

Analysis:
    The `SELECT` in the statement is the same as the preceding `SELECT` statement, but the `FROM`
 clause is different. Here the relationship between the two tables is part of the `FROM` clause specified as `INNER JOIN`. In this syntax, the join condition is specified using the special `ON` clause instead of a `WHERE` clause. The actual condition passed to `ON` is the same as would be passed to `WHERE`.


**Joining Multiple Tables**
    SQL imposes no limit to the number of tables that may be joined in a `SELECT` statement. The basic rules for creating the join remain the same. First, list all the tables, and then define the relationship between each.

**Note**: The Postgres max tables to join is <u>61</u>

Note: **Maximum Number of Tables in a Join**
    In ANSI sql there’s no limit to the tables to join, but check for the implementations in your DBMS.

Example 3:

```sql
SELECT prod_name, vend_name, prod_price, quantity
FROM OrderItems, Products, Vendors
WHERE Products.vend_id = Vendors.vend_id
 AND OrderItems.prod_id = Products.prod_id
 AND order_num = 20007;
```

Analysis:
    This example displays the items in order number `20007`. Order items are stored in the `OrderItems` table. Each product is stored by its product ID, which refers to a product in the `Products` table. The products are linked to the appropriate vendor in the `Vendors` table by the vendor ID, which is stored with each product record. The `FROM` clause here lists the three tables, and the `WHERE` clause defines both of those join conditions. An additional `WHERE` condition is then used to filter just the items for order `20007`.
