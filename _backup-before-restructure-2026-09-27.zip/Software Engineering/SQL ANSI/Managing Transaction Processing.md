---
notion-id: 10d99249-ea0f-48af-bd77-ff9e8eab707c
cover: "[[Managing Transaction Processing.jpeg]]"
---

**Understanding Transaction Processing**
    Transaction processing is used to <u>maintain</u> database integrity by <u>ensuring</u> that batches of SQL operations execute <u>completely</u> or <u>not at all</u>.

    The `Orders` tables that you’ve been using in the past 19 lessons are a good example of this. Orders are stored in two tables: `Orders` stores actual orders, and `OrderItems` stores the individual items ordered. These two tables are related to each other using unique IDs called primary keys. These tables, in turn, are related to other tables containing customer and product information.
    The process of adding an order to the system is as follows:
		1. Check if the customer is already in the database. If not, add him or her.
		2. Retrieve the customer’s ID.
		3. Add a row to the `Orders` table associating it with the customer ID.
		4. Retrieve the new order ID assigned in the `Orders` table.
		5. Add one row to the `OrderItems` table for each item ordered, associating it with the `Orders` table by the retrieved ID (and with the `Products` table by product ID).

    What is **Transaction Processing** 
        *Transaction processing* is a mechanism used to <u>manage</u> sets of SQL operations that must be executed in <u>batches</u> so as to ensure that databases never contain the results of partial operations. With transaction processing, you can ensure that sets of operations are not aborted mid-processing—they either execute in their entirety or not at all (unless explicitly instructed otherwise). If no error occurs, the entire set of statements is committed (written) to the database tables. If an error does occur, then a rollback (undo) can occur to restore the database to a known and safe state.
        So basically:
			1. **Transaction**: A block of SQL statements.
			2. **Rollback**: The process of undoing specified SQL statements.
			3. **Commit**: Writing unsaved SQL statements to the database tables.
			4. **Save point**: temporary placeholder in a transaction set to which you can issue a rollback (as opposed to rolling back an entire transaction).

    Which Statements Can You** Roll Back?**
        Transaction processing is used to manage `INSERT`, `UPDATE`, and `DELETE` statements. You cannot roll back `SELECT` statements. (There would not be much point in doing so anyway.) You cannot roll back `CREATE` or `DROP` operations. These statements may be used in a transaction block, but if you perform a rollback, they will not be undone.

    So, if we look at the same example, this is how the process would work:
		1. Check if the customer is already in the database; if not, add him or her.
		2. Commit the customer information.
		3. Retrieve the customer’s ID.
		4. Add a row to the `Orders` table.
		5. If a failure occurs while adding the row to `Orders`, roll back.
		6. Retrieve the new order ID assigned in the `Orders` table.
		7. Add one row to the `OrderItems` table for each item ordered.
		8. If a failure occurs while adding rows to `OrderItems`, roll back all the `OrderItems` rows added and the `Orders` row.


**Controlling Transactions**
    **Note**: The key to managing transactions involves <u>breaking</u> your SQL statements into logical chunks and explicitly stating when data should be rolled back and when it should not.
    **Note**: Some DBMSs require that you explicitly mark the start and end of transaction blocks.

    SQL Server
```sql
BEGIN TRANSACTION
...
COMMIT TRANSACTION
```
    Postgres
```sql
BEGIN
```
    Analysis: 
        In this example, any SQL between the `BEGIN TRANSACTION` and `COMMIT TRANSACTION` statements must be executed entirely or not at all.
        Other DBMSs use variations of the above. You’ll notice that most implementations don’t have an <u>explicit end</u> of transaction. Rather, the transaction exists until something terminates it, usually a `COMMIT` to save changes or a `ROLLBACK` to undo them.


**Using **`**ROLLBACK**`
    The SQL `ROLLBACK` command is used to roll back (undo) SQL statements, as seen in this next statement:
```sql
DELETE FROM Orders;
ROLLBACK;
```
    Analysis:
        In this example, a `DELETE` operation is performed and then undone using a `ROLLBACK` statement. Although not the most useful example, it does demonstrate that, within a transaction block, `DELETE` operations (like `INSERT` and `UPDATE` operations) are never final.

**Using **`**COMMIT**`
    Usually, SQL statements are executed and written directly to the database tables. This is known as an *implicit commit*—the commit (write or save) operation happens automatically.
    Within a transaction block, however, commits might not occur implicitly. This, too, is DBMS specific. Some DBMSs treat a transaction end as an implicit commit; others do not.
    To force an explicit commit, you use the `COMMIT` statement. The following is a SQL Server example:
```sql
BEGIN TRANSACTION
DELETE OrderItems WHERE order_num = 12345
DELETE Orders WHERE order_num = 12345
COMMIT TRANSACTION
```
    Analysis:
        In this SQL Server example, order number `12345` is deleted entirely from the system. Because this involves updating two database tables, `Orders` and `OrderItems`, a transaction block is used to ensure that the order is not partially deleted. The final `COMMIT` statement writes the change only if no error occurred. If the first `DELETE` worked, but the second failed, the `DELETE` would not be committed.


**Using Savepoints**
    Simple `ROLLBACK` and `COMMIT` statements enable you to write or undo an entire transaction. Although this approach works for simple transactions, more complex transactions might require partial commits or rollbacks.
    For example, the process of adding an order described previously is a single transaction. If an error occurs, you only want to roll back to the point before the `Orders` row was added. You do not want to roll back the addition to the `Customers` table (if there was one).
    To support the rollback of partial transactions, you must be able to put placeholders at strategic locations in the transaction block. Then, if a rollback is required, you can roll back to one of the placeholders.
    In SQL, these placeholders are called *savepoints*. To create one in MariaDB, MySQL, and Oracle, you use the `SAVEPOINT` statement, as follows:
```sql
SAVEPOINT delete1;
```
    Each savepoint takes a unique name that identifies it so that, when you roll back, the DBMS knows where you are rolling back to. To roll back to this savepoint, do the following
```sql
ROLLBACK TO delete1;
```


Full Example: 
```sql
BEGIN TRANSACTION
INSERT INTO Customers(cust_id, cust_name)
VALUES(1000000010, 'Toys Emporium');
SAVE TRANSACTION StartOrder;
INSERT INTO Orders(order_num, order_date, cust_id)
VALUES(20100,'2020/12/1',1000000010);
IF @@ERROR <> 0 ROLLBACK TRANSACTION StartOrder;
INSERT INTO OrderItems(order_num, order_item,
prod_id, quantity, item_price)
VALUES(20100, 1, 'BR01', 100, 5.49);
IF @@ERROR <> 0 ROLLBACK TRANSACTION StartOrder;
INSERT INTO OrderItems(order_num, order_item,
prod_id, quantity, item_price)
VALUES(20100, 2, 'BR03', 100, 10.99);
IF @@ERROR <> 0 ROLLBACK TRANSACTION StartOrder;
COMMIT TRANSACTION
```
    Analysis:
        Here four `INSERT` statements are enclosed within a transaction block. A savepoint is defined after the first `INSERT` so that, if any of the subsequent `INSERT` operations fail, the transaction is only rolled back that far. In SQL Server, a variable named `@@ERROR` can be inspected to see if an operation succeeded. (Other DBMSs use different functions or variables to return this information.) If `@@ERROR` returns a value other than `0`, an error occurred, and the transaction will roll back to the savepoint. If the entire transaction is processed, a `COMMIT` will be issued to save the data.
