---
notion-id: 5b99debb-59e0-4116-bd54-e897fe6137ec
cover: "[[SQL Index.jpeg]]"
---

**Why** indexes? It allows us to speed up the process of finding X, so what if it has a reference point (an index).

In **MYSQL**, by default it creates an index for the PrimaryKey, and index on the foreign key too.

**Note**: Index Algorithms.

**Note**: Index type None-Unique, Unique, Full-Text and partial.

You can create an index for the PostalCode’s for example (Varchar is not having the same performance as the integer index).

The <u>Lock</u> need’s to be done, because we don’t want to run into the problem of concurrency.

<u>Why not index everything</u> ? Because of storage and the index’s takes a lot of index, every time you make an insert/update it has to update every index you have so it will perform a bad performance, so index only the most searched columns.

Clustered Indexes
    Clustered Index Seek, Tree, you can create only one clustered index.
    It’s a way to represent data as a whole

Non-clustered Indexes 
    Heap Structure, Separate index structure, leaf of top, you can set reference to top or bottom of the base table. RID (Row Identifier)
    Physically separate structure that references the base data and it can have different sort order.

<u>Unique → Non-clustered, Primary → Clustered </u>

Column-store index: 2012 

---

### Introduction to SQL Indexing

---

Well in general index is a `B-tree`. There are two types of indexes: clustered and nonclustered.

**Clustered** index creates a physical order of rows (it can be only one and in most cases it is also a primary key — if you create primary key on table you create clustered index on this table also).

**Non-clustered** index is also a binary tree but it doesn’t create a physical order of rows. So the leaf nodes of non-clustered index contain PK (if it exists) or row index.

Indexes are used to increase the speed of search. Because the complexity is of O(log N). Indexes is very large and interesting topic. I can say that creating indexes on large database is some kind of art sometimes.

---

Now, let’s say that we want to run a query to find all the details of any employees who are named ‘Abc’?

```plain text
SELECT * FROM Employee
WHERE Employee_Name = 'Abc'
```

**What would happen without an index?**

Database software would literally have to look at every single row in the Employee table to see if the Employee_Name for that row is ‘Abc’. And, because we want every row with the name ‘Abc’ inside it, we can not just stop looking once we find just one row with the name ‘Abc’, because there could be other rows with the name **Abc**. So, every row up until the last row must be searched — which means thousands of rows in this scenario will have to be examined by the database to find the rows with the name ‘Abc’. This is what is called a **full table scan**

**How a database index can help performance**

The whole point of having an index is to speed up search queries by essentially cutting down the number of records/rows in a table that need to be examined. An index is a data structure (most commonly a B- tree) that stores the values for a specific column in a table.

**How does B-trees index work?**

The reason B- trees are the most popular data structure for indexes is due to the fact that they are time efficient — because look-ups, deletions, and insertions can all be done in logarithmic time. And, another major reason B- trees are more commonly used is because the data that is stored inside the B- tree can be sorted. The RDBMS typically determines which data structure is actually used for an index. But, in some scenarios with certain RDBMS’s, you can actually specify which data structure you want your database to use when you create the index itself.

**How does a hash table index work?**

The reason hash indexes are used is because hash tables are extremely efficient when it comes to just looking up values. So, queries that compare for equality to a string can retrieve values very fast if they use a hash index.

For instance, the query we discussed earlier could benefit from a hash index created on the Employee_Name column. The way a hash index would work is that the column value will be the key into the hash table and the actual value mapped to that key would just be a pointer to the row data in the table. Since a hash table is basically an associative array, a typical entry would look something like “Abc => 0x28939″, where 0x28939 is a reference to the table row where Abc is stored in memory. Looking up a value like “Abc” in a hash table index and getting back a reference to the row in memory is obviously a lot faster than scanning the table to find all the rows with a value of “Abc” in the Employee_Name column.

**The disadvantages of a hash index**

Hash tables are not sorted data structures, and there are many types of queries which hash indexes can not even help with. For instance, suppose you want to find out all of the employees who are less than 40 years old. How could you do that with a hash table index? Well, it’s not possible because a hash table is only good for looking up key value pairs — which means queries that check for equality

**What exactly is inside a database index?** So, now you know that a database index is created on a column in a table, and that the index stores the values in that specific column. But, it is important to understand that a database index does not store the values in the other columns of the same table. For example, if we create an index on the Employee_Name column, this means that the Employee_Age and Employee_Address column values are not also stored in the index. If we did just store all the other columns in the index, then it would be just like creating another copy of the entire table — which would take up way too much space and would be very inefficient.

**How does a database know when to use an index?** When a query like “SELECT * FROM Employee WHERE Employee_Name = ‘Abc’ ” is run, the database will check to see if there is an index on the column(s) being queried. Assuming the Employee_Name column does have an index created on it, the database will have to decide whether it actually makes sense to use the index to find the values being searched — because there are some scenarios where it is actually less efficient to use the database index, and more efficient just to scan the entire table.

**What is the cost of having a database index?**

It takes up space — and the larger your table, the larger your index. Another performance hit with indexes is the fact that whenever you add, delete, or update rows in the corresponding table, the same operations will have to be done to your index. Remember that an index needs to contain the same up to the minute data as whatever is in the table column(s) that the index covers.

As a general rule, an index should only be created on a table if the data in the indexed column will be queried frequently.

---

**Why is it needed?**

When data is stored on disk-based storage devices, it is stored as blocks of data. These blocks are accessed in their entirety, making them the atomic disk access operation. Disk blocks are structured in much the same way as linked lists; both contain a section for data, a pointer to the location of the next node (or block), and both need not be stored contiguously.

Due to the fact that a number of records can only be sorted on one field, we can state that searching on a field that isn’t sorted requires a Linear Search which requires `(N+1)/2` block accesses (on average), where `N` is the number of blocks that the table spans. If that field is a non-key field (i.e. doesn’t contain unique entries) then the entire tablespace must be searched at `N` block accesses.

Whereas with a sorted field, a Binary Search may be used, which has `log2 N` block accesses. Also since the data is sorted given a non-key field, the rest of the table doesn’t need to be searched for duplicate values, once a higher value is found. Thus the performance increase is substantial.

**What is indexing?**

Indexing is a way of sorting a number of records on multiple fields. Creating an index on a field in a table creates another data structure which holds the field value, and a pointer to the record it relates to. This index structure is then sorted, allowing Binary Searches to be performed on it.

The downside to indexing is that these indices require additional space on the disk since the indices are stored together in a table using the MyISAM engine, this file can quickly reach the size limits of the underlying file system if many fields within the same table are indexed.

**How does it work?**

Firstly, let’s outline a sample database table schema;

```plain text
Field name       Data type      Size on disk
id (Primary key) Unsigned INT   4 bytes
firstName        Char(50)       50 bytes
lastName         Char(50)       50 bytes
emailAddress     Char(100)      100 bytes
```

**Note**: char was used in place of varchar to allow for an accurate size on disk value. This sample database contains five million rows and is unindexed. The performance of several queries will now be analyzed. These are a query using the *id* (a sorted key field) and one using the *firstName* (a non-key unsorted field).

***Example 1*** — *sorted vs unsorted fields*

Given our sample database of `r = 5,000,000` records of a fixed size giving a record length of `R = 204` bytes and they are stored in a table using the MyISAM engine which is using the default block size `B = 1,024` bytes. The blocking factor of the table would be `bfr = (B/R) = 1024/204 = 5` records per disk block. The total number of blocks required to hold the table is `N = (r/bfr) = 5000000/5 = 1,000,000` blocks.

A linear search on the id field would require an average of `N/2 = 500,000` block accesses to find a value, given that the id field is a key field. But since the id field is also sorted, a binary search can be conducted requiring an average of `log2 1000000 = 19.93 = 20` block accesses. Instantly we can see this is a drastic improvement.

Now the *firstName* field is neither sorted nor a key field, so a binary search is impossible, nor are the values unique, and thus the table will require searching to the end for an exact `N = 1,000,000` block accesses. It is this situation that indexing aims to correct.

Given that an index record contains only the indexed field and a pointer to the original record, it stands to reason that it will be smaller than the multi-field record that it points to. So the index itself requires fewer disk blocks than the original table, which therefore requires fewer block accesses to iterate through. The schema for an index on the *firstName* field is outlined below;

```plain text
Field name       Data type      Size on disk
firstName        Char(50)       50 bytes
(record pointer) Special        4 bytes
```

```plain text


```

**Note**: Pointers in MySQL are 2, 3, 4 or 5 bytes in length depending on the size of the table.

***Example 2*** — *indexing*

Given our sample database of `r = 5,000,000` records with an index record length of `R = 54` bytes and using the default block size `B = 1,024` bytes. The blocking factor of the index would be `bfr = (B/R) = 1024/54 = 18` records per disk block. The total number of blocks required to hold the index is `N = (r/bfr) = 5000000/18 = 277,778` blocks.

Now a search using the *firstName* field can utilize the index to increase performance. This allows for a binary search of the index with an average of `log2 277778 = 18.08 = 19` block accesses. To find the address of the actual record, which requires a further block access to read, bringing the total to `19 + 1 = 20` block accesses, a far cry from the 1,000,000 block accesses required to find a *firstName* match in the non-indexed table.

**When should it be used?**

Given that creating an index requires additional disk space (277,778 blocks extra from the above example, a ~28% increase), and that too many indices can cause issues arising from the file systems size limits, careful thought must be used to select the correct fields to index.

Since indices are only used to speed up the searching for a matching field within the records, it stands to reason that indexing fields used only for output would be simply a waste of disk space and processing time when doing an insert or delete operation, and thus should be avoided. Also given the nature of a binary search, the cardinality or uniqueness of the data is important. Indexing on a field with a cardinality of 2 would split the data in half, whereas a cardinality of 1,000 would return approximately 1,000 records. With such a low cardinality the effectiveness is reduced to a linear sort, and the query optimizer will avoid using the index if the cardinality is less than 30% of the record number, effectively making the index a waste of space.

---

**Understanding Indexes**

Indexes are used to sort data logically to improve the speed of searching and sorting operations. The best way to understand indexes is to envision the index at the back of a book (this book, for example).

Suppose you want to find all occurrences of the word *datatype* in this book. The simple way to do this would be to turn to page 1 and scan every line of every page looking for matches. Although that works, it is obviously not a workable solution.

Scanning a few pages of text might be feasible, but scanning an entire book in that manner is not. As the amount of text to be searched increases, so does the time it takes to pinpoint the desired data.

That is why books have indexes. An index is an alphabetical list of words with references to their locations in the book. To search for *datatype*, you find that word in the index to determine what pages it appears on. Then, you turn to those specific pages to find your matches.

What makes an index work? Simply, it is the fact that it is sorted correctly. The difficulty in finding words in a book is not the amount of content that must be searched; rather, it is the fact that the content is not sorted by word. If the content is sorted like a dictionary, an index is not needed (which is why dictionaries don’t have indexes).

Database indexes work in much the same way. Primary key data is always sorted; that’s just something the DBMS does for you. Retrieving specific rows by primary key, therefore, is always a fast and efficient operation.

Searching for values in other columns is usually not as efficient, however. For example, what if you want to retrieve all customers who live in a specific state? Because the table is not sorted by state, the DBMS must read every row in the table (starting at the very first row) looking for matches, just as you would have to do if you were trying to find words in a book without using an index.

The solution is to use an index. You may define an index on one or more columns so that the DBMS keeps a sorted list of the contents for its own use. After an index is defined, the DBMS uses it in much the same way as you would use a book index. It searches the sorted index to find the location of any matches and then retrieves those specific rows.

Indexing Warning

1. Indexes improve the performance of retrieval operations, but they degrade the performance of data insertion, modification, and deletion. When these operations are executed, the DBMS has to update the index dynamically.
2. Index data can take up lots of storage space.
3. Not all data is suitable for indexing. Data that is not sufficiently unique (State, for example) will not benefit as much from indexing as data that has more possible values (First Name or Last Name, for example).
4. Indexes are used for data filtering and for data sorting. If you frequently sort data in a specific order, that data might be a candidate for indexing.
5. Multiple columns can be defined in an index (for example, State plus City). Such an index will be of use only when data is sorted in State plus City order. (If you want to sort by City, this index would not be of any use.)

Indexes are created with the `CREATE INDEX` statement (which varies dramatically from one DBMS to another). The following statement creates a simple index on the `Products` table’s product name column:

```plain text
CREATE INDEX prod_name_ind
ON Products (prod_name);
```

Analysis:

Every index must be uniquely named. Here the name `prod_name_ind` is defined after the keywords `CREATE INDEX`. `ON` is used to specify the table being indexed, and the columns to include in the index (just one in this example) are specified in parentheses after the table name.