---
notion-id: 34d3162b-206b-4a44-bea4-b09fa78f6384
base: "[[Union vs Joins.base]]"
UNION: Number of columns selected from each table should be same.
---
