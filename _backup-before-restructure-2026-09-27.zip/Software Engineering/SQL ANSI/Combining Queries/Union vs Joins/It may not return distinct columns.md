---
notion-id: 4bac4d9d-2297-48e3-bf50-b125b83cca65
base: "[[Union vs Joins.base]]"
UNION: It returns distinct rows.
---
