---
notion-id: f8a5444f-8e09-44b0-88bd-f0dc2b3bf728
base: "[[Union vs Joins.base]]"
UNION: Datatypes of corresponding columns selected from each table should be same.
---
