---
notion-id: d4ef19e0-dda6-4339-b1a6-4b7e210317be
base: "[[Union vs Joins.base]]"
UNION: It combines data into new rows
---
