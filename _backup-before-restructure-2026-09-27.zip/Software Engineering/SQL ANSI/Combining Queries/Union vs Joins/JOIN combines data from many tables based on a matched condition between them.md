---
notion-id: 061b8be4-5604-4833-ae80-9ef61cdd326b
base: "[[Union vs Joins.base]]"
UNION: SQL combines the result-set of two or more SELECT statements.
---
