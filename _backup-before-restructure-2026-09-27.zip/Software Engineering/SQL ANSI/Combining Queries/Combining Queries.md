---
notion-id: e84552fd-3dcc-422e-8cf6-716b318e0335
cover: "[[Combining Queries.jpeg]]"
---
*In this lesson, you’ll learn how to use the* `UNION` *operator to combine multiple* `SELECT` *statements into one result set*.

**Understanding Combined Queries**
    Most SQL queries contain a single `SELECT` statement that returns data from one or more tables. SQL also enables you to perform multiple queries (multiple `SELECT` statements) and return the results as a single query result set. These combined queries are usually known as *unions* or *compound queries.*
    For the most part, combining two queries to the same table accomplishes the same thing as a single query with multiple `WHERE` clause conditions. In other words, any `SELECT` statement with multiple `WHERE` clauses can also be specified as a combined query.

**Creating Combined Queries**
    SQL queries are combined using the `UNION` operator. Using `UNION`, you can specify multiple `SELECT` statements, and their results can be combined into a single result set.

**Why Combined queries**
	1. To return similarly structured data from different tables in a single query.
	2. To perform multiple queries against a single table returning the data as one query.

**Using **`**UNION**`
    Let’s look at an example. You need a report on all your customers in Illinois, Indiana, and Michigan. You also want to include all `Fun4All` locations, regardless of state. Of course, you can create a `WHERE` clause that will do this, but this time you’ll use a `UNION` instead.
    As just explained, creating a `UNION` involves writing multiple `SELECT` statements. First, look at the individual statements:
```sql
SELECT cust_name, cust_contact, cust_email
FROM Customers
WHERE cust_state IN ('IL','IN','MI');
```
```sql
SELECT cust_name, cust_contact, cust_email
FROM Customers
WHERE cust_name = 'Fun4All';
```
    Analysis:
        The first `SELECT` retrieves all rows in Illinois, Indiana, and Michigan by passing those state abbreviations to the `IN` clause. The second `SELECT` uses a simple equality test to find all `Fun4All` locations. You’ll notice that one row appears on both outputs as it meets both `WHERE` conditions.

    To combine these two statements, do the following:
    Example 1:
```sql
SELECT cust_name, cust_contact, cust_email
FROM Customers
WHERE cust_state IN ('IL','IN','MI')
UNION
SELECT cust_name, cust_contact, cust_email
FROM Customers
WHERE cust_name = 'Fun4All';
```
    Analysis:
        The preceding statements are made up of both of the previous `SELECT` statements separated by the `UNION` keyword. `UNION` instructs the DBMS to execute both `SELECT` statements and combine the output into a single query result set.

    **Note**: `**UNION**`** Limits**
        There is no standard SQL limit to the number of `SELECT` statements that can be combined with `UNION` statements.


`**UNION**`** Rules**
	1. A `UNION` must be composed of two or more `SELECT` statements, each separated by the keyword `UNION` (so, if you’re combining four `SELECT` statements, you would use three `UNION` keywords).
	2. Each query in a `UNION` must contain the same columns, expressions, or aggregate functions (and some DBMSs even require that columns be listed in the same order).
	3. Column datatypes must be compatible. They need not be the same name or the exact same type, but they must be of a type that the DBMS can implicitly convert (for example, different numeric types or different date types).

**Including or Eliminating Duplicate Rows**
    Go back to the preceding section titled “Using `UNION`” and look at the sample `SELECT` statements used. You’ll notice that when executed individually, the first `SELECT` statement returns three rows, and the second `SELECT` statement returns two rows. However, when the two `SELECT` statements are combined with a `UNION`, only four rows are returned, not five.
    The `UNION` automatically removes any duplicate rows from the query result set (in other words, it behaves just as multiple `WHERE` clause conditions in a single `SELECT` would). Because there is a Fun4All location in Indiana, that row was returned by both `SELECT` statements. When the `UNION` was used, the duplicate row was eliminated.
    This is the default behavior of `UNION`, but you can change it if you so desire. If you would, in fact, want all occurrences of all matches returned, you could use `UNION ALL` instead of `UNION`.

    Example 2:
```sql
SELECT cust_name, cust_contact, cust_email
FROM Customers
WHERE cust_state IN ('IL','IN','MI')
UNION ALL
SELECT cust_name, cust_contact, cust_email
FROM Customers
WHERE cust_name = 'Fun4All';
```
    Analysis:
        When you use `UNION ALL`, the DBMS does not eliminate duplicates. Therefore, the preceding example returns five rows, one of them occurring twice.
        At the beginning of this lesson, I said that `UNION` almost always accomplishes the same thing as multiple `WHERE` conditions. `UNION ALL` is the form of `UNION` that accomplishes what cannot be done with `WHERE` clauses. If you do, in fact, want all occurrences of matches for every condition (including duplicates), you must use `UNION ALL` and not `WHERE`.


**Sorting Combined Query Results**
    `SELECT` statement output is sorted using the `ORDER BY` clause. When combining queries with a `UNION`, you may use only one `ORDER BY` clause, and it must occur after the final `SELECT` statement. There is very little point in sorting part of a result set one way and part another way, and so multiple `ORDER BY` clauses are not allowed.
```sql
SELECT cust_name, cust_contact, cust_email
FROM Customers
WHERE cust_state IN ('IL','IN','MI')
UNION
SELECT cust_name, cust_contact, cust_email
FROM Customers
WHERE cust_name = 'Fun4All'
ORDER BY cust_name, cust_contact;
```
    Analysis:
        This `UNION` takes a single `ORDER BY` clause after the final `SELECT` statement. Even though the `ORDER BY` appears to be a part of only that last `SELECT` statement, the DBMS will in fact use it to sort all the results returned by all the `SELECT` statements.

    **Note**: **Other **`**UNION**`** Types**
        Some DBMSs support two additional types of `UNION`. `EXCEPT` (sometimes called `MINUS`) can be used to retrieve only the rows that exist in the first table but not in the second, and `INTERSECT` can be used to retrieve only the rows that exist in both tables. In practice, however, these `UNION` types are rarely used because the same results can be accomplished using joins.
    **Note**:
        In practice, `UNION` is really useful when you need to combine data from multiple tables, even tables with mismatched column names, in which case you can combine `UNION` with aliases to retrieve a single set of results.


# Union Summary

![[Untitled 42.png]]

**UNION Operator**
    The `Union` operator returns rows from both tables. If used by itself, `UNION` returns a distinct list of rows. Using `UNION ALL`, returns all rows from both tables. A `UNION` is useful when you want to sort results from two separate queries as one combined result. For instance, if you have two tables, `Vendor`, and `Customer`, and you want a combined list of names, you can easily do so using:
```sql
SELECT ‘Vendor’, V.Name
FROM   Vendor V
UNION
SELECT ‘Customer’, C.Name
FROM   Customer C
ORDER BY Name
```

**INTERSECT Operator**
    Use an intersect operator to return rows that are in common between two tables; it returns unique rows from both the left and right query. This query is useful when you want to find results that are in common between two queries. Continuing with `Vendor`s, and `Customer`s, suppose you want to find `vendor`s that are also `customer`s. You can do so easily using:
```sql
SELECT V.Name
FROM   Vendor V
INTERSECT
SELECT C.Name
FROM   Customer C
ORDER BY Name
```
    You can also use an `INNER JOIN` to answer the same question.
```sql
SELECT Distinct V.Name
FROM   Vendor V
INNER JOIN Customer C
ON V.Name = C.Name
ORDER BY V.Name
```

**EXCEPT Operator**
    Use the `EXCEPT` Operator to return only rows found in the left query. It returns unique rows from the left query that aren’t in the right query’s results. This query is useful when you’re looking to find rows that are in one set but not another. For example, to create a list of all vendors that are not customers, you could write:
```sql
SELECT V.Name
FROM   Vendor V
EXCEPT
SELECT C.Name
FROM   Customer C
ORDER BY Name
```
    Like `INTERSECTION`, `EXCEPT` has an equivalent SQL statement. In this case, we can use an `OUTER JOIN` to construct its equivalent.
```sql
SELECT Distinct V.Name
FROM   Vendor V
LEFT OUTER JOIN Customer C
ON V.Name = C.Name
WHERE C.Name is NULL
ORDER BY V.Name
```



**Unions vs Joins**

![[Union vs Joins.base]]