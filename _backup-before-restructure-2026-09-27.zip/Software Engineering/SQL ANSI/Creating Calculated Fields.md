---
notion-id: 99862789-6bdd-4171-9415-4f3ad6f81940
cover: "[[Creating Calculated Fields.jpeg]]"
---

What is a **Field**
    Essentially means the same thing as *column *and often used interchangeably, although database columns are typically called *columns *and the term *fields *is usually used in conjunction with calculated fields.


**Concatenating Fields**

What is **Concatenate**
    Joining values together (by appending them to each other) to form a single long value.
    **Note**: SQL Server uses `+`for concatenation. DB2, Oracle, PostgreSQL, and SQLite support `||`

Example 1:

```sql
/* DB2, Oracle, PostgreSQL, and SQLite */
SELECT vend_name || '(' || vend_country || ')'
FROM Vendors
ORDER BY vend_name;
/* SQL Server */
SELECT vend_name + '(' + vend_country + ')'
FROM Vendors
ORDER BY vend_name;
/* MySQL, MariaDB */
SELECT Concat(vend_name, ' (', vend_country, ')')
FROM Vendors
ORDER BY vend_name;
```

Analysis:
    The above `SELECT` statements concatenate the following elements:
		1. The name stored in the `vend_name` column.
		2. A string containing a space and an open parenthesis.
		3. The country stored in the `vend_country`
 column.
		4. A string containing the close parenthesis.
    The `SELECT` statement returns a single column (a calculated field) containing all these four elements as one unit.


The `RTRIM()` Function
    Used to return the data formatted properly ie. trim padded spaces.

Example 2:

```sql
SELECT RTRIM(vend_name) + ' (' + RTRIM(vend_country) + ')'
FROM Vendors
ORDER BY vend_name;
/* OR */
SELECT RTRIM(vend_name) || ' (' || RTRIM(vend_country) || ')'
FROM Vendors
ORDER BY vend_name;
```

Analysis:
    The `RTRIM()` function trims all space from the right of a value. When you use `RTRIM()`, the individual columns are all trimmed properly.
    **Note**: Most DBMSs support `RTRIM()` (which, as just seen, trims the right side of a string), as well as `LTRIM()`, which trims the left side of a string, and `TRIM()`, which trims both the right and left.

**Using Aliases (Derived columns)**
    An alias is just that, an alternate name for a field or value. Aliases are assigned with the `AS` keyword.

Example 3:

```sql
SELECT RTRIM(vend_name) + ' (' + RTRIM(vend_country) + ')'
 AS vend_title
FROM Vendors
ORDER BY vend_name;
```

Analysis:
    The `SELECT` statement itself is the same as the one used in the previous code snippet, except that here the calculated field is followed by the text AS `vend_title`. This instructs SQL to create a calculated field named `vend_title` containing the calculation specified. As you can see in the output, the results are the same as before, but the column is now named `vend_title`, and any client application can refer to this column by name, just as it would to any actual table column.

**Performing Mathematical Calculations**

Example 4:

```sql
SELECT prod_id,
       quantity,
       item_price,
       quantity*item_price AS expanded_price
FROM OrderItems
WHERE order_num = 20008;
```

Analysis:
    The `expanded_price` column shown in the output above is a calculated field; the calculation is simply `quantity*item_price`. The client application can now use this new calculated column just as it would any other column.

