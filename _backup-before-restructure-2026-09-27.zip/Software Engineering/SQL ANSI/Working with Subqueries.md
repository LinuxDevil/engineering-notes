---
notion-id: 8b9e5e93-3d63-4356-a17c-2000c0cf74ed
cover: "[[Working with Subqueries.jpeg]]"
---

**Understanding Subqueries**
    `SELECT` statements are SQL queries. All the `SELECT` statements we have seen thus far are simple queries—single statements retrieving data from individual database tables.


What is a **Query**
    Any SQL statement. However, the term is usually used to refer to `SELECT` statements.

**Filtering by Subquery**

Example 1:
    The `Orders` table stores a single row for each order containing order number, customer ID, and order date. The individual order items are stored in the related `OrderItems` table. The `Orders` table does not store customer information. It only stores a customer ID. The actual customer information is stored in the `Customers` table.
    Now suppose you wanted a list of all the customers who ordered item `RGAN01`. What would you have to do to retrieve this information? Here are the steps:
		1. Retrieve the order numbers of all orders containing item `RGAN01`.
		2. Retrieve the customer ID of all the customers who have orders listed in the order numbers returned in the previous step.
		3. Retrieve the customer information for all the customer IDs returned in the previous step.
    Each of these steps can be executed as a separate query. By doing so, you use the results returned by one `SELECT` statement to populate the `WHERE` clause of the next `SELECT` statement.

```sql
SELECT order_num
FROM OrderItems
WHERE prod_id = 'RGAN01';
```
    Now that we know which orders contain the desired item, the next step is to retrieve the customer IDs associated with those order number, `20007` and `20008`.
```sql
SELECT cust_id
FROM Orders
WHERE order_num IN (20007,20008);
```
    Now, combine the two queries by turning the first (the one that returned the order numbers) into a subquery. Look at the following `SELECT` statement:
```sql
SELECT cust_id
FROM Orders
WHERE order_num IN (SELECT order_num
                    FROM OrderItems
                    WHERE prod_id = 'RGAN01');
```
    You now have the IDs of all the customers who ordered item `RGAN01`. The next step is to retrieve the customer information for each of those customer IDs. Here is the SQL statement to retrieve the two columns:
```sql
SELECT cust_name, cust_contact
FROM Customers
WHERE cust_id IN (SELECT cust_id
                  FROM Orders
                  WHERE order_num IN (SELECT order_num
                                      FROM OrderItems
                                      WHERE prod_id = 'RGAN01'));
```
    Analysis:
        Subqueries are always processed starting with the innermost `SELECT` statement and working outward. When the preceding `SELECT` statement is processed, the DBMS actually performs two operations.
        It first runs the following subquery:
            `SELECT order_num FROM orderitems WHERE prod_id='RGAN01'`
        That query returns the two order numbers `20007` and `20008`. Those two values are then passed to the `WHERE` clause of the outer query in the comma-delimited format required by the `IN` operator. The outer query now becomes
            `SELECT cust_id FROM orders WHERE order_num IN (20007,20008)`

        To execute the above `SELECT` statement, the DBMS had to actually perform three `SELECT` statements. The innermost subquery returned a list of order numbers that were then used as the `WHERE` clause for the subquery above it. That subquery returned a list of customer IDs that were used as the `WHERE` clause for the top-level query. The top-level query actually returned the desired data.


**Using Subqueries as Calculated Fields**

Example 2:
    Another way to use subqueries is in creating calculated fields. Suppose you wanted to display the total number of orders placed by every customer in your `Customers` table. Orders are stored in the `Orders` table along with the appropriate customer ID.
    To perform this operation, follow these steps:
		1. Retrieve the list of customers from the `Customers` table.
		2. For each customer retrieved, count the number of associated orders in the `Orders` table.
```sql
SELECT cust_name,
       cust_state,
       (SELECT COUNT(*)
        FROM Orders
        WHERE Orders.cust_id = Customers.cust_id) AS orders
FROM Customers
ORDER BY cust_name;
```
    Analysis:
        This `SELECT` statement returns three columns for every customer in the `Customers` table: `cust_name`, `cust_state`, and `orders`. `Orders` is a calculated field that is set by a subquery that is provided in parentheses. That subquery is executed once for every customer retrieved. In the example above, the subquery is executed five times because five customers were retrieved.
        The `WHERE` clause in the subquery is a little different from the `WHERE` clauses used previously because it uses fully qualified column names; instead of just a column name (`cust_id`), it specifies the table and the column name (as `Orders.cust_id` and `Customers.cust_id`). The following `WHERE` clause tells SQL to compare the `cust_id` in the `Orders` table to the one currently being retrieved from the `Customers` table:
            `WHERE Orders.cust_id = Customers.cust_id`
        This syntax—the table name and the column name separated by a period—must be used whenever there is possible ambiguity about column names. In this example, there are two `cust_id` columns, one in `Customers` and one in `Orders`. Without fully qualifying the column names, the DBMS assumes you are comparing the `cust_id` in the `Orders` table to itself. Because will always return the total number of orders in the `Orders` table.
            `SELECT COUNT(*)  FROM Orders WHERE cust_id = cust_id`

    **Note**: Although subqueries are extremely useful in constructing this type of `SELECT`  statement, care must be taken to properly qualify ambiguous column names.
