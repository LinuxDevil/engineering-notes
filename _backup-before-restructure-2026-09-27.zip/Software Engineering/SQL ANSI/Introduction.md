---
notion-id: e10ebd76-77e3-4066-9187-a285e11decbb
cover: "[[Introduction 1.jpeg]]"
---

What is a **Database**
    `A container (usually a file or set of files) to store organized data.`

What is a **Table**
    `A structured list of data of a specific type.`

What is a **Schema**
    `Information about database and table layout and properties.`

What is a **Column**
    `A single field in a table. All tables are made up of one or more columns.`


What is a **Datatype**
    `A type of allowed data. Every table column has an associated datatype that restricts (or allows) specific data in that column.`

What is a **Row**
    `A record in a table.`


What are the **SQL Keys** 
	1. Primary Key
	2. Unique Key
	3. Candidate Key
	4. Alternate Key
	5. Composite Key
	6. Super Key
	7. Foreign Key

What is a **Primary key**
    `A column (or set of columns) whose values uniquely identify every row in a table.`
    Rules: 
		1. *No two rows can have the same primary key value.*
		2. *Every row must have a value in the primary key column(s). (So, no NULL values.)*
		3. *Values in primary key columns should never be modified or updated.*
		4. *Primary key values should never be reused. (If a row is deleted from the table, its primary key may not be assigned to any new rows in the future.)*
        Note: If you are combining primary key (more than one primary key column) the individual columns need not have unique values, but the combination must be unique.

What is a **Super Key**
    `Super key is a single key or a group of multiple keys that can uniquely identify tuples in a table.`
    Example: 
![[Screen_Shot_2022-06-28_at_11.05.13_PM.png]]
        Consider that *Id *attribute is unique to every employee. In that case, we can say that the *Id *attribute can uniquely identify the tuples of this table. So, *Id *is a Super key of this table. Note that we can have other Super Keys too in this table.
        For instance – *(Id, Name), (Id, Email), (Id, Name, Email)*, etc. can all be Super keys as they can all uniquely identify the tuples of the table. This is so because of the presence of the *Id *attribute which is able to uniquely identify the tuples. The other attributes in the keys are unnecessary. Nevertheless, they can still identify tuples.

What is a **Candidate Key**
    `Candidate key is a single key or a group of multiple keys that uniquely identify rows in a table it is a subset of Super keys and is devoid of any unnecessary attributes that are not important for uniquely identifying tuples.`
    Note: Candidate keys must be unique and non-null for all tuples. And every table has to have at least one Candidate.
    For example the email and the id columns can be considered as a candidate key.


What is a **Foreign Key**
    `Foreign key is an attribute which is a Primary key in its parent table, but is included as an attribute in another host table.`


What is a **Composite key**
    `A Composite key is a Candidate key or Primary key that consists of more than one attribute.`


What is a **Unique Key**
    `A unique key is a constraint in SQL which helps in uniquely identifying a record in the data table. It is can be considered somewhat similar to the Primary key as both of them guarantees the uniqueness of a record. But unlike primary key, a unique key can accept NULL values and it can be used on more than one column of the data table.`
    Note: A unique key can accept NULL value only once and it cannot have duplicate values.

What is a **Alternate Key**
    `The alternate key is a combination of one or more columns whose values are unique. A table consists of one or more Candidate keys, in which one will be Primary Key and rest of the keys, are called as Alternate keys. Alternate Key is not part of the primary key. There can be one or more alternate keys in a table and contain NULL values unless it is mentioned to be NOT NULL explicitly. The UNIQUE keyword is used to define the alternate key, which indicates the value must be unique. Simple words to say Candidate keys that are not selected as primary key are called Alternate key.`


Comparison of the **SQL Keys**
	- **SQL keys** are used to uniquely identify rows in a table.
	- **SQL keys can either be a single column or a group of columns.**
	- **Super key** is a single key or a group of multiple keys that can uniquely identify tuples in a table.
	- **Super keys** can contain redundant attributes that might not be important for identifying tuples.
	- **Candidate keys** are a subset of **Super keys**. They contain only those attributes which are required to uniquely identify tuples.
	- All** Candidate keys **are **Super keys**. But the vice-versa is not true.
	- **Primary key** is a **Candidate key** chosen to uniquely identify tuples in the table.
	- **Primary key** values should be unique and non-null.
	- There can be multiple **Super keys** and **Candidate keys** in a table, but there can be only one** Primary key** in a table.
	- **Alternate keys** are those **Candidate keys **that were not chosen to be the Primary key of the table.
	- **Composite key** is a **Candidate key** that consists of more than one attribute.
	- **Foreign key** is an attribute which is a **Primary key** in its parent table but is included as an attribute in the host table.
	- **Foreign keys **may accept non-unique and null values.
