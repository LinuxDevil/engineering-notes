---
notion-id: 960df67f-ff84-4175-a456-dd1efad9a129
cover: "[[Understanding Advanced SQL Features.jpeg]]"
---
*constraints, indexes, and triggers*

**Understanding Constraints**

    What is **Constraints**
        Rules that govern how database data is inserted or manipulated.

    **Primary Keys**
        *primary key* is a special <u>constraint</u> used to ensure that values in a column (or set of columns) are unique and never change—in other words, a column (or columns) in a table whose values uniquely identify each row in the table.

        Rules:
			1. No two rows may have the same primary key value.
			2. Every row must have a primary key value. (Columns must not enable `NULL` values.).
			3. The column containing primary key values can never be modified or updated. (Most DBMSs won’t enable this, but if yours does enable doing so, well, don’t!).
			4. Primary key values can never be reused. If a row is deleted from the table, its primary key must not be assigned to any new rows.

        One way to define primary keys is to create them as follows:
        Example 1:
```sql
CREATE TABLE Vendors
(
    vend_id        CHAR(10)    NOT NULL PRIMARY KEY,
    vend_name      CHAR(50)    NOT NULL,
    vend_address   CHAR(50)    NULL,
    vend_city      CHAR(50)    NULL,
    vend_state     CHAR(5)     NULL,
    vend_zip       CHAR(10)    NULL,
    vend_country   CHAR(50)    NULL
);
```
            Analysis:
                In the above example, the keyword `PRIMARY KEY` is added to the table definition so that `vend_id` becomes the primary key.
        Example 2:
```sql
ALTER TABLE Vendors
ADD CONSTRAINT PRIMARY KEY (vend_id);
```
            Analysis:
                Here the same column is defined as the primary key, but the `CONSTRAINT` syntax is used instead. This syntax can be used in `CREATE TABLE` and `ALTER TABLE` statements.

        **Note**: **Keys in SQLite**
            SQLite does not allow keys to be defined using `ALTER TABLE` and requires that they be defined as part of the initial `CREATE TABLE`.

    **Foreign Keys**
        A foreign key is a column in a table <u>whose values must be listed in a primary key in another table</u>. Foreign keys are an extremely important part of ensuring referential integrity. To understand foreign keys, let’s look at an example:
            The `Orders` table contains a single row for each order entered into the system. Customer information is stored in the `Customers` table. Orders in the `Orders` table are tied to specific rows in the `Customers` table by the customer ID. The customer ID is the primary key in the `Customers` table; each customer has a unique ID. The order number is the primary key in the `Orders` table; each order has a unique number.
            The values in the customer ID column in the `Orders` table are not necessarily unique. If a customer has multiple orders, there will be multiple rows with the same customer ID (although each will have a different order number). At the same time, the only values that are valid within the customer ID column in `Orders` are the IDs of customers in the `Customers` table.
            That’s what a foreign key does. In our example, a foreign key is defined on the customer ID column in `Orders` so that the column can accept only values that are in the `Customers` table’s primary key.

        Example 3:
```sql
CREATE TABLE Orders
(
    order_num    INTEGER    NOT NULL PRIMARY KEY,
    order_date   DATETIME   NOT NULL,
    cust_id      CHAR(10)   NOT NULL REFERENCES Customers(cust_id)
);
```
            Analysis:
                Here the table definition uses the `REFERENCES` keyword to state that any values in `cust_id` must be in `cust_id` in the `Customers` table.
        Example 4:
```sql
ALTER TABLE Orders
ADD CONSTRAINT
FOREIGN KEY (cust_id) REFERENCES Customers (cust_id);
```
            Analysis:
                The same thing can be accomplished using `CONSTRAINT` syntax in an `ALTER TABLE` statement.

        **Note**: *cascading delete*. If enabled, this feature deletes all related data when a row is deleted from a table. For example, if cascading delete is enabled and a customer is deleted from the `Customers` table, any related order rows are deleted automatically.

    **Unique Constraints**
        Unique constraints are used to ensure that all data in a column (or set of columns) is unique. They are similar to primary keys, but there are some important <u>**distinctions**</u>:
			1. A table can contain multiple unique constraints, but only one primary key is allowed per table.
			2. Unique constraint columns can contain `NULL` values.
			3. Unique constraint columns can be modified or updated.
			4. Unique constraint column values can be reused.
			5. Unlike primary keys, unique constraints cannot be used to define foreign keys.
        The syntax for unique constraints is similar to that for other constraints. Either the `UNIQUE` keyword is defined in the table definition, or a separate `CONSTRAINT` is used.

    **Check Constraints**
        Check constraints are used to ensure that data in a column (or set of columns) meets a set of criteria that you specify. Common uses of this are:
			1. **Checking minimum or maximum values**—For example, preventing an order of `0` (zero) items (even though 0 is a valid number).
			2. **Specifying ranges**—For example, making sure that a ship date is greater than or equal to today’s date and not greater than a year from now.
			3. **Allowing only specific values**—For example, allowing only `M` or `F` in a gender field.

        Example 5:
```sql
CREATE TABLE OrderItems
(
    order_num     INTEGER    NOT NULL,
    order_item    INTEGER    NOT NULL,
    prod_id       CHAR(10)   NOT NULL,
    quantity      INTEGER    NOT NULL CHECK (quantity > 0),
    item_price    MONEY      NOT NULL
);
```
            Analysis:
                With this constraint in place, any row inserted (or updated) will be checked to ensure that `quantity` is greater than `0`.


**Understanding Indexes**
    Indexes are used to sort data logically to improve the speed of searching and sorting operations. The best way to understand indexes is to envision the index at the back of a book (this book, for example).
    Suppose you want to find all occurrences of the word *datatype* in this book. The simple way to do this would be to turn to page 1 and scan every line of every page looking for matches. Although that works, it is obviously not a workable solution.
    Scanning a few pages of text might be feasible, but scanning an entire book in that manner is not. As the amount of text to be searched increases, so does the time it takes to pinpoint the desired data.
    That is why books have indexes. An index is an alphabetical list of words with references to their locations in the book. To search for *datatype*, you find that word in the index to determine what pages it appears on. Then, you turn to those specific pages to find your matches.
    What makes an index work? Simply, it is the fact that it is sorted correctly. The difficulty in finding words in a book is not the amount of content that must be searched; rather, it is the fact that the content is not sorted by word. If the content is sorted like a dictionary, an index is not needed (which is why dictionaries don’t have indexes).

    Database indexes work in much the same way. Primary key data is always sorted; that’s just something the DBMS does for you. Retrieving specific rows by primary key, therefore, is always a fast and efficient operation.
    Searching for values in other columns is usually not as efficient, however. For example, what if you want to retrieve all customers who live in a specific state? Because the table is not sorted by state, the DBMS must read every row in the table (starting at the very first row) looking for matches, just as you would have to do if you were trying to find words in a book without using an index.
    The solution is to use an index. You may define an index on one or more columns so that the DBMS keeps a sorted list of the contents for its own use. After an index is defined, the DBMS uses it in much the same way as you would use a book index. It searches the sorted index to find the location of any matches and then retrieves those specific rows.

    Indexing Warning
		1. Indexes improve the performance of retrieval operations, but they degrade the performance of data insertion, modification, and deletion. When these operations are executed, the DBMS has to update the index dynamically.
		2. Index data can take up lots of storage space.
		3. Not all data is suitable for indexing. Data that is not sufficiently unique (State, for example) will not benefit as much from indexing as data that has more possible values (First Name or Last Name, for example).
		4. Indexes are used for data filtering and for data sorting. If you frequently sort data in a specific order, that data might be a candidate for indexing.
		5. Multiple columns can be defined in an index (for example, State plus City). Such an index will be of use only when data is sorted in State plus City order. (If you want to sort by City, this index would not be of any use.)
    Example 6:
        Indexes are created with the `CREATE INDEX` statement (which varies dramatically from one DBMS to another). The following statement creates a simple index on the `Products` table’s product name column:
```sql
CREATE INDEX prod_name_ind
ON Products (prod_name);
```
        Analysis:
            Every index must be uniquely named. Here the name `prod_name_ind` is defined after the keywords `CREATE INDEX`. `ON` is used to specify the table being indexed, and the columns to include in the index (just one in this example) are specified in parentheses after the table name.

**Understanding Triggers**
    Triggers are special stored procedures that are executed automatically when specific database activity occurs. Triggers might be associated with `INSERT`, `UPDATE`, and `DELETE` operations (or any combination thereof) on specific tables.
    Unlike stored procedures (which are simply stored SQL statements), triggers are tied to individual tables. A trigger associated with `INSERT` operations on the `Orders` table will be executed only when a row is inserted into the `Orders` table. Similarly, a trigger on `INSERT` and `UPDATE` operations on the `Customers` table will be executed only when those specific operations occur on that table.
    Within triggers, your code has <u>access</u> to the following:
		1. All new data in `INSERT` operations.
		2. All new data and old data in `UPDATE` operations.
		3. Deleted data in `DELETE` operations.
    Triggers can be executed before or after a specified operation is performed.

    Trigger uses: 
		1. Ensuring data consistency; for example, converting all state names to uppercase during an `INSERT` or `UPDATE` operation.
		2. Performing actions on other tables based on changes to a table; for example, writing an audit trail record to a log table each time a row is updated or deleted.
		3. Performing additional validation and rolling back data if needed; for example, making sure a customer’s available credit has not been exceeded and blocking the insertion if it has.
		4. Calculating computed column values or updating time stamps.

    Example 7:
```sql
CREATE TRIGGER customer_state
AFTER INSERT OR UPDATE
FOR EACH ROW
BEGIN
UPDATE Customers
SET cust_state = Upper(cust_state)
WHERE Customers.cust_id = :OLD.cust_id
END;
```
        Analysis:
            The following example creates a trigger that converts the `cust_state` column in the `Customers` table to uppercase on all `INSERT` and `UPDATE` operations.

    **Note**: **Constraints Are Faster Than Triggers**
        As a rule, constraints are processed more quickly than triggers, so whenever possible, use constraints instead.

