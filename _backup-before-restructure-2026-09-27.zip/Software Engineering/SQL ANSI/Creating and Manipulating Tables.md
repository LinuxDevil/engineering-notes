---
notion-id: 2c60dffa-1dfd-45fd-b448-7b9d0251c0ee
cover: "[[Creating and Manipulating Tables.jpeg]]"
---

**Creating Tables**
    SQL is not used just for table data manipulation. Rather, SQL can be used to perform all database and table operations, including the creation and manipulation of tables themselves.
    There are generally two ways to create database tables:
		1. Most DBMSs come with an administration tool that you can use to create and manage database tables interactively.
		2. Tables may also be manipulated directly with SQL statements.

    To create tables programmatically, you use the `CREATE TABLE` SQL statement. It is worth noting that when you use interactive management tools, you are actually using SQL statements. Instead of your writing these statements, however, the interface generates and executes the SQL seamlessly for you (the same is true for changes to existing tables).

**Basic Table Creation**
    To create a table using `CREATE TABLE`, you must specify the following information:
		1. The name of the new table specified after the keywords `CREATE TABLE`.
		2. The name and definition of the table columns separated by commas.
		3. Some DBMSs require that you also specify the table location (as in which specific database it is to be created).

    Example 1:
        The following SQL statement creates the `Products` table used throughout this book:
```sql
CREATE TABLE Products
(
    prod_id      CHAR(10)        NOT NULL,
    vend_id      CHAR(10)        NOT NULL,
    prod_name    CHAR(254)       NOT NULL,
    prod_price   DECIMAL(8,2)    NOT NULL,
    prod_desc    VARCHAR(1000)   NULL
);
```
        Analysis:
            As you can see in the above statement, the table name is specified immediately following the `CREATE TABLE` keywords. The actual table definition (all the columns) is enclosed within parentheses. The columns themselves are separated by commas. This particular table is made up of five columns. Each column definition starts with the column name (which must be unique within the table), followed by the column’s datatype.


**Working with **`**NULL**`** Values**
    Every table column is either a `NULL` column or a `NOT NULL` column, and that state is specified in the table definition at creation time. Take a look at the following example:
    Example 2:
```sql
CREATE TABLE Orders
(
    order_num     INTEGER     NOT NULL,
    order_date    DATETIME    NOT NULL,
    cust_id       CHAR(10)    NOT NULL
);
```
    Analysis:
        This statement creates the `Orders` table used throughout this book. `Orders` contains three columns: the order number, order date, and customer ID. All three columns are required, and so each contains the keyword `NOT NULL`. This will prevent the insertion of columns with no value. If someone tries to insert no value, an error will be returned, and the insertion will fail.

    This next example creates a table with a mixture of `NULL` and `NOT NULL` columns:
    Example 3
```sql
CREATE TABLE Vendors
(
    vend_id        CHAR(10)    NOT NULL,
    vend_name      CHAR(50)    NOT NULL,
    vend_address   CHAR(50)    ,
    vend_city      CHAR(50)    ,
    vend_state     CHAR(5)     ,
    vend_zip       CHAR(10)    ,
    vend_country   CHAR(50)
);
```
    Analysis:
        This statement creates the `Vendors` table used throughout this book. The vendor ID and vendor name columns are both required and are, therefore, specified as `NOT NULL`. The five remaining columns all allow `NULL` values, and so `NOT NULL` is not specified. `NULL` is the default setting, so if `NOT NULL` is not specified, `NULL` is assumed.

**Specifying Default Values**
    SQL enables you to specify default values to be used if no value is specified when a row is inserted. Default values are specified using the `DEFAULT` keyword in the column definitions in the `CREATE TABLE` statement.

    Example 4:
```sql
CREATE TABLE OrderItems
(
    order_num     INTEGER         NOT NULL,
    order_item    INTEGER         NOT NULL,
    prod_id       CHAR(10)        NOT NULL,
    quantity      INTEGER         NOT NULL    DEFAULT 1,
    item_price    DECIMAL(8,2)    NOT NULL
);
```
        Analysis:
            This statement creates the `OrderItems` table that contains the individual items that make up an order. (The order itself is stored in the `Orders` table.) The `quantity` column contains the quantity for each item in an order. In this example, adding the text `DEFAULT 1` to the column description instructs the DBMS to use a quantity of `1` if no quantity is specified.
            Default values are often used to store values in date or time stamp columns. For example, the system date can be used as a default date by specifying the function or variable used to refer to the system date. For example, MySQL users may specify `DEFAULT CURRENT_DATE()`, while Oracle users may specify `DEFAULT SYSDATE`, and SQL Server users may specify `DEFAULT GETDATE()`. Unfortunately, the command used to obtain the system date is different in just about every DBMS. [Table 17.1](https://learning.oreilly.com/library/view/sams-teach-yourself/9780135182925/ch17.xhtml#table17-1) lists the syntax for some DBMSs. If yours is not listed here, consult your DBMS documentation.


**Updating Tables**
    To update table definitions, you use the `ALTER TABLE` statement. Although all DBMSs support `ALTER TABLE`, what they allow you to alter varies dramatically from one to another. Here are some points to consider when using `ALTER TABLE`:
		1. Ideally, tables should never be altered after they contain data. You should spend sufficient time anticipating future needs during the table design process so that extensive changes are not required later on.
		2. All DBMSs allow you to add columns to existing tables, although some restrict the datatypes that may be added (as well as `NULL` and `DEFAULT` usage).
		3. Many DBMSs do not allow you to remove or change columns in a table.
		4. Most DBMSs allow you to rename columns.
		5. Many DBMSs restrict the kinds of changes you can make on columns that are populated and enforce fewer restrictions on unpopulated columns.
    To change a table using `ALTER TABLE`, you must specify the following information:
		1. The name of the table to be altered after the keywords `ALTER TABLE`. (The table must exist; otherwise, an error will be generated.)
		2. The list of changes to be made.

    Example 5:
```sql
ALTER TABLE Vendors
ADD vend_phone CHAR(20);
```
        Analysis:
            This statement adds a column named `vend_phone` to the `Vendors` table. The datatype must be specified.
            Other `ALTER` operations—for example, changing or dropping columns, or adding constraints or keys—use a similar syntax.


**Note**: SQLite limits the operations that may be performed using `ALTER TABLE`. One of the most important limitations is that it does not support the use of `ALTER TABLE` to define primary and foreign keys; these must be specified at initial `CREATE TABLE` time.

**Deleting Tables**
    Deleting tables (actually removing the entire table, not just the contents) is very easy—arguably too easy. Tables are deleted using the `DROP TABLE` statement:
    Example 6:
```sql
DROP TABLE CustCopy;
```
        Analysis:
            This statement deletes the `CustCopy` table. There is no confirmation, nor is there an undo. Executing the statement will permanently remove the table.

**Renaming Tables**
    Table renaming is supported differently by each DBMS. There is no hard-and-fast standard for this operation. DB2, MariaDB, MySQL, Oracle, and PostgreSQL users can use the `RENAME` statement. SQL Server users can use the supplied `sp_rename` stored procedure. SQLite supports the renaming of tables via the `ALTER TABLE` statement.