---
notion-id: da098971-cce8-4832-b073-8065da8f468f
cover: "[[Using Data Manipulation Functions.jpeg]]"
---

**Understanding Functions**
    Like almost any other computer language, SQL supports the use of functions to manipulate data. Functions are operations that are usually performed on data, usually to facilitate conversion and manipulation, and they are an important part of your SQL toolbox.
    An example of a function is `RTRIM()`, which we used in the last lesson to trim spaces from the end of a string.

    Unlike SQL statements (for example, `SELECT`), which for the most part are supported by all DBMSs equally, functions tend to be very DBMS specific. In fact, very few functions are supported identically by all major DBMSs. Although all types of functionality are usually available in each DBMS, the function names or syntax can differ greatly.

    Table lists three commonly needed functions and their syntax as employed by various DBMSs:
    ![[Functions between DBMS.base]]


What is a **Portable Code**
    Code that is written so that it will run on multiple different systems.


**Using Functions**
    Function Types:
		1. Text functions are used to manipulate strings of text (for example, trimming or padding values and converting values to upper- and lowercase).
		2. Numeric functions are used to perform mathematical operations on numeric data (for example, returning absolute numbers and performing algebraic calculations).
		3. Date and time functions are used to manipulate date and time values and to extract specific components from these values (for example, returning differences between dates and checking date validity).
		4. Formatting functions are used to generate user-friendly outputs (for example, displaying dates in local languages and formats, or currencies with the right symbols and comma placement).
		5. System functions return information specific to the DBMS being used (for example, returning user login information).


**Text Manipulation Functions**

Example 1:

```sql
SELECT vend_name, UPPER(vend_name) AS vend_name_upcase
FROM Vendors
ORDER BY vend_name;
```

Analysis:
    As you can see, `UPPER()` converts text to uppercase, and so in this example each vendor is listed twice—first exactly as stored in the Vendors table, and then converted to uppercase as column `vend_name_upcase`.


Commonly Used Text Manipulation Functions

![[Text Manipulation Functions.base]]

What is `SOUNDEX`
    is an algorithm that converts any string of text into an alphanumeric pattern describing the phonetic representation of that text. `SOUNDEX` takes into account similar-sounding characters and syllables, enabling strings to be compared by how they sound rather than how they have been typed. Although `SOUNDEX` is not a SQL concept, most DBMSs do offer `SOUNDEX` support.


**Date and Time Manipulation Functions**

Example 2:

```sql
SELECT order_num
FROM Orders
WHERE DATE_PART('year', order_date) = 2020;
/* Or, you can use */
SELECT order_num
FROM Orders
WHERE EXTRACT(year FROM order_date) = 2020;
```

Analysis:
    In this example, the `EXTRACT()` function is used to extract part of the date with `year` specifying what part of the date to extract. The returned value is then compared to `2020`.

Example 3:

```sql
SELECT order_num
FROM Orders
WHERE order_date BETWEEN to_date('2020-01-01', 'yyyy-mm-dd')
 AND to_date('2020-12-31', 'yyyy-mm-dd');
```

Analysis:
    In this example, Oracle’s `to_date()` function is used to convert two strings to dates. One contains the date January 1, 2020, and the other contains the date December 31, 2020. A standard `BETWEEN` operator is used to find all orders between those two dates. It is worth noting that this same code would not work with SQL Server because it does not support the `to_date()` function. However, if you replaced `to_date()` with `DATEPART()`, you could indeed use this type of statement.

    DB2, MySQL, and MariaDB have all sorts of date manipulation functions, but not `DATEPART()`. DB2, MySQL, and MariaDB users can use a function named `YEAR()` to extract the year from a date:
```sql
SELECT order_num
FROM Orders
WHERE YEAR(order_date) = 2020;
```
    SQLite is a little trickier:
```sql
SELECT order_num
FROM Orders
WHERE strftime('%Y', order_date) = '2020';
```
    The example shown here extracted and used part of a date (the year). To filter by a specific month, you could use the same process, specifying an AND operator and both year and month comparisons.

**Numeric Manipulation Functions**

Commonly Used Numeric Manipulation Functions

![[Numeric Functions.base]]

