---
notion-id: 80484b04-30d4-483b-8404-ddaee4593307
base: "[[Functions between DBMS.base]]"
Syntax: DB2, Oracle, PostgreSQL, and SQLite use SUBSTR(). MariaDB, MySQL, and SQL Server use SUBSTRING().
---
