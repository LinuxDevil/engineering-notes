---
notion-id: 306a9bec-fdf8-49cf-bbe9-cde51e70415b
base: "[[Functions between DBMS.base]]"
Syntax: DB2 and PostgreSQL use CURRENT_DATE. MariaDB and MySQL use CURDATE(). Oracle uses SYSDATE. SQL Server uses GETDATE(). SQLite uses DATE().
---
