---
notion-id: 605e2ab1-7750-478c-bf01-2ebc289fc76f
base: "[[Functions between DBMS.base]]"
Syntax: Oracle uses multiple functions, one for each conversion type. DB2, PostgreSQL, and SQL Server use CAST(). MariaDB, MySQL, and SQL Server use CONVERT().
---
