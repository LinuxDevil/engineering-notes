---
notion-id: f8523a0d-202a-4b20-9655-95f62ef23dc4
base: "[[Text Manipulation Functions.base]]"
Description: Converts string to uppercase
---
