---
notion-id: 6e730349-0895-404e-ac5a-d0b34550cf3b
base: "[[Text Manipulation Functions.base]]"
Description: Converts string to lowercase
---
