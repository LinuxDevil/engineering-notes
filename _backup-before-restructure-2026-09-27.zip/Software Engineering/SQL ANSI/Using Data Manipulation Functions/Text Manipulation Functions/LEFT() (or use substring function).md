---
notion-id: a2091f68-1f43-48f0-bcbc-03beeb4903e8
base: "[[Text Manipulation Functions.base]]"
Description: Returns characters from left of string
---
