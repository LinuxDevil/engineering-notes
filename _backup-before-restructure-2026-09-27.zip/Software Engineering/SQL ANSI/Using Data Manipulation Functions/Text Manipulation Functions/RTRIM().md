---
notion-id: 8ac44ff6-16fa-44a9-885d-e84dc35f15e4
base: "[[Text Manipulation Functions.base]]"
Description: Trims white space from right of string
---
