---
notion-id: 3b8c1bd6-dbda-49c2-ae49-d914cc53e4d0
base: "[[Text Manipulation Functions.base]]"
Description: Returns a string’s SOUNDEX value
---
