---
notion-id: 1199af1a-c548-48c7-a8ac-a49080baf17e
base: "[[Text Manipulation Functions.base]]"
Description: Extracts part of a string
---
