---
notion-id: 690359b6-b2f4-42c1-abc2-3a750f8d1356
base: "[[Text Manipulation Functions.base]]"
Description: Returns the length of a string
---
