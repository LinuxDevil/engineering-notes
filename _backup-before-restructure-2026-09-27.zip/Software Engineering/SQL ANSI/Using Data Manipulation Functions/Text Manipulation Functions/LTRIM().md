---
notion-id: 72120dd3-2c20-48e8-9456-72e4d3a3a162
base: "[[Text Manipulation Functions.base]]"
Description: Trims white space from left of string
---
