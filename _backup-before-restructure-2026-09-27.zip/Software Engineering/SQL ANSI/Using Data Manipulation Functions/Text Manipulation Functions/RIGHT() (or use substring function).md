---
notion-id: c58502df-1ccb-4dea-9fd0-d82edd21e781
base: "[[Text Manipulation Functions.base]]"
Description: Returns characters from right of string
---
