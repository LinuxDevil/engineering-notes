---
notion-id: cb9f82f7-d1db-4adf-8abd-d22b2f079f3c
base: "[[Numeric Functions.base]]"
Function: COS()
---
