---
notion-id: 394eebbe-5883-4407-8f4b-dea0e0fd9779
base: "[[Numeric Functions.base]]"
Function: TAN()
---
