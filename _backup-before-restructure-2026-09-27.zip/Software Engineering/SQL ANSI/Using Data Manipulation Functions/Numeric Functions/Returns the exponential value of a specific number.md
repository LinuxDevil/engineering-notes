---
notion-id: 56aae238-24b8-4576-9fcf-da739048b383
base: "[[Numeric Functions.base]]"
Function: EXP()
---
