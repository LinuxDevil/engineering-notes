---
notion-id: fcf98187-4531-4485-9d97-5d13ac13cae7
base: "[[Numeric Functions.base]]"
Function: SQRT()
---
