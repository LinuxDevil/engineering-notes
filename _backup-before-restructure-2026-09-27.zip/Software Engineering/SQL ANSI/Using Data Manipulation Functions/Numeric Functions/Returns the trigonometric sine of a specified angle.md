---
notion-id: 9d2a6b55-1a3e-4178-b561-1a91ad55ef9e
base: "[[Numeric Functions.base]]"
Function: SIN()
---
