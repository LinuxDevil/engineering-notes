---
notion-id: a84339ad-e0e8-4844-bb2a-461c88a82921
base: "[[Numeric Functions.base]]"
Function: ABS()
---
