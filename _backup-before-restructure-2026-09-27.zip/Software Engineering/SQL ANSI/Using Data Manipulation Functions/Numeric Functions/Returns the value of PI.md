---
notion-id: 6471bb6b-fbee-4fcb-aa74-e6af12438dad
base: "[[Numeric Functions.base]]"
Function: PI()
---
