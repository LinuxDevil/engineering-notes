---
notion-id: fb64e481-5fb9-4b0b-9fba-b10651484724
cover: "[[SQL Table Partitioning.jpeg]]"
---

## **Why partition a table?**

Table partitioning allows to split one large table into smaller ones bringing the following benefits:

- Smaller tables are faster both for reading and writing.
- You can very efficiently drop the whole partition instead of deleting data row by row.
- Because PostgreSQL knows how to prune unused partitions, you can use partitions as a crude index. For example, by paritioning a table by date, you may not need an index on the date field any more and use a sequential scan instead.
- Rarely used partitions can be moved to a cheaper storage.

