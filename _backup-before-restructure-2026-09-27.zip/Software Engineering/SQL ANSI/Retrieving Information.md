---
notion-id: 298658d1-093a-4543-b4ce-68fe06d26fdb
cover: "[[Retrieving Information.jpeg]]"
---
## The `select` keyword

Basic Structure: `SELECT `<u>`*what*`</u>` FROM `<u>`*where*`</u>

Example 1: 

```sql
SELECT prod_name
FROM Products;
```

Analysis:
    The previous statement uses the `SELECT` statement to retrieve a single column called `prod_name` from the `Products` table. The desired column name is specified right after the `SELECT` keyword, and the `FROM` keyword specifies the name of the table from which to retrieve the data.


Example 2:

```sql
SELECT prod_id, prod_name, prod_price
FROM Products;
```

Analysis:
    Just as in the prior example, this statement uses the `SELECT` statement to retrieve data from the `Products` table. In this example, three column names are specified, each separated by a comma.

The `DISTINCT` Keyword:
    Used to return only unique values

Example 3:

```sql
SELECT DISTINCT vend_id
FROM Products;
```

Analysis:
    `SELECT DISTINCT vend_id` tells the DBMS to only return distinct (unique) `vend_id` rows, and so only three rows are returned, as seen in the following output. If used, the `DISTINCT` keyword must be placed directly in front of the column names.


The `LIMIT` Keyword:
    Used to limit the select return to only a number

Example 4:

```sql
SELECT prod_name
FROM Products
LIMIT 5;
```

Analysis: 
    The previous statement uses the `SELECT` statement to retrieve a single column. `LIMIT 5` instructs the supported DBMSs to return no more than five rows. The output from this statement is shown in the following code.
