---
notion-id: 58e09b83-7b01-4df5-a230-c457ded1f39d
cover: "[[Advanced  Filtering Data.jpeg]]"
---
Combing `WHERE` with `NOT`, `IN`, `AND` and `OR` operators.

What is an **Operator**
    A special keyword used to join or change clauses within a `WHERE` clause. Also known as logical operators.

**Using the **`**AND**`** Operator**
    `AND` A keyword used in a `WHERE` clause to specify that only rows matching all the specified conditions should be retrieved.

Example 1:

```sql
SELECT prod_id, prod_price, prod_name
FROM Products
WHERE vend_id = 'DLL01' AND prod_price <= 4;
```

Analysis:
    The above SQL statement retrieves the product name and price for all products made by vendor `DLL01` as long as the price is $4 or less. The `WHERE` clause in this `SELECT` statement is made up of two conditions, and the keyword `AND` is used to join them. `AND` instructs the database management system software to return only rows that meet all the conditions specified. If a product is made by vendor `DLL01`, but it costs more than $4, it is not retrieved. Similarly, products that cost less than $4 that are made by a vendor other than the one specified are not to be retrieved.

**Using the **`**OR**`** Operator**
    `OR` A keyword used in a `WHERE` clause to specify that any rows matching either of the specified conditions should be retrieved.

Example 2:

```sql
SELECT prod_id, prod_price, prod_name
FROM Products
WHERE vend_id = 'DLL01' OR vend_id = 'BRS01';
```

Analysis:
    The above SQL statement retrieves the product name and price for any products made by either of the two specified vendors. The OR operator tells the DBMS to match either condition, not both. If an `AND` operator were used here, no data would be returned (as it would create a `WHERE` clause that would match no rows).


**Understanding Order of Evaluation**

Example 3:

```sql
SELECT prod_name, prod_price
FROM Products
WHERE vend_id = 'DLL01' OR vend_id = 'BRS01'
      AND prod_price >= 10;
```

Analysis:
    Look at the results above. Four of the rows returned have prices less than $10—so, obviously, the rows were not filtered as intended. Why did this happen? The answer is the order of evaluation. SQL (like most languages) processes `AND` operators before `OR` operators. When SQL sees the above `WHERE` clause, it reads *any products costing $10 or more made by vendor* `BRS01`*, and any products made by vendor* `DLL01` *regardless of price*. In other words, because AND ranks higher in the order of evaluation, the wrong operators were joined together.
    The solution to this problem is to use parentheses to explicitly group related operators. Take a look at the following Example 4.

Example 4:

```sql
SELECT prod_name, prod_price
FROM Products
WHERE (vend_id = 'DLL01' OR vend_id = 'BRS01')
      AND prod_price >= 10;
```

Analysis:
    The only difference between this `SELECT` statement and the earlier one is that, in this statement, the first two `WHERE` clause conditions are enclosed within parentheses. As parentheses have a higher order of evaluation than either `AND` or `OR` operators, the DBMS first filters the OR condition within those parentheses. The SQL statement then becomes *any products made by either vendor* `DLL01` *or vendor* `BRS01` *costing $10 or greater*, which is exactly what we want.

**Using the **`**IN**`** Operator**
    `IN` A keyword used in a WHERE clause to specify a list of values to be matched using an OR comparison.


Example 5:

```sql
SELECT prod_name, prod_price
FROM Products
WHERE vend_id  IN ('DLL01','BRS01')
ORDER BY prod_name;
```

Analysis:
    The `SELECT` statement retrieves all products made by vendor `DLL01` and vendor `BRS01`. The `IN` operator is followed by a comma-delimited list of valid values, and the entire list must be enclosed within parentheses.
    If you are thinking that the `IN` operator accomplishes the same goal as `OR`, you are right. The following SQL statement accomplishes the exact same thing as the example above.
```sql
SELECT prod_name, prod_price
FROM Products
WHERE vend_id  = 'DLL01' OR vend_id = 'BRS01'
ORDER BY prod_name;
```

Why the `IN` operator ?
	1. When you are working with long lists of valid options, the `IN` operator syntax is far cleaner and easier to read.
	2. The order of evaluation is easier to manage when `IN` is used in conjunction with other `AND` and OR operators.
	3. `IN` operators almost always execute more quickly than lists of `OR` operators (although you’ll not see any performance difference with very short lists like the ones we’re using here).
	4. The biggest advantage of `IN` is that the `IN` operator can contain another `SELECT` statement, enabling you to build highly dynamic `WHERE` clauses.


**Using the **`**NOT**`** Operator**
    `NOT` A keyword used in a WHERE clause to specify a list of values to be matched using an OR comparison.


Example 6:

```sql
SELECT prod_name
FROM Products
WHERE NOT vend_id = 'DLL01'
ORDER BY prod_name;
```

Analysis:
    The `NOT` here negates the condition that follows it; so instead of matching  `vend_id` to `DLL01`, the DBMS matches `vend_id` to anything that is not `DLL01`.

Example 7:

```sql
SELECT prod_name
FROM Products
WHERE vend_id  <> 'DLL01'
ORDER BY prod_name;
```

Analysis:
    Why use `NOT?` Well, for simple `WHERE` clauses such as the ones shown here, there really is no advantage to using `NOT`. `NOT` is useful in more complex clauses. For example, using `NOT` in conjunction with an `IN` operator makes it simple to find all rows that do not match a list of criteria. 