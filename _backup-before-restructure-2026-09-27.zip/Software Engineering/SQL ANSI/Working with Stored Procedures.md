---
notion-id: 7f7f2cd8-d6ee-4c7c-bc92-4c9b7a6b7215
cover: "[[Working with Stored Procedures.jpeg]]"
---

**Understanding Stored Procedures**
    Stored Procedures scenarios:
		1. To process an order, checks must be made to ensure that items are in stock.
		2. If items are in stock, they need to be reserved so that they are not sold to anyone else, and the available quantity must be reduced to reflect the correct amount in stock.
		3. Any items not in stock need to be ordered; this requires some interaction with the vendor.
		4. The customer needs to be notified as to which items are in stock (and can be shipped immediately) and which are backordered.

    What is **Stored Procedures** 
        Stored procedures are simply collections of one or more SQL statements saved for future use. You can think of them as <u>batch files</u>, although in truth they are more than that.

    **Note**: SQLite does not support stored procedures.


**Understanding Why to Use Stored Procedures**
	1. To simplify complex operations (as seen in the previous example) by encapsulating processes into a single easy-to-use unit.
	2. To ensure data consistency by not requiring that a series of steps be created over and over. If all developers and applications use the same stored procedure, then the same code will be used by all.
	3. To prevent errors; this is an extension of the preceding reason. The more steps that need to be performed, the more likely it is that errors will be introduced. Preventing errors ensures data consistency.
	4. To simplify change management. If tables, column names, or business logic (or just about anything) changes, then only the stored procedure code needs to be updated, and no one else will even need to be aware that changes were made.
	5. To ensure security; this is an extension of the preceding reason. Restricting access to underlying data via stored procedures reduces the chance of data corruption (unintentional or otherwise).
	6. To do less work to process the command. Because stored procedures are usually stored in a compiled form, the DBMS has to do less work. This results in improved performance.
	7. To write code that is more powerful and flexible. There are SQL language elements and features that are available only within single requests. Stored procedures can use them for this reason.

**Note**: Stored procedure syntax <u>varies dramatically</u> from one DBMS to the next. In fact, it is close to impossible to write truly portable stored procedures. Having said that, the stored procedure calls themselves (their names and how data is passed to them) can be kept relatively portable so that if you need to change to another DBMS, at least your client application code may not need changing.

**Executing Stored Procedures**
    The SQL statement to execute a stored procedure is simply `EXECUTE`. `EXECUTE` takes the name of the stored procedure and any parameters that need to be passed to it.
    Example 1:
```sql
EXECUTE AddNewProduct('JTS01',
'Stuffed Eiffel Tower',
6.49,
'Plush stuffed toy with
the text La Tour Eiffel in red white and blue');
```
        Analysis:
            Here a stored procedure named `AddNewProduct` is executed; it adds a new product to the `Products` table. `AddNewProduct` takes four parameters: the vendor ID (the primary key from the `Vendors` table), product name, price, and description. These four parameters match four expected variables within the stored procedure (defined as part of the stored procedure itself). The stored procedure adds a new row to the `Products` table and assigns these passed attributes to the appropriate columns.
            In the `Products` table, you’ll notice that another column needs a value—the `prod_id` column, which is the table’s primary key. Why was this value not passed as an attribute to the stored procedure? To ensure that IDs are generated properly, it is safer to have that process automated (and not rely on end users). That is why a stored procedure is used in this example. This is what this stored procedure does:
				1. It validates the passed data, ensuring that all four parameters have values.
				2. It generates a unique ID to be used as the primary key.
				3. It inserts the new product into the `Products` table, storing the generated primary key and passed data in the appropriate columns.


**Creating Stored Procedures**
    Example 2:
```sql
CREATE PROCEDURE MailingListCount
AS
DECLARE @cnt INTEGER
SELECT @cnt = COUNT(*)
FROM Customers
WHERE NOT cust_email IS NULL;
RETURN @cnt;
```
        Analysis:
            This stored procedure takes no parameters at all. The calling application retrieves the value by using SQL Server’s return code support. Here a local variable named `@cnt` is declared using the `DECLARE` statement (all local variables in SQL Server are named starting with a `@`). This variable is then used in the `SELECT` statement so that it contains the value returned by the `COUNT()` function. Finally, the `RETURN` statement is used to return the count to the calling application as `RETURN @cnt`.
    Example 3:
```sql
DECLARE @ReturnValue INT
EXECUTE @ReturnValue=MailingListCount;
SELECT @ReturnValue;
```
        Analysis:
            This code declares a variable to hold whatever the stored procedure returns, executes the stored procedure, and then uses a `SELECT` to display the returned value.

    Example 4:
```sql
CREATE PROCEDURE NewOrder @cust_id CHAR(10)
AS
-- Declare variable for order number
DECLARE @order_num INTEGER
-- Get current highest order number
SELECT @order_num=MAX(order_num)
FROM Orders
-- Determine next order number
SELECT @order_num=@order_num+1
-- Insert new order
INSERT INTO Orders(order_num, order_date, cust_id)
VALUES(@order_num, GETDATE(), @cust_id)
-- Return order number
RETURN @order_num;
```
        Analysis:
            This stored procedure creates a new order in the `Orders` table. It takes a single parameter—the ID of the customer placing the order. The other two table columns, the order number and order date, are generated automatically within the stored procedure itself. The code first declares a local variable to store the order number. Next, the current highest order number is retrieved (using a `MAX()` function) and incremented (using a `SELECT` statement). Then the order is inserted with an `INSERT` statement using the newly generated order number, the current system date (retrieved using the `GETDATE()` function), and the passed customer ID. Finally, the order number (which is needed to process order items) is returned as `RETURN @order_num`. Notice that the code is commented; this should always be done when writing stored procedures.



## **What are Stored Procedures in PostgreSQL?**

Stored procedures in PostgreSQL are a collection of SQL commands manipulated to achieve a particular operation.

The benefits of using PostgreSQL Stored Procedures are immense. Just imagine deploying a new function every time a new use case arises. Instead, creating a stored procedure to later use in an app makes sense. Likewise, it is also an essential step while creating user-defined functions.

## **How to CREATE OR REPLACE PostgreSQL Stored Procedures?**

In PostgreSQL, **CREATE OR REPLACE PROCEDURE** exists to create a new procedure or deploy a new definition in place of an existing one. To be able to CREATE OR REPLACE PROCEDURE, for a user in PostgreSQL, having a **USAGE privilege** on the language is a prerequisite.

The syntax to CREATE or REPLACE PostgreSQL Stored Procedures is given below:

```plain text
CREATE [ OR REPLACE ] PROCEDURE
    name ( [ [ argmode ] [ argname ] argtype [ { DEFAULT | = } default_expr ] [, ...] ] )
  { LANGUAGE lang_name
    | TRANSFORM { FOR TYPE type_name } [, ... ]
    | [ EXTERNAL ] SECURITY INVOKER | [ EXTERNAL ] SECURITY DEFINER
    | SET configuration_parameter { TO value | = value | FROM CURRENT }
    | AS 'definition'
    | AS 'obj_file', 'link_symbol'
    | sql_body
  }
```

1. A procedure is generated in schema if a schema name is provided. Otherwise, the existing schema captures the newly built one within itself.
2. CREATE or REPLACE PROCEDURE can be used to change/replace the existing definition of the current procedure. The ownership and permissions will not change.
3. You must have USAGE privilege on the argument types to build a procedure.
4. The user who creates the procedure becomes the procedure’s owner.

### **Workflow Example**

Let’s use a ***stored_Procedure_Prac***** **table to understand the PostgreSQL Stored Procedure better. We will use an online editor, [OneCompiler](https://onecompiler.com/postgresql/3xk8tb9w4), to write and run PostgreSQL queries for demo purposes.

**Step 1:** Create a table with the following inputs, as shown in the code block below.

```plain text
create table stored_Procedure_Prac (
    id int generated by default as identity,
    name varchar(100) not null,
    balance dec(15, 2) not null,
    primary key(id)
);

insert into stored_Procedure_Prac(name, balance)
values('Don', 400000);

insert into stored_Procedure_Prac(name, balance)
values('Bob', 400000);
```

**Step 2:** Now run a SQL query to show the table.

```plain text
select * from stored_Procedure_Prac;
```

The following shall be the result:

![[image-7_1600384369c.png]]

Image Source: Self

**Step 3:** The query below produces a stored procedure called *prac_transfer*, which transfers a specific amount of money from one account to another.

```plain text
create or replace procedure prac_transfer(
   sender int,
   receiver int,
   amount dec
)
language plpgsql
as $$
begin
    -- subtracting the amount from the sender's account
    update accounts
    set balance = balance - amount
    where id = sender;

    -- adding the amount to the receiver's account
    update accounts
    set balance = balance + amount
    where id = receiver;

    commit;
end;$$;
```

**Step 4: **Now call a stored procedure. Use the below-given query; a CALL statement is used.

```plain text
call prac_transfer(1, 2, 1000);
```

The result would look like this:

![[image-9_1600406d03b.png]]

Image Source: Self

**Step 5: **Now verify the results by running the following query.

```plain text
SELECT * FROM stored_Procedure_Prac;
```

![[image-10_160041025f2.png]]

## **PostgreSQL Stored Procedures vs Functions**

A function returns a result, but a stored procedure does not. The reason is simple: the sole purpose of a stored procedure is to proceed with an action to complete it. Post that, the control is returned to the caller.

Using an example query, let’s distinguish:

**PostgreSQL Stored Procedures’ Query**

```plain text
CREATE PROCEDURE deactivate_unpaid_accounts()
LANGUAGE SQL
AS $$
  UPDATE accounts SET active = false WHERE balance < 0;
$$;
```

For calling purposes, post PostgreSQL 11, we use the CALL statement as shown below:

```plain text
CALL deactivate_unpaid_accounts();
```

**PostgreSQL Function’s Query**

```plain text
CREATE FUNCTION deactivate_unpaid_accounts() RETURNS void
LANGUAGE SQL
AS $$
  UPDATE accounts SET active = false WHERE balance < 0;
$$;
```

For calling purposes, we used the SELECT statement, not CALL statement, as shown below:

```plain text
SELECT deactivate_unpaid_accounts();
```

## **How Do PostgreSQL Stored Procedures Affect Your Workflow (Advantages vs Disadvantages)?**

## **Conclusion**

This article provided an in-depth knowledge of PostgreSQL Stored procedures. Through this article and a workflow example, we learned to CREATE OR REPLACE a stored procedure. We also discussed how Stored Procedures are different from Functions.

If you want to continue your learning of PostgreSQL Commands & Operations, go through either of the two articles provided below:

|  |
| --- | --- |
|  |
|  |
|  |

[**What are the differences between "Stored Procedures" and "Stored Functions"?**](https://dba.stackexchange.com/questions/2357/what-are-the-differences-between-stored-procedures-and-stored-functions)[Ask Question](https://dba.stackexchange.com/questions/ask)

Officially, PostgreSQL only has "functions". Trigger functions are sometimes referred to as "trigger procedures", but that usage has no distinct meaning. Internally, functions are sometimes referred to as procedures, such as in the system catalog `pg_proc`. That's a holdover from PostQUEL. Any features that some people (possibly with experience in different database systems) might associate with procedures, such as their relevance to preventing SQL injections or the use of output parameters, also apply to functions as they exist in PostgreSQL.

PostgreSQL 11 added stored procedures as a new schema object. You can create a new procedure by using the [`CREATE PROCEDURE`](https://www.postgresql.org/docs/current/sql-createprocedure.html) statement.

Stored procedures differ from functions in the following ways:

- Stored procedures do not have to return anything, and only return a single row when using `INOUT` parameters.
- You can commit and rollback transactions inside stored procedures, but not in functions.
- You execute a stored procedure using the `CALL` statement rather than a `SELECT` statement.
- Unlike functions, procedures cannot be nested in other DML commands (`SELECT`, `INSERT`, `UPDATE`, `DELETE`).



