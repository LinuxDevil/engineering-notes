---
notion-id: 03ef3234-9cb2-47c9-ab89-0a70b1c6d670
cover: "[[Using Views.jpeg]]"
---

**Understanding Views**
    Views are virtual tables. Unlike tables that contain data, views simply contain queries that dynamically retrieve data when used.

    **Note**: SQLite supports only read-only views, so views may be created and read, but their contents cannot be updated.

    The best way to understand views is to look at an example. When you used the following `SELECT` statement to retrieve data from three tables:
```sql
SELECT cust_name, cust_contact
FROM Customers, Orders, OrderItems
WHERE Customers.cust_id = Orders.cust_id
 AND OrderItems.order_num = Orders.order_num
 AND prod_id = 'RGAN01';
```
    That query was used to retrieve the customers who had ordered a specific product. Anyone needing this data would have to understand the table structure, as well as how to create the query and join the tables. To retrieve the same data for another product (or for multiple products), you would have to modify the last `WHERE` clause.
    Now imagine that you could wrap that entire query in a virtual table called `ProductCustomers`. You could then simply do the following to retrieve the same data:
```sql
SELECT cust_name, cust_contact
FROM ProductCustomers
WHERE prod_id = 'RGAN01';
```
    This is where views come into play. `ProductCustomers` is a view, and as a view, it does not contain any columns or data. Instead, it contains a query—the same query used above to join the tables properly.


**Why Use Views**
    You’ve already seen one use for views. Here are some other common uses:
		1. To reuse SQL statements
		2. To simplify complex SQL operations. After the query is written, it can be reused easily, without having to know the details of the underlying query itself.
		3. To expose parts of a table instead of complete tables.
		4. To secure data. Users can be given access to specific subsets of tables instead of to entire tables.
		5. To change data formatting and representation. Views can return data formatted and presented differently from their underlying tables.

    **Note**: For the most part, after views are created, they can be used in the same way as tables. You can perform `SELECT` operations, filter and sort data, join views to other views or tables, and possibly even add and update data. (There are some restrictions on this last item. More on that in a moment.)
    **Note**: The important thing to remember is views are just that—views into data stored elsewhere. Views contain no data themselves, so the data they return is retrieved from other tables. When data is added or changed in those tables, the views will return that changed data.

**View Rules and Restrictions**
    Here are some of the most common rules and restrictions governing view creation and usage:
		1. Like tables, views must be uniquely named. (They cannot be named with the name of any other table or view.)
		2. There is no limit to the number of views that can be created.
		3. To create views, you must have security access. This level of access is usually granted by the database administrator.
		4. Views can be nested; that is, a view may be built using a query that retrieves data from another view. The exact number of nested levels allowed varies from DBMS to DBMS. (Nesting views may seriously degrade query performance, so test this thoroughly before using it in production environments.)
		5. Many DBMSs prohibit the use of the `ORDER BY` clause in view queries.
		6. Some DBMSs require that every column returned be named; this will require the use of aliases if columns are calculated fields.
		7. Views cannot be indexed, nor can they have triggers or default values associated with them.
		8. Some DBMSs, like SQLite, treat views as read-only queries, meaning you can retrieve data from views but not write data back to the underlying tables.
		9. Some DBMSs allow you to create views that do not allow rows to be inserted or updated if that insertion or update will cause that row to no longer be part of the view. For example, if you have a view that retrieves only customers with email addresses, updating a customer to remove his email address would make that customer fall out of the view. This is the default behavior and is allowed, but depending on your DBMS, you might be able to prevent this from occurring.

**Creating Views**
    Views are created using the `CREATE VIEW` statement. Like `CREATE TABLE`, `CREATE VIEW` can only be used to create a view that does not exist.


**Using Views to Simplify Complex Joins**
    One of the most common uses of views is to hide complex SQL, and this often involves joins. Look at the following statement:
    Example 1:
```sql
CREATE VIEW ProductCustomers AS
SELECT cust_name, cust_contact, prod_id
FROM Customers, Orders, OrderItems
WHERE Customers.cust_id = Orders.cust_id
 AND OrderItems.order_num = Orders.order_num;
```
        Analysis:
            This statement creates a view named `ProductCustomers`, which joins three tables to return a list of all customers who have ordered any product. If you were to use `SELECT * FROM ProductCustomers`, you’d list every customer who ordered anything.
            To retrieve a list of customers who ordered product `RGAN01`, you can do the following:
    Example 2:
```sql
SELECT cust_name, cust_contact
FROM ProductCustomers
WHERE prod_id = 'RGAN01';
```
        Analysis:
            This statement retrieves specific data from the view by issuing a `WHERE` clause. When the DBMS processes the request, it adds the specified `WHERE` clause to any existing `WHERE` clauses in the view query so that the data is filtered correctly.
            As you can see, views can greatly simplify the use of complex SQL statements. Using views, you can write the underlying SQL once and then reuse it as needed.

**Using Views to Reformat Retrieved Data**
    As mentioned above, another common use of views is for reformatting retrieved data. The following  `SELECT` statement (from [Lesson 7](https://learning.oreilly.com/library/view/sams-teach-yourself/9780135182925/ch07.xhtml#ch07)) returns vendor name and location in a single combined calculated column:
```sql
SELECT RTRIM(vend_name) || ' (' || RTRIM(vend_country) || ')'
       AS vend_title
FROM Vendors
ORDER BY vend_name;
```
    Now suppose that you regularly needed results in this format. Rather than perform the concatenation each time it was needed, you could create a view and use that instead. To turn this statement into a view, you can do the following:
```sql
CREATE VIEW VendorLocations AS
SELECT RTRIM(vend_name) || ' (' || RTRIM(vend_country) || ')'
       AS vend_title
FROM Vendors;
```
    Analysis:
        This statement creates a view using the exact same query as the previous `SELECT` statement. To retrieve the data to create all mailing labels, simply do the following: `SELECT * FROM VendorLocations;`

**Using Views to Filter Unwanted Data**
    Views are also useful for applying common `WHERE` clauses. For example, you might want to define a `CustomerEMailList` view so that it filters out customers without email addresses. To do this, you can use the following statement:
    Example 3:
```sql
CREATE VIEW CustomerEMailList AS
SELECT cust_id, cust_name, cust_email
FROM Customers
WHERE cust_email IS NOT NULL;
```
        Analysis:
            Obviously, when sending email to a mailing list, you’d want to ignore users who have no email address. The `WHERE` clause here filters out those rows that have `NULL` values in the `cust_email` columns so that they’ll not be retrieved.


**Using Views with Calculated Fields**
    Views are exceptionally useful for simplifying the use of calculated fields. The following `SELECT` statement was introduced in back. It retrieves the order items for a specific order, calculating the expanded price for each item:
    Example 4:
```sql
SELECT prod_id,
       quantity,
       item_price,
       quantity*item_price AS expanded_price
FROM OrderItems
WHERE order_num = 20008;
```

