---
notion-id: 2d216747-a32a-4052-83dd-77d1656ea5ad
base: "[[Aggregate Functions.base]]"
Function: COUNT()
---
