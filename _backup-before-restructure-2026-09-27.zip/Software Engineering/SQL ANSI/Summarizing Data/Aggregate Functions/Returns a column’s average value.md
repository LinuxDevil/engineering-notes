---
notion-id: ed3560c4-ad47-40c0-bc16-f86e6a869b70
base: "[[Aggregate Functions.base]]"
Function: AVG()
---
