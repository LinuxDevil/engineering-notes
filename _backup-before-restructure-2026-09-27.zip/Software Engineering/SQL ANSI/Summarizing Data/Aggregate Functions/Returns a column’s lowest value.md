---
notion-id: 073a8b67-4cdb-40f3-b379-46577ce2c263
base: "[[Aggregate Functions.base]]"
Function: MIN()
---
