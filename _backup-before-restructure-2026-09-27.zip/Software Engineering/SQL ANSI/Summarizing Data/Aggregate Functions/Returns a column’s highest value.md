---
notion-id: 33774e19-bf36-49d8-97ca-a533f4646b0d
base: "[[Aggregate Functions.base]]"
Function: MAX()
---
