---
notion-id: 5f24a6fb-f067-4ac7-8ef5-5545d9a527e6
base: "[[Aggregate Functions.base]]"
Function: SUM()
---
