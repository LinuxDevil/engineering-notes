---
notion-id: caa7e7cb-1e79-47dc-9fe2-4d76bfdcfaf2
cover: "[[Summarizing Data.jpeg]]"
---

What is an **Aggregate Functions**
    Functions that operate on a set of rows to calculate and return a single value.

    Table showing SQL aggregate functions
    ![[Aggregate Functions.base]]

**Using Aggregate Functions**
    It is often necessary to <u>summarize data</u> without actually retrieving it all, and SQL provides special functions for this purpose. Using these functions, SQL queries are often used to retrieve data for analysis and reporting purposes.
    **Note**:
        All the aggregate functions can be used to perform calculations on multiple columns using the standard mathematical operators, example:  `AVG(prod_price*quantity)`.


**The **`**AVG()**`** Function**
    `AVG()` is used to return the average value of a specific column by counting both the number of rows in the table and the sum of their values. `AVG()` can be used to return the average value of all columns or of specific columns or rows.
    **Note**: Column rows containing `NULL` values are ignored by the `AVG()` function.

Example 1:

```sql
SELECT AVG(prod_price) AS avg_price
FROM Products;
```

Analysis:
    The `SELECT` statement above returns a single value `avg_price`, which contains the average price of all products in the `Products` table.

**The **`**COUNT()**`** Function**
    `COUNT()` does just that—it counts. Using `COUNT()`, you can determine the number of rows in a table or the number of rows that match a specific criterion.
    `COUNT()` can be used in 2 ways:
		1. Use `COUNT(*)` to count the number of rows in a table, whether columns contain values or `NULL` values.
		2. Use `COUNT(column)` to count the number of rows that have values in a specific column, ignoring `NULL` values.
    **Note**: Column rows containing `NULL` values are ignored by the `COUNT()` function, <u>but not</u> if the asterisk (*) is used.

Example 2:

```sql
SELECT COUNT(*) AS num_cust
FROM Customers;
```

Analysis:
    In this example, `COUNT(*)` is used to count all rows, regardless of values. The count is returned in `num_cust`.

Example 3:

```sql
SELECT COUNT(cust_email) AS num_cust
FROM Customers;
```

Analysis:
    This `SELECT` statement uses `COUNT(cust_email)` to count only rows with a value in the `cust_email` column. In this example, `cust_email` is `3` (meaning that only 3 of the 5 customers have email addresses).

**The **`**MAX()**`** Function**
    `MAX()` returns the highest value in a specified column. `MAX()` requires that the column name be specified.
    **Note**: **Using **`**MAX()**`** with none numerical types**
        Although `MAX()` is usually used to find the highest numeric or date values, many (but not all) DBMSs allow it to be used to return the highest value in any columns including textual columns. When used with textual data, `MAX()` returns the row that would be the <u>**last**</u> if the data were sorted by that column.
    **Note**: Column rows with `NULL` values in them are ignored by the `MAX()` function.

Example 4:

```sql
SELECT MAX(prod_price) AS max_price
FROM Products;
```

Analysis:
    Here `MAX()` returns the price of the most expensive item in the `Products` table.

**The **`**MIN()**`** Function**
    `MIN()` does the exact opposite of `MAX()`—it returns the lowest value in a specified column. Like `MAX(), MIN()` requires that the column name be specified.
    **Note**: **Using **`**MIN()**`** with none numerical types**
        Although `MIN()` is usually used to find the lowest numeric or date values, many (but not all) DBMSs allow it to be used to return the lowest value in any columns including textual columns. When used with textual data, `MIN()` returns the row that would be the <u>**first**</u> if the data were sorted by that column.
    **Note**: Column rows with `NULL` values in them are ignored by the `MIN()` function.


Example 5:

```sql
SELECT MIN(prod_price) AS min_price
FROM Products;
```

Analysis:
    Here `MIN()` returns the price of the least expensive item in the `Products` table.

**The **`**SUM()**`** Function**
    `SUM()` is used to return the sum (total) of the values in a specific column.
    **Note**: Column rows with `NULL` values in them are ignored by the `SUM()` function.

Example 6: 

```sql
SELECT SUM(item_price*quantity) AS total_price
FROM OrderItems
WHERE order_num = 20005;
```

Analysis:
    The function `SUM(item_price*quantity)` returns the sum of all the expanded prices in an order, and again the `WHERE` clause ensures that just the right order items are included.

**Aggregates on Distinct Values**
    The five aggregate functions can all be used in two ways:
		1. To perform calculations on all rows, specify the `ALL` argument or specify no argument at all (because `ALL` is the default behavior), but **No **`**DISTINCT**`** with **`**COUNT(*)**`**, **`DISTINCT` may only be used with `COUNT()` if a column name is specified. `DISTINCT` may not be used with `COUNT(*)`. Similarly, `DISTINCT` must be used with a column name and not with a calculation or expression.
		2. To include only unique values, specify the `DISTINCT` argument.
    **Note**: 
        In addition to the `DISTINCT` and `ALL` arguments shown here, some DBMSs support additional arguments such as `TOP` and `TOP PERCENT` that let you perform calculations on subsets of query results. Refer to your DBMS documentation to determine exactly what arguments are available to you.

Example 7:

```sql
SELECT AVG(DISTINCT prod_price) AS avg_price
FROM Products
WHERE vend_id = 'DLL01';
```

Analysis:
    As you can see, in this example `avg_price` is higher when `DISTINCT` is used because there are multiple items with the same lower price. Excluding them raises the average price.

**Combining Aggregate Functions**

Example 8:

```sql
SELECT COUNT(*) AS num_items,
       MIN(prod_price) AS price_min,
       MAX(prod_price) AS price_max,
       AVG(prod_price) AS price_avg
FROM Products;
```

Analysis:
    Here a single `SELECT` statement performs four aggregate calculations in one step and returns four values (the number of items in the `Products` table and the highest, lowest, and average product prices).
