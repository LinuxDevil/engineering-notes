---
notion-id: cff4949a-4013-44d1-a8b8-8e6d3af421e7
cover: "[[Grouping Data.jpeg]]"
---
## The `GROUP BY` clause and the `HAVING` clause.

**Understanding Data Grouping**
    Grouping lets you divide data into logical sets so that you can perform aggregate calculations on each group.


**Creating Groups**
    Groups are created using the `GROUP BY` clause in your `SELECT` statement.

Example 1:

```sql
SELECT vend_id, COUNT(*) AS num_prods
FROM Products
GROUP BY vend_id;
```

Analysis:
    The above `SELECT` statement specifies two columns, `vend_id`, which contains the ID of a product’s vendor, and `num_prods`, which is a calculated field (created using the `COUNT(*)` function). The `GROUP BY` clause instructs the DBMS to sort the data and group it by `vend_id`. This causes `num_prods` to be calculated once per `vend_id` rather than once for the entire table. As you can see in the output, vendor `BRS01` has `3` products listed, vendor `DLL01` has `4` products listed, and vendor `FNG01` has `2` products listed.

    Because you used `GROUP BY`, you did not have to specify each group to be evaluated and calculated. That was done automatically. The `GROUP BY` clause instructs the DBMS to group the data and then perform the aggregate on each group rather than on the entire result set.

**Rules of **`**GROUP BY**`
	1. `GROUP BY` clauses can contain as many columns as you want. This enables you to nest groups, providing you with more granular control over how data is grouped.
	2. If you have nested groups in your `GROUP BY` clause, data is summarized at the last specified group. In other words, all the columns specified are evaluated together when grouping is established (so you won’t get data back for each individual column level).
	3. Every column listed in `GROUP BY` must be a retrieved column or a valid expression (but not an aggregate function). If an expression is used in the `SELECT`, that same expression must be specified in `GROUP BY`. Aliases cannot be used.
	4. Most SQL implementations do not allow `GROUP BY` columns with variable-length datatypes (such as text or memo fields).
	5. Aside from the aggregate calculation statements, every column in your `SELECT` statement must be present in the `GROUP BY` clause.
	6. If the grouping column contains a row with a `NULL` value, `NULL` will be returned as a group. If there are multiple rows with `NULL` values, they’ll all be grouped together.
	7. The `GROUP BY` clause must come after any `WHERE` clause and before any `ORDER BY` clause.

**Filtering Groups**
    `HAVING` clause. `HAVING` is very similar to `WHERE`. In fact, all types of `WHERE` clauses you’ve learned about thus far can also be used with `HAVING`. The only difference is that `WHERE` <u>filters rows</u> and `HAVING` <u>filters groups.</u>

Example 2:

```sql
SELECT cust_id, COUNT(*) AS orders
FROM Orders
GROUP BY cust_id
HAVING COUNT(*) >= 2;
```

Analysis:
    The first three lines of this `SELECT` statement are similar to the statements seen above. The final line adds a `HAVING` clause that filters on those groups with a `COUNT(*) >= 2`—two or more orders.
    As you can see, a `WHERE` clause couldn’t work here because the filtering is based on the group aggregate value, not on the values of specific rows.

**The Difference Between **`**HAVING**`** and **`**WHERE**`
    Here’s another way to look it: `WHERE` filters <u>before</u> data is grouped, and `HAVING` filters <u>after</u> data is grouped. This is an important distinction; rows that are eliminated by a `WHERE` clause will not be included in the group. This could change the calculated values, which in turn could affect which groups are filtered based on the use of those values in the `HAVING` clause.
    **Note: Using **`**HAVING**`** and **`**WHERE**`
        `HAVING` is so similar to `WHERE` that most DBMSs treat them as the same thing if no `GROUP BY` is specified. Nevertheless, you should make that distinction yourself. Use `HAVING` only in conjunction with `GROUP BY` clauses. Use `WHERE` for standard row-level filtering.

Example 3:

```sql
SELECT vend_id, COUNT(*) AS num_prods
FROM Products
WHERE prod_price >= 4
GROUP BY vend_id
HAVING COUNT(*) >= 2;
```

Analysis:
    This statement warrants an explanation. The first line is a basic `SELECT` using an aggregate function—much like the examples thus far. The `WHERE` clause filters all rows with a `prod_price` of at least `4`. Data is then grouped by `vend_id`, and then a `HAVING` clause filters just those groups with a count of `2` or more. Without the `WHERE` clause, an extra row would have been retrieved (vendor `DLL01` who sells four products all priced under `4`).

**Grouping and Sorting**
    It is important to understand that `GROUP BY` and `ORDER BY` are very different, even though they often accomplish the same thing.
    Table showing the difference between `GROUP BY` and `ORDER BY`
    ![[Order By VS Group By.base]]

Example 4:

```sql
SELECT order_num, COUNT(*) AS items
FROM OrderItems
GROUP BY order_num
HAVING COUNT(*) >= 3
ORDER BY items, order_num;
```

Analysis:
    In this example, the `GROUP BY` clause is used to group the data by order number (the `order_num` column) so that the `COUNT(*)` function can return the number of items in each order. The `HAVING` clause filters the data so that only orders with three or more items are returned. Finally, the output is sorted using the `ORDER BY` clause.


`**SELECT**`** Clause Ordering**

| <u>**Clause**</u> | <u>**Description**</u> | <u>**Required**</u> |
| --- | --- | --- |
| `SELECT` | Columns or expressions to be returned | Yes |
| `FROM` | Table to retrieve data from | Only if selecting data from a table |
| `WHERE` | Row-level filtering | No |
| `GROUP BY` | Group specification | Only if calculating aggregates by group |
| `HAVING` | Group-level filtering | No |
| `ORDER BY` | Output sort order | No |
