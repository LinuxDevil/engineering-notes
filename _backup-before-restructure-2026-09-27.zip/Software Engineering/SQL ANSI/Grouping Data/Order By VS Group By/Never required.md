---
notion-id: 24ad9478-641f-4f0a-a208-355883575b28
base: "[[Order By VS Group By.base]]"
GROUP BY: Required if using columns (or expressions) with aggregate functions.
---
