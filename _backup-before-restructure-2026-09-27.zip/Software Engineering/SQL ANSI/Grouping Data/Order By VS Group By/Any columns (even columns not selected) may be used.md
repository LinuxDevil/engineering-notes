---
notion-id: 94018c55-ba4d-45fb-86eb-d04173e935be
base: "[[Order By VS Group By.base]]"
GROUP BY: Only selected columns or expressions columns may be used, and every selected column expression must be used.
---
