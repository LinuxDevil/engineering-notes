---
notion-id: 2e43022c-f3d3-488f-9985-fd269a0e5130
base: "[[Order By VS Group By.base]]"
GROUP BY: Groups rows. The output might not be in group order, however.
---
