---
notion-id: a8a5be17-3538-45f2-9a2e-07d8bd024041
cover: "[[Filtering Data.jpeg]]"
---
## Using the `WHERE` clause 

![[Where clause operators.base]]

**Searching for equality**

Example 1:

```sql
SELECT prod_name, prod_price
FROM Products
WHERE prod_price = 3.49;
```

Analysis:
    This statement retrieves two columns from the `products` table, but instead of returning all rows, only rows with a `prod_price` value of `3.49` are returned.

**Checking Against a Single Value**

Example 2:

```sql
SELECT prod_name, prod_price
FROM Products
WHERE prod_price < 10;
```

Analysis:
    This statement retrieves two columns from the `products` table, but instead of returning all rows, only rows with a `prod_price` value less than `10` are returned.

