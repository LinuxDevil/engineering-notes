---
notion-id: 87c6021b-12f4-4bf7-8765-fb1061b52b02
base: "[[Where clause operators.base]]"
Filter Operator: <
Description: Less than
---
