---
notion-id: 7633947e-d57e-46e7-9f9f-97497ce0f49e
base: "[[Where clause operators.base]]"
Filter Operator: "!>"
Description: Not greater than
---
