---
notion-id: 9a3e5fc4-9d08-436a-b09d-a3ab0e5ad77b
base: "[[Where clause operators.base]]"
Filter Operator: IS NULL
Description: Is a NULL value
---
