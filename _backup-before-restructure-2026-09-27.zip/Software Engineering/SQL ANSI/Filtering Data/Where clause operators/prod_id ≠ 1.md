---
notion-id: a11e3167-66b1-4185-bd28-1d5fe51d97c1
base: "[[Where clause operators.base]]"
Filter Operator: "!="
Description: Nonequality
---
