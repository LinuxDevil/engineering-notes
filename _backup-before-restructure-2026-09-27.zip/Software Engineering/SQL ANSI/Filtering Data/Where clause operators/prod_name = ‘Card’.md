---
notion-id: ab784529-bdec-486b-b5da-3bedca8776ae
base: "[[Where clause operators.base]]"
Filter Operator: =
Description: Equality
---
