---
notion-id: 0f60173e-d718-4671-b924-2c4ad003efb0
base: "[[Where clause operators.base]]"
Filter Operator: "!<"
Description: Not less than
---
