---
notion-id: 9fe08635-3570-47a9-8c37-3c3c61b485e1
base: "[[Where clause operators.base]]"
Filter Operator: <>
Description: Nonequality
---
