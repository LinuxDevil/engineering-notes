---
notion-id: eba7b820-d346-47cb-9fdf-95d0f117b28c
base: "[[Where clause operators.base]]"
Filter Operator: ">"
Description: Greater than
---
