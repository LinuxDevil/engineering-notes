---
notion-id: 6df647f3-1a3d-4e54-8d8d-0ab750f1b808
base: "[[Where clause operators.base]]"
Filter Operator: <=
Description: Less than or equal to
---
