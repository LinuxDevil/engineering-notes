---
notion-id: bfd98687-4467-420a-9cd7-1441190c2842
base: "[[Where clause operators.base]]"
Filter Operator: ">="
Description: Greater than or equal to
---
