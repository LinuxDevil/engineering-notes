---
notion-id: ab83e18d-c9cb-4eff-9975-2e8f6cc2fb10
base: "[[Where clause operators.base]]"
Filter Operator: BETWEEN
Description: Between two specified values
---
