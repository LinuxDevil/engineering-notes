---
notion-id: a7966622-19ee-4dff-b7a3-26cecd3615d0
cover: "[[Using Cursors.jpeg]]"
---

**Understanding Cursors**
    SQL retrieval operations work with sets of rows known as <u>*result sets*</u>. The rows returned are all the rows that match a SQL statement—zero or more of them. When you use simple `SELECT` statements, there is no way to get the first row, the next row, or the previous 10 rows. This is an integral part of how a relational DBMS works.

    What is a **Cursor** 
        A cursor is a database query stored on the DBMS server—not a `SELECT` statement, but the result set retrieved by that statement. Once the cursor is stored, applications can scroll or browse up and down through the data as needed.
        A Cursor can only be declared inside a transaction. The cursor does not calculate the data but only prepares the query so that your data can be created when FETCH is called. In the end, simply commit the transaction.

    **Note**: SQLite supports a form of cursors called *steps*. The basic concepts described in this lesson apply to SQLite steps, but the syntax can be quite different.

    Different DBMSs support different <u>cursor options</u> and <u>features</u>. Some of the more common ones are:
		1. The capability to flag a cursor as read-only so that data can be read but not updated or deleted.
		2. The capability to control the directional operations that can be performed (forward, backward, first, last, absolute position, relative position, and so on).
		3. The capability to flag some columns as editable and others as not editable.
		4. Scope specification so as to be able to make the cursor accessible to the specific request that created it (a stored procedure, for example) or to all requests.
		5. Instructing the DBMS to make a copy of the retrieved data (as opposed to pointing to the live data in the table) so that data does not change between the time the cursor is opened and the time it is accessed.


**Working with Cursors**
    Using cursors involves several distinct steps:
		1. Before a cursor can be used, it must be declared (defined). This process does not actually retrieve any data, it merely defines the `SELECT` statement to be used and any cursor options.
		2. Once it is declared, the cursor must be opened for use. This process actually retrieves the data using the previously defined `SELECT` statement.
		3. With the cursor populated with data, individual rows can be fetched (retrieved) as needed.
		4. When it is done, the cursor must be closed and possibly deallocated (depending on the DBMS).


**Creating Cursors**
```sql
DECLARE CURSOR CustCursor
IS
SELECT * FROM Customers
WHERE cust_email IS NULL;
```
    Analysis:
        The `DECLARE` statement is used to define and name the cursor—in this case, `CustCursor`. The `SELECT` statement defines a cursor containing all customers with no email address (a `NULL` value). Now that the cursor is defined, it is ready to be opened.

**Using Cursors**
    Cursors are opened using the `OPEN CURSOR` statement, which is so simple a statement that most DBMSs support exactly the same syntax:
```sql
OPEN CURSOR CustCursor
```
    When the `OPEN CURSOR` statement is processed, the query is executed, and the retrieved data is stored for subsequent browsing and scrolling.
    Now the cursor data can be accessed using the `FETCH` statement. `FETCH` specifies the rows to be retrieved, where they are to be retrieved from, and where they are to be stored (variable names, for example). The first example uses Oracle syntax to retrieve a single row from the cursor (the first row):
```sql
DECLARE TYPE CustCursor IS REF CURSOR
    RETURN Customers%ROWTYPE;
DECLARE CustRecord Customers%ROWTYPE
BEGIN
    OPEN CustCursor;
    FETCH CustCursor INTO CustRecord;
    CLOSE CustCursor;
END;
```
    Analysis:  
        In this example, `FETCH` is used to retrieve the current row (it’ll start at the first row automatically) into a declared variable named `CustRecord`. Nothing is done with the retrieved data.

**Closing Cursors**
    As already mentioned and seen in the previous examples, cursors need to be closed after they have been used. In addition, some DBMSs (such as SQL Server) require that the resources used by the cursor be explicitly deallocated. Here’s the DB2, Oracle, and PostgreSQL syntax:
```sql
CLOSE CustCursor
```
    Here’s the Microsoft SQL Server version:
```sql
CLOSE CustCursor
DEALLOCATE CURSOR CustCursor
```
    Analysis:
        The `CLOSE` statement is used to close cursors; once a cursor is closed, it cannot be reused without being opened again. However, a cursor does not need to be declared again to be used; an `OPEN` statement is sufficient.