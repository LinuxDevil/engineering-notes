---
notion-id: 3cfbae89-2064-4452-b101-257fd369d7c3
cover: "[[Using Wildcard Filtering.jpeg]]"
---
## Using the `LIKE` operator/predicate 

What is **Wildcards**
    **Wildcards **are special characters used to match parts of a value.
    **Note**: 
        Wildcard searching can only be used with text fields (strings); you can’t use wildcards to search fields of non-text datatypes.

What is **Search pattern**
    Is a search condition made up of literal text, wildcard characters, or any combination of the above.

The `LIKE` Operator
    Instructs the DBMS that the following search pattern is to be compared using a wildcard match rather than a straight equality match.

What is a **Predicate**
    When is an operator not an operator? When it is a “predicate.” Technically, `LIKE` is a predicate, not an operator. The end result is the same. Just be aware of this term in case you run across it in SQL documentation or manuals.


**The Percent Sign (**`**%**`**) Wildcard**
    `%` means *match any number of occurrences of any character*. For example, to find all products that start with the word `Fish`.
    **Note**: **Case Sensitivity**
        Depending on our DBMS and how it is configured, searches may be case sensitive, in which case `'fish%'` would not match Fish bean bag toy.
    **Note**:
         `%` represents zero, one, or more characters at the specified location in the search pattern.
    **Note**: 
        It may seem that the `%` wildcard matches anything, but there is one exception: `NULL`. Not even the clause `WHERE prod_name LIKE '%'` will match a row with the value `NULL` as the product name.


Example 1:

```sql
SELECT prod_id, prod_name
FROM Products
WHERE prod_name LIKE 'Fish%';
```

Analysis:
    This example uses a search pattern of `'Fish%'`. When this clause is evaluated, any value that starts with Fish will be retrieved. The `%` tells the DBMS to accept any characters after the word `Fish`, regardless of how many characters there are.

Example 2:

```sql
SELECT prod_id, prod_name
FROM Products
WHERE prod_name LIKE '%bean bag%';
```

Analysis:
    The search pattern `'%bean bag%'` means *match any value that contains the text* bean bag *anywhere within it*, *regardless of any characters before or after that text*.

**The Underscore (**`**_**`**) Wildcard**
    The underscore is used just like `%`, but instead of matching multiple characters, the underscore matches just a single character.

Example 3:

```sql
SELECT prod_id, prod_name
FROM Products
WHERE prod_name LIKE '__ inch teddy bear';
```

Analysis:
    The search pattern used in this `WHERE` clause specified two wildcards followed by literal text. The results shown are the only rows that match the search pattern: the underscore matches `12` in the first row and `18` in the second row. The `8 inch teddy bear` product did not match because the search pattern required two wildcard matches, not one. By contrast, the following `SELECT` statement uses the `%` wildcard and returns three matching products:
```sql
SELECT prod_id, prod_name
FROM Products
WHERE prod_name LIKE '% inch teddy bear';
```

**The Brackets (**`**[]**`**) Wildcard**
    The brackets (`[]`) wildcard is used to specify a set of characters, any one of which must match a character in the specified position (the location of the wildcard).
    **Note**:
        Not all DBMS supports [], MySQL doesn’t support it while MS SQL Server does.


Example 4:

```sql
SELECT cust_contact
FROM Customers
WHERE cust_contact LIKE '[JM]%'
ORDER BY cust_contact;
```

Analysis:
    The `WHERE` clause in this statement is `'[JM]%'`. This search pattern uses two different wildcards. The `[JM]` matches any contact name that begins with either of the letters within the brackets, and it also matches only a single character. Therefore, any names longer than one character will not match. The `%` wildcard after the `[JM]` matches any number of characters after the first character, returning the desired results.

    This wildcard can be negated by prefixing the characters with ^ (the caret character). For example, the following matches any contact name that does not begin with the letter `J` or the letter `M` (the opposite of the previous example):
```sql
SELECT cust_contact
FROM Customers
WHERE cust_contact LIKE '[^JM]%'
ORDER BY cust_contact;
```

Some Rules of the wildcards:
	1. Don’t overuse wildcards. If another search operator will do, <u>use it instead</u>.
	2. When you do use wildcards, try <u>not</u> to use them at the beginning of the search pattern unless absolutely necessary. Search patterns that begin with wildcards are the slowest to process.
	3. Pay careful attention to the placement of the wildcard symbols. If they are misplaced, you might not return the data you intended.
