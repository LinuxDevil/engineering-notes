---
notion-id: 35d628a3-9117-4055-9b6a-4495ecadbbce
cover: "[[SQL Trigger Functions.jpeg]]"
---

Triggers are special stored procedures that are executed automatically when specific database activity occurs. Triggers might be associated with `INSERT`, `UPDATE`, and `DELETE` operations (or any combination thereof) on specific tables.

Unlike stored procedures (which are simply stored SQL statements), triggers are tied to individual tables. A trigger associated with `INSERT` operations on the `Orders` table will be executed only when a row is inserted into the `Orders` table. Similarly, a trigger on `INSERT` and `UPDATE` operations on the `Customers` table will be executed only when those specific operations occur on that table.

Within triggers, your code has <u>access</u> to the following:
	1. All new data in `INSERT` operations.
	2. All new data and old data in `UPDATE` operations.
	3. Deleted data in `DELETE` operations.

Triggers can be executed before or after a specified operation is performed.

## Types of Triggers

1.    <u>Row Level Trigger:</u> If the trigger is marked **FOR EACH ROW** then the trigger function will be called for each row that is getting modified by the event.

For example: If we UPDATE 100 rows in the table, the UPDATE trigger function will be called 100 times, once for each updated row.

2.    <u>Statement Level Trigger:</u> The **FOR EACH STATEMENT **option** **will call the trigger function only once for each statement, regardless of the number of the rows getting modified.

Trigger uses: 
	1. Ensuring data consistency; for example, converting all state names to uppercase during an `INSERT` or `UPDATE` operation.
	2. Performing actions on other tables based on changes to a table; for example, writing an audit trail record to a log table each time a row is updated or deleted.
	3. Performing additional validation and rolling back data if needed; for example, making sure a customer’s available credit has not been exceeded and blocking the insertion if it has.
	4. Calculating computed column values or updating time stamps.

    ## Uses Of Triggers
    1.    Auditing: You can use triggers to track the table transactions by logging the event details.
    2.    Forcing Check Constraint: You can create a trigger by which you can check the constraints before applying the transaction to the table.
	3.   Automatic Population: By using triggers you can also auto populate tables fields by new transactions records manipulation.
    ## Important Points To Remember
    1.    To create a trigger on a table, the user must have the TRIGGER privilege on the table and EXECUTE privilege on the trigger function.
    2.    You can check system catalogue “pg_trigger” for the existing trigger information in the database.
    3.    If you create multiple triggers on the same object for the same event, those triggers will be fired in alphabetical order by name.


Example 7:
```sql
CREATE TRIGGER customer_state
AFTER INSERT OR UPDATE
FOR EACH ROW
BEGIN
UPDATE Customers
SET cust_state = Upper(cust_state)
WHERE Customers.cust_id = :OLD.cust_id
END;
```
    Analysis:
        The following example creates a trigger that converts the `cust_state` column in the `Customers` table to uppercase on all `INSERT` and `UPDATE` operations.


**Note**: **Constraints Are Faster Than Triggers**
    As a rule, constraints are processed more quickly than triggers, so whenever possible, use constraints instead.


A PostgreSQL trigger is a [function](https://www.postgresqltutorial.com/postgresql-create-function/) invoked automatically whenever an event associated with a table occurs. An event could be any of the following: [INSERT](https://www.postgresqltutorial.com/postgresql-tutorial/postgresql-insert/), [UPDATE](https://www.postgresqltutorial.com/postgresql-tutorial/postgresql-update/), [DELETE ](https://www.postgresqltutorial.com/postgresql-tutorial/postgresql-delete/)or [TRUNCATE](https://www.postgresqltutorial.com/postgresql-tutorial/postgresql-truncate-table/).

A trigger is a special [user-defined function](https://www.postgresqltutorial.com/postgresql-stored-procedures/) associated with a table. To create a new trigger, you define a trigger function first, and then bind this trigger function to a table. The difference between a trigger and a user-defined function is that a trigger is automatically invoked when a triggering event occurs.

PostgreSQL provides two main types of triggers: row and statement-level triggers. The differences between the two kinds are how many times the trigger is invoked and at what time.

For example, if you issue an `UPDATE` statement that affects 20 rows, the row-level trigger will be invoked 20 times, while the statement level trigger will be invoked 1 time.

You can specify whether the trigger is invoked before or after an event. If the trigger is invoked before an event, it can skip the operation for the current row or even change the row being updated or inserted. In case the trigger is invoked after the event, all changes are available to the trigger.

Triggers are useful in case the database is accessed by various applications, and you want to keep the cross-functionality within the database that runs automatically whenever the data of the table is modified. For example, if you want to keep the history of data without requiring the application to have logic to check for every event such as `INSERT` or `UDPATE`.

You can also use triggers to maintain complex data integrity rules which you cannot implement elsewhere except at the database level.  For example, when a new row is added into the `customer` table, other rows must be also created in tables of banks and credits.

The main drawback of using a trigger is that you must know the trigger exists and understand its logic to figure it out the effects when data changes.

Even though PostgreSQL implements SQL standard, triggers in PostgreSQL has some specific features:

- PostgreSQL fires trigger for the [`TRUNCATE`](https://www.postgresqltutorial.com/postgresql-tutorial/postgresql-truncate-table/) event.
- PostgreSQL allows you to define the statement-level trigger on views.
- PostgreSQL requires you to define a user-defined function as the action of the trigger, while the SQL standard allows you to use any SQL commands.


## Creating a Trigger

The SQL command CREATE TRIGGER creates a trigger on the specified object.

The syntax of the CREATE TRIGGER  is as follows:

```plain text
CREATE [CONSTRAINT ]TRIGGER name { BEFORE | AFTER | INSTEADOF } { event [OR ... ] }

ON table_name

[FROM referenced_table_name ]

[NOT DEFERRABLE | [ DEFERRABLE ] [ INITIALLY IMMEDIATE | INITIALLY DEFERRED ] ]

[REFERENCING { {OLD |NEW }TABLE [AS ] transition_relation_name } [ ... ] ]

[FOR [EACH ] {ROW | STATEMENT } ]

[WHEN (condition ) ]

EXECUTE {FUNCTION |PROCEDURE } function_name ( arguments )



where event can beoneof:



INSERTUPDATE [OF column_name [, ... ] ]

DELETETRUNCATE
```

**Parameter**

- **Name –** The name of the trigger. This name will be distinct from any other trigger from the same table.
- **Before –** Determines that we are calling the function before the event.
- **After –** Determines that we are calling the function after the event.
- **Instead Of –** Determines that we are calling the function instead of the event.
- **Event –** Any of the event like Insert, Update, delete or truncate will fire the trigger.
- **Table name –** Name of the table or view
- **Referenced table name –** This is the name of other tables which is referenced by constraints. This option only specified with constraints triggers.
- **DEFERRABLE, NOT DEFERRABLE, INITIALLY IMMEDIATE and INITIALLY DEFERRED –** This is the PostgreSQL trigger’s default time.
- **For each row, this** will specify that the trigger will be fired once for every row affected by trigger events.
- **For each statement –** If we have not specified any row or statement, this will default. This will specify that it will be fired once for every statement affected by a trigger event.
- **Condition –** Condition will be the Boolean expression that determines that trigger function will be executed.
- **Function name –** User-supplied function that is not arguments, and it will return trigger.
- **Arguments –** This is an optional comma-separated argument provided to the function, then the trigger was executing.

For a more detailed description and available options, check the PostgreSQL documentation at [https://www.postgresql.org/docs/12/sql-createtrigger.html](https://www.postgresql.org/docs/12/sql-createtrigger.html).

The function is defined in the following compatible languages:

- PL/pgsql
- PL/Python
- Pl/ Java

### **1. INSERT event Trigger**

The INSERT event trigger gets called when a new record is added to a table using the INSERT statement.

### **Example**

Let’s take a look at an example of creating a new trigger. In this example, we will create a new table named “Employee” as follows:

```plain text
CREATETABLE "Employee"

(

"EmployeeId"INTNOTNULL,

"LastName"VARCHAR(20)NOTNULL,

"FirstName"VARCHAR(20)NOTNULL,

"Title"VARCHAR(30),

"ReportsTo"INT,

"BirthDate"TIMESTAMP,

"HireDate"TIMESTAMP,

"Address"VARCHAR(70),

"City"VARCHAR(40),

"State"VARCHAR(40),

"Country"VARCHAR(40),

"PostalCode"VARCHAR(10),

"Phone"VARCHAR(24),

"Fax"VARCHAR(24),

"Email"VARCHAR(60),

CONSTRAINT "PK_Employee"PRIMARY KEY  ("EmployeeId")

);



CREATETABLE "Employee_Audit"

(

"EmployeeId"INTNOTNULL,

"LastName"VARCHAR(20)NOTNULL,

"FirstName"VARCHAR(20)NOTNULL,

"UserName"VARCHAR(20)NOTNULL,

"EmpAdditionTime"VARCHAR(20)NOTNULL,

);
```

We are going to create a trigger that can add an entry in the “Employee_Audit” table if a new employee record gets inserted into the “Employee” table. We are going to log the username details, which is going to add the record in the “Employee” table.

Add a trigger function and CREATE TRIGGER command:

```plain text
CREATEOR REPLACEFUNCTION employee_insert_trigger_fnc()

RETURNStriggerAS

$$

BEGIN



INSERTINTO "Employee_Audit" ( "EmployeeId", "LastName", "FirstName","UserName" ,"EmpAdditionTime")

VALUES(NEW."EmployeeId",NEW."LastName",NEW."FirstName",current_user,current_date);



RETURNNEW;

END;

$$

LANGUAGE 'plpgsql';



CREATETRIGGER employee_insert_trigger

  AFTERINSERT

ON "Employee"

FOREACHROW

EXECUTEPROCEDURE employee_insert_trigger_fnc();
```

### **2. UPDATE event Trigger**

The UPDATE event trigger gets called at the time of UPDATE statement execution.

### **Example**

```plain text
CREATETRIGGER verify_user_for_update

 BEFOREUPDATE

ON "Employee"

FOREACHROWEXECUTEPROCEDURE employee_verify_user_priv();
```

### **3. DELETE event Trigger**

This the DELETE event trigger, which can be added on transactions that DELETE the records.

### **Example**

```plain text
CREATETRIGGER employee_delete_trigger

  AFTERDELETE

ON "Employee"

FOREACHROW

EXECUTEPROCEDURE aft_delete();
```

## Dropping a Trigger

DROP TRIGGER is used to remove a trigger. The syntax is very simple.

```plain text
droptrigger employee_insert_triggeron "Employee" ;
```


## **Listing TRIGGERS**

You can list down all the triggers in the current database from **pg_trigger** table as follows −

```plain text
testdb=# SELECT * FROM pg_trigger;
```

The above given PostgreSQL statement will list down all triggers.

If you want to list the triggers on a particular table, then use AND clause with table name as follows −

```plain text
testdb=# SELECT tgname FROM pg_trigger, pg_class WHERE tgrelid=pg_class.oid AND relname='company';
```

The above given PostgreSQL statement will also list down only one entry as follows −

```plain text
     tgname
-----------------
 example_trigger
(1 row)
```


# **Summary:**

- A PostgreSQL trigger refers to a function that is triggered automatically when a database event occurs on a database object, such as a table.
- Examples of such database events include INSERT, UPDATE, DELETE, etc.
- A trigger only exists during the lifetime of the database object for which it was created.
- If the database object is deleted, the trigger will also be deleted.
- PostgreSQL triggers are created using the CREATE TRIGGER statement.
- Each trigger is associated with a function stating what the trigger will do when it is invoked.