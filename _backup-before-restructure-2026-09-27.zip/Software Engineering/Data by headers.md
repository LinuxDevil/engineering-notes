---
notion-id: 3e8848c0-4c08-449d-922a-0d89ea706e12
cover: "[[Data by headers.jpeg]]"
---
It is usually a good idea to use the headers for metadata and the body for the data that is used by the business logic.

Some points to consider:

1. If the data is sent via HTTP instead of HTTPS, the proxy servers can modify the headers.
2. If you are using the REST protocol for communication among microservices, interoperability could be important. Most APIs usually do not provide the capability to add/modify custom headers.
3. It is better to have the data that is used by routers/firewalls in the HTTP header and limit the body to application specific information.
