---
notion-id: 67e33c3f-24ef-4c97-89d3-1e65a76a6c1b
cover: "[[GraphQL vs REST.jpeg]]"
---

GraphQL server potentially could work based on protocols other than HTTP, like WebSockets or the lower-level TCP

What is **GraphQL**
    GraphQL is a **query language for APIs** that enables declarative data fetching in order to give the client the power to specify exactly the data that is needed from the API. It makes easier to evolve APIs over time.
    Now that we know what GraphQL is, I want to clarify what it is not, as I feel that there is still some confusion about it.
    Firstly, **it does not have anything to do with databases.** It is not an alternative to SQL or a brand new ORM.
    Secondly, **it is not a REST replacement**, but an alternative. You don't have to pick between one and the other, they can happily co-exist in the same project.
    Last but not least, GraphQL is not complicated or scary. It is quite easy to understand its declarative nature and exactly how it is possible to take the best from it.
    GraphQL solves the issue of over and under fetching.


What is **REST**
    REST (Representational State Transfer) is a **software architectural style** that defines a set of constraints which make any web service – a true RESTful API. The REST constraints are:
		1. **Client-server architecture**
			Client-server architecture means that the user-interface concerns should be separated from the data storage concerns to improve the user interfaces portability across multiple platforms.
		2. **Stateless**
			A stateless server does not persist any information about the user who uses the API. This means that the server does not remember if the user is sending is first request or not.
		3. **Cacheability**
			REST API responses must define themselves as cachable or non-cachable to prevent clients from providing any inappropriate data that can be used on future requests.
		4. **Layered system**
			A Layered system means that if a [proxy](https://en.wikipedia.org/wiki/Proxy_server) or [load balancer](https://en.wikipedia.org/wiki/Load_balancing_(computing)) is placed between client and server, the connections between them should not be affected, and the client did not know if is connected to the end server or not.
		5. **Uniform interface**
			A Uniform interface suggests that it should be a uniform way of interacting with a given server despite the device or application type (website, mobile app). The main guideline is that each resource has to be identified on requests.

![[REST VS GraphQL.base]]