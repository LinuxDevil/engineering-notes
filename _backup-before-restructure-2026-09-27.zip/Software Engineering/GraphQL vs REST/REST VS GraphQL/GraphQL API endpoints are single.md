---
notion-id: 2282eb50-07c1-47e7-9aa6-368e860bcda6
base: "[[REST VS GraphQL.base]]"
REST: REST API endpoints are multiple.
---
