---
notion-id: 47c00838-e83d-4ad6-9bdc-a80833d9a474
base: "[[REST VS GraphQL.base]]"
REST: It is difficult to get consistency across all operating systems.
---
