---
notion-id: 57caef9b-0f31-4c76-aa76-c4a78dc0079e
base: "[[REST VS GraphQL.base]]"
REST: It offers flexible public API that can easily enable new applications.
---
