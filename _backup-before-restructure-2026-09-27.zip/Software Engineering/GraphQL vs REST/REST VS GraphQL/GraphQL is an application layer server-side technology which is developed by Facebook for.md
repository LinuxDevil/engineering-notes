---
notion-id: f6f35fec-5bc7-4512-99c0-4dcab7ab2ea8
base: "[[REST VS GraphQL.base]]"
REST: REST is a software architectural style that defines a set of constraints for creating Web services.
---
