---
notion-id: 2fdd7918-1173-421f-b932-e508ad005455
base: "[[REST VS GraphQL.base]]"
REST: The development speed in REST is Slow.
---
