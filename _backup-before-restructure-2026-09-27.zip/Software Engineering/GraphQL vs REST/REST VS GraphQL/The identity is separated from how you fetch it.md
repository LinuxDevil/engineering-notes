---
notion-id: 4e41a3a6-aeee-4de3-af1e-ed0280e67ef8
base: "[[REST VS GraphQL.base]]"
REST: The endpoint you call in REST is the identity of an object.
---
