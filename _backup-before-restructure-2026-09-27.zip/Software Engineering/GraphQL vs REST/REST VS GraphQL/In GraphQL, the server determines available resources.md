---
notion-id: 1709da47-e68d-4941-90d1-ea84426b28e5
base: "[[REST VS GraphQL.base]]"
REST: The shape and size of the resource are determined by the server in REST.
---
