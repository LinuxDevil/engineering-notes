---
notion-id: c7f31e73-4ba7-4072-82ac-83b349d791ec
base: "[[REST VS GraphQL.base]]"
REST: The learning curve in REST is moderate.
---
