---
notion-id: 59af9b05-d77d-4a7a-a260-1d2e25a5ccfe
base: "[[REST VS GraphQL.base]]"
REST: REST is a large community.
---
