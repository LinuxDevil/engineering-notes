---
notion-id: a9b7981f-82fb-4cd6-babf-4f30ee2dd9f0
base: "[[REST VS GraphQL.base]]"
REST: REST can be arranged in terms of endpoints.
---
