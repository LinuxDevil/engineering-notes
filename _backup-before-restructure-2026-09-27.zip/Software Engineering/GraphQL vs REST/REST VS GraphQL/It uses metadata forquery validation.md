---
notion-id: 5be690a6-8a96-40cb-a3ff-3c60010b2171
base: "[[REST VS GraphQL.base]]"
REST: It does not have machine-readable metadata cacheable.
---
