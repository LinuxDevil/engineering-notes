---
notion-id: 450b95e4-b54f-4570-ace9-b00797a0ec8c
base: "[[REST VS GraphQL.base]]"
REST: The message format for REST mutations can be anything.
---
