---
notion-id: e751689f-ad95-4c6d-bc62-d691bca6ba02
base: "[[REST VS GraphQL.base]]"
REST: It is hard to get consistency across all platforms.
---
