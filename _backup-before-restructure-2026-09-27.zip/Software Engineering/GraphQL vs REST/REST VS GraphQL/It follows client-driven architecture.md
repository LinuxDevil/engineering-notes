---
notion-id: 5cb7bb0e-47f9-400b-9e56-30a044786e38
base: "[[REST VS GraphQL.base]]"
REST: It follows server-driven architecture.
---
