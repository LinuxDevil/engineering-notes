---
notion-id: 1f9b4895-fae2-4460-a1aa-88c0c6461045
base: "[[REST VS GraphQL.base]]"
REST: It is weakly typed.
---
