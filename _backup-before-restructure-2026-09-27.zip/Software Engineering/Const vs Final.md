---
notion-id: b9ec1ee3-cdd7-41f1-b8d0-4884d6cf3b87
cover: "[[Const vs Final.jpeg]]"
---

The only difference between final and const is that the **const makes the variable constant from compile-time only**. Using const on an object, makes the object's entire deep state strictly fixed at compile-time and that the object with this state will be considered frozen and completely immutable.
