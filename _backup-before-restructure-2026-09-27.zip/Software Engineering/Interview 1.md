---
notion-id: 8768bcc8-aa7b-4882-8850-d8eca894629f
---

Write a function that given two non-negative integers A and B, returns the number of bits set to 1 in binary representation of the number A * B.

For example given A = 3 and B = 7 the function should return 3, because the binary representation of that A * B = 3 *7 = 21 is 101010 and it contains three bits set to 1. 

Assume that: 

A and B are integers within the range of [0..100,000,000]

In ypur soultion focus on correctness.

```matlab
public class Main {
    public static void main(String[] args) {
        System.out.println(countBits(3, 7));  // It will print 3
    }

    public static int countBits(int A, int B) {
        long product = (long)A * (long)B;  // Convert to long to prevent overflow

        // Convert the product to binary string, then count the number of '1's
        return Long.bitCount(product);
    }
}
```


You are given an undirected graph consisting of N vertices, numbered from 1 to N and M edges, the graph is described by two arrays, A and B, both of length M. A pair (A[K], B[K]) for K from 0 to )=1, describes an edge between vertex A[K] and vertex B[K]. 

Your task is to check whether the given graph contains a path from vertex 1 to vertex N going through all of the vertices, one by one, in increasing order of their numbers, All connections on the path should be direct. 

write a function that, given an integer N and two arrays A, B of M integers each, return true if there exists a path from vertex 1 to N going through all vertices, one by one, in increasing order of false otherwise.

Examples: 
1. Given N = 4, A=[1,2, 4, 4, 3] and B=[2,3,1,3,1] the function should return true. There is a path (1 -> 2 -> 3 -> 4) using edges (1,2), (2,3) and (4,3)
2. Given N=4, A=[1,2,1,3] and B=[2,4,3,4] the function should return false. There is no path
3. Given N = 6, A= [2,4,5,3] and B=[3,5,6,4] the function should return false.

Write an efficient algorthm for the following assumptions: 
1. N is an integer within the range [2.. 100,000]
2. M is an integer within the range [0.. 100,000]
3. all elements of arrays A and B are integers within the range [1..N]
4. There are no self-loops (edges with A[K] = B[K]) in the graph
5. There are no multiple edges between the same verticies

```matlab
import java.util.*;

public class Main {
    public static void main(String[] args) {
        System.out.println(hasPath(4, new int[]{1,2,4,4,3}, new int[]{2,3,1,3,1}));  // It will print true
        System.out.println(hasPath(4, new int[]{1,2,1,3}, new int[]{2,4,3,4}));  // It will print false
        System.out.println(hasPath(6, new int[]{2,4,5,3}, new int[]{3,5,6,4}));  // It will print false
    }

    public static boolean hasPath(int N, int[] A, int[] B) {
        int[] edges = fillEdges(N, A, B);
        return checkPath(N, edges);
    }

    private static int[] fillEdges(int N, int[] A, int[] B) {
        int[] edges = new int[N + 1];
        for (int i = 0; i < A.length; i++) {
            if (A[i] + 1 == B[i]) {
                edges[A[i]] = B[i];
            } else if (B[i] + 1 == A[i]) {
                edges[B[i]] = A[i];
            }
        }
        return edges;
    }

    private static boolean checkPath(int N, int[] edges) {
        for (int i = 1; i < N; i++) {
            if (edges[i] != i + 1) {
                return false;
            }
        }
        return true;
    }
}
```

Hash Map implementation

```java
import java.util.*;

public class Main {
    public static void main(String[] args) {
        System.out.println(hasPath(4, new int[]{1,2,4,4,3}, new int[]{2,3,1,3,1}));  // It will print true
        System.out.println(hasPath(4, new int[]{1,2,1,3}, new int[]{2,4,3,4}));  // It will print false
        System.out.println(hasPath(6, new int[]{2,4,5,3}, new int[]{3,5,6,4}));  // It will print false
    }

    public static boolean hasPath(int N, int[] A, int[] B) {
        HashMap<Integer, Integer> edges = fillEdges(N, A, B);
        return checkPath(N, edges);
    }

    private static HashMap<Integer, Integer> fillEdges(int N, int[] A, int[] B) {
        HashMap<Integer, Integer> edges = new HashMap<>();
        for (int i = 0; i < A.length; i++) {
            if (A[i] + 1 == B[i]) {
                edges.put(A[i], B[i]);
            } else if (B[i] + 1 == A[i]) {
                edges.put(B[i], A[i]);
            }
        }
        return edges;
    }

    private static boolean checkPath(int N, HashMap<Integer, Integer> edges) {
        for (int i = 1; i < N; i++) {
            if (!edges.getOrDefault(i, -1).equals(i + 1)) {
                return false;
            }
        }
        return true;
    }
}
```

You have just rolled a dice several times. The N roll results that you remember described by an array A. However, there are F rolls whose results you have forgotten. The arithmetic mean of all of the roll results ( the sum of all the roll results divided by the number of rolls) equals M.

What are the possible result of the missing rolls ?
Write a function that, given an array A of length N, an integer F and an integer M, returns an array containing possible results of the missed rolls. The returned array should contain F integers from 1 to 6 (valid dice rolls). If such an array does not exist then the function should return [0].

Examples:
1. Given A=[3,2,4,3], F=2, M=4, your function should return [6,6]. The arithmatic mean of all the rolls is (3+2+4+3+6+6)/6=24 / 6 = 4
2. Given A=[1,5,6], F=4, M=3, your function may return [2,1,2,4] or [6,1,1,1] (among others).
3. Given A=[6,1], F=1, M=1, your function should return [0]. It is not possible to obrain such a mean.

Write an effient algorithm for the following assumptions:
1. N and F are integers within the range [1...100,000]
2. Each element of array A is an integer within the range [1..6]
3. M is an integer within the range [1..6]

```matlab
import java.util.Arrays;

public class Main {
    private static final int MIN_DICE_ROLL = 1;
    private static final int MAX_DICE_ROLL = 6;

    public static void main(String[] args) {
        System.out.println(Arrays.toString(findMissingRolls(new int[]{3,2,4,3}, 2, 4)));  // It will print [6, 6]
        System.out.println(Arrays.toString(findMissingRolls(new int[]{1,5,6}, 4, 3)));  // It will print [1, 1, 1, 6]
        System.out.println(Arrays.toString(findMissingRolls(new int[]{6,1}, 1, 1)));  // It will print [0]
    }

    public static int[] findMissingRolls(int[] knownRolls, int numMissingRolls, int targetMean) {
        int totalRollsCount = knownRolls.length + numMissingRolls;
        int requiredSumToReachMean = totalRollsCount * targetMean;
        int currentSumOfKnownRolls = 0;

        for (int roll : knownRolls) {
            currentSumOfKnownRolls += roll;
        }

        int requiredSumOfMissingRolls = requiredSumToReachMean - currentSumOfKnownRolls;
        if (requiredSumOfMissingRolls < numMissingRolls || requiredSumOfMissingRolls > numMissingRolls * MAX_DICE_ROLL) {
            return new int[]{0};
        }

        int[] missingRolls = new int[numMissingRolls];
        Arrays.fill(missingRolls, MIN_DICE_ROLL);
        requiredSumOfMissingRolls -= numMissingRolls;

        for (int i = 0; i < numMissingRolls; i++) {
            int add = Math.min(MAX_DICE_ROLL - MIN_DICE_ROLL, requiredSumOfMissingRolls);
            missingRolls[i] += add;
            requiredSumOfMissingRolls -= add;
        }

        return missingRolls;
    }
}
```

While using git SHA of a commit will not change if you change only 
commit author
commit date
commit message 
<u>**none**</u>

while using git how would you check who is the last person thatmodified a line in a file
<u>**git blame
**</u>git fetch
git log
git diff

whice of the following will output hello ito the standard output
cat hello 
<u>**echo hello 
**</u>ls hello 
cp hello

while of the following should be put instead of ... so that the following script runs all python files in the current directory and all of its nested subdirectories
for ...
do
 python $i
done

A: $i in `find . | grep .py$`
<u>**B. i in `find . -name '*.py`**</u>
C: i in [find . | grep .py$]
D: $i in [find . | grep .py$]