---
notion-id: 3328be4f-670a-4bea-89da-a5ffb3554d1e
cover: "[[Software Engineering.jpeg]]"
---
[[University Courses on YT - ASU]]

### ❤️ <u>**The Basics**</u>:

[[OOP]]

[[Abstract Class and Interface]]

[[MVC]]

[[SOLID]]

[[Dry & Kiss]]

[[Design Patterns]]

[[Rails Clean Architecture]]

[[gRPC vs REST]]

### ❤️ <u>**Architecture, Patterns and Principles:**</u>

[[GraphQL vs REST]]

[[JWT vs Cookies]]

[[Authentication vs Authorization]]

[[Local Storage vs Session Storage vs Cookie]]

[[SSR vs CSR vs Pre-Rendering]]

[[SOLID Principles with Ruby]]

### ❤️ <u>**Common Questions:**</u>

[[Const vs Final]]

[[Data by headers]]

[[Unix Commands And Rails Structure]]

[[Concurrency And Parallelism]]

[[Cron Jobs]]

### ❤️ <u>**TODO:**</u>

[[Ngnix]]

[[TODO TDD  BDD  DDD]]

### ❤️ <u>Database</u><u>**:**</u>

[[Database Round]]

[[MongoDB]]

[[SQL ANSI]]

### ❤️ <u>Front End</u><u>**:**</u>

[[Angular]]

[[Front End]]

[[Building Micro-frontends with React]]

### <u>❤️ Data Structures:</u>

[[Grokking Algorithms]]

[[FE Masters]]

[[Interview]]

[[Microservices]]

[[Interview]]

[[Preparation]]

[[The Hard Parts of Servers & Node.js]]

[[Data structure & Algorithms]]