---
notion-id: b43c87c8-ec9a-40f4-9598-52be56179c17
base: "[[Concrete Class Vs Abstract Class.base]]"
Concrete Class: A concrete class cannot contain an abstract method.
---
