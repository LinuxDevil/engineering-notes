---
notion-id: 50e7a64a-fb1e-4603-8895-b55a2ecf923d
base: "[[Concrete Class Vs Abstract Class.base]]"
Concrete Class: A concrete class can be directly instantiated using the new keyword.
---
