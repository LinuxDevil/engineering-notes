---
notion-id: 96e48265-da94-4eab-9c12-f0eeb5335125
base: "[[Concrete Class Vs Abstract Class.base]]"
Concrete Class: A concrete class is not declared using abstract modifier.
---
