---
notion-id: 89029e66-1f62-4451-b6b8-5b34f0c65aad
base: "[[Concrete Class Vs Abstract Class.base]]"
Concrete Class: A concrete class can be declared as final.
---
