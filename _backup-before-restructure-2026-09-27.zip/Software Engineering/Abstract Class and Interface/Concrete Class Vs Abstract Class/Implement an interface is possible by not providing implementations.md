---
notion-id: 94f43e8d-f368-48aa-ac65-a34c3293b15d
base: "[[Concrete Class Vs Abstract Class.base]]"
Concrete Class: Easy implementation of all of the methods in the interface.
---
