---
notion-id: 3b3e31aa-b3ae-41e4-a2ca-12b9bf0239bc
cover: "[[Abstract Class and Interface.jpeg]]"
---
Abstract is about generalization and interfaces is about standardisation.

As we know that abstraction refers to hiding the internal implementation of the feature and only showing the functionality to the users. i.e. what it works (showing), how it works (hiding).

An **Abstract Class** is a class to hide the internal implementation of a feature and only showing the functionality to the users.

An **interface** is like a contract to ensure that the functions is overridden.

### **Abstract class vs Interface**

- **Type of methods:** Interface can have only abstract methods. An abstract class can have abstract and non-abstract methods. From Java 8, it can have default and static methods also.
- **Final Variables:** Variables declared in a Java interface are by default final. An abstract class may contain non-final variables.
- **Type of variables: **Abstract class can have final, non-final, static and non-static variables. The interface has only static and final variables.
- **Implementation:** Abstract class can provide the implementation of the interface. Interface can’t provide the implementation of an abstract class.
- **Inheritance vs Abstraction:** A Java interface can be implemented using the keyword “implements” and an abstract class can be extended using the keyword “extends”.
- **Multiple implementations:** An interface can extend one or more Java interfaces, an abstract class can extend another Java class and implement multiple Java interfaces.
- **Accessibility of Data Members:** Members of a Java interface are public by default. A Java abstract class can have class members like private, protected, etc.
- **An abstract class permits you to make functionality that subclasses can implement or override whereas an interface only permits you to state functionality but not to implement it**

Consider using <u>**abstract classes**</u> if any of these statements apply to your situation:

- In the java application, there are some related classes that need to share some lines of code then you can put these lines of code within the abstract class and this abstract class should be extended by all these related classes.
- You can define the non-static or non-final field(s) in the abstract class so that via a method you can access and modify the state of the object to which they belong.
- You can expect that the classes that extend an abstract class have many common methods or fields, or require access modifiers other than public (such as protected and private).

Consider using <u>**interfaces**</u> if any of these statements apply to your situation:

- It is total abstraction, All methods declared within an interface must be implemented by the class(es) that implements this interface.
- A class can implement more than one interface. It is called multiple inheritances.
- You want to specify the behavior of a particular data type but are not concerned about who implements its behavior.

![[Concrete Class Vs Abstract Class.base]]