---
notion-id: 1fad91f9-7a99-80e7-85ab-d5fb247136f8
cover: "[[System design.jpeg]]"
---

The FE system design is about 

- API Communication
- UI Data Management
- User Interface Interactions
- Assets Management

## Part 1 | Core Fundamentals

 
