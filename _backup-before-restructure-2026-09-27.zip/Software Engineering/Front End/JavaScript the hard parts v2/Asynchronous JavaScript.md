---
notion-id: 3ce8800c-44ee-44c0-b38e-09ce2beb1170
cover: "[[Asynchronous JavaScript.jpeg]]"
---

Asynchronicity is the backbone of Modern web development.

![[Screenshot_2023-09-02_at_8.56.42_PM.png]]

JS is a single threaded language (One command at a time), synchronously executed (each line is run in order the code appears in)



![[Screenshot_2023-09-02_at_8.57.11_PM.png]]