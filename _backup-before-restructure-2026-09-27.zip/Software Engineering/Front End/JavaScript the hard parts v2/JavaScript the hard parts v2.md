---
notion-id: f372a9d1-f76a-4ce2-bd7e-e4abeb4b165a
cover: "[[JavaScript the hard parts v2.jpeg]]"
---
![[javascript-hard-parts-v2.pdf]]

[[Software Engineering/Front End/JavaScript the hard parts v2/Principles]]

[[Software Engineering/Front End/JavaScript the hard parts v2/Functions & Callbacks]]

[[Software Engineering/Front End/JavaScript the hard parts v2/Closures]]

[[Software Engineering/Front End/JavaScript the hard parts v2/Asynchronous JavaScript]]
