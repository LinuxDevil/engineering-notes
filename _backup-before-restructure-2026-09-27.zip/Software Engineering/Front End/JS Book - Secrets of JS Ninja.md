---
notion-id: 21dd91f9-7a99-8063-8293-f588ae9f30c6
---

Generators: Functions that generate multiple values on per-request and can suspend their execution.

Proxies: Allows us to control access to certain objects

Transpilers: Transformation + Compiling (They give us access to tomorrow’s JS today), they take current code and transform it into equivalent (or similar) code that works properly in most current browsers.
	- Babel (babeljs.io)
	- Traceur (google/traceur-compiler)

Document Object Model (DOM): Is a structured representation of the UI of a client application that is built from the HTML code of a web app.

