---
notion-id: 002fe188-d0bc-403c-93aa-1d9aa16a9a10
cover: "[[Asynchronous JavaScript.jpeg]]"
---

Asynchronicity is the backbone of Modern web development.

![[Screenshot_2023-09-02_at_8.56.42_PM.png]]

JS is a single threaded language (One command at a time), synchronously executed (each line is run in order the code appears in)



![[Screenshot_2023-09-02_at_8.57.11_PM.png]]