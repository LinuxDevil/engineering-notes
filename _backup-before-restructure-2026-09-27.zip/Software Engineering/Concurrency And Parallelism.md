---
notion-id: 8ef9391e-883c-4465-b877-f067abe19cd7
cover: "[[Concurrency And Parallelism.jpeg]]"
---


- Parallelism → Doing more than one thing at the same time
![[Untitled 24.png]]
- Concurrency → The illusion of doing more than one thing at the same time
![[Untitled 25.png]]

### Processes

An instance of a running program.

![[Untitled 26.png]]

At least one process (Can be more) per tech that has a separated memory space that can’t access another tech process.

Tech with multiple process (Process model for tech) [Node] will have more space and take more resources than one process tech [Java].

In a single core environment the concurrency can be achieved by context switching, in multi-core environment concurrency is achieved by by parallelism.

### Interprocess communication

Ways of interprocess communications:
	- File (Memory mapped)
All processes will access the same file at the same time
Process → File ← Process (You can do that with memory mapped file [Portion of ram for the file]).
	- Signals
You can send signals to the process like SIGKILL/SIGEXIT 
But you can send only one signal per process  
	- Socket (Unix domain Socket)
There are two types of sockets (Unix domain socket (Limited to the same machine, you can’t access remote machines) and Network socket(Remote calls (like broswser access the server)) 
Client (Process) Connect—>←Listen Server (Process) 
Both processes connect
	- Pipe
Every Process have standard input and standard output that is connected via a pipe (Processes grep captures the output of the ls via a pipe)
ls | grep hello 
[ls]  -Standard Out—>(Connected via a pipe)← Standard In — [Grep] — Standard Out> 
	- Shared Memory
	- Message passing

### Threads

Is the smallest unit of task that can be executed be an OS.

![[Untitled 27.png]]

A Thread is what execute your code, every process will create at least one thread.

Process has ⇒ 
	- Code execution thread(s)
	- Garbage collection threads(s)
	- Network
	- Other Thread

Thread is lighter than a process and different thread can run in different CPU’s in parallel

Thread anatomy (Stack & Heap) 

→ Every thread has
    Process 
    Heap (All memory of the process is stored here [Memory leak is here] and shared between all threads)
    Thread 
        Stack (Stores the local variable and meta params and call chain)

Threads overhead

- When you want to create a Thread per user, this is called Thread per request model the problem with this approach is costly
- Spawning a new thread is relatively slow 
- OS limit the number of threads 
- Each thread consumes memory (In Java every thread takes 1MB)
- Contention (Fight/Compete) It happens when two threads try to access either the same resource or related resource in a way that at least one of the threads runs more slowly than it would if other threads are not running 
	- Locks (Threads will compete to take the lock)
	- CPU Time (Threads will compete to take the run)
	- Shared Resources 


### Thread-pools 

Sacrifice availability to make the system more reliable (Stable) 

(How to limit the number of threads) (Manager for the threads) If not the maximum number of threads are reached, he will create another thread, if not it will wait for a thread to finish and routes you to it or exit it and create a new one.

How concurrency related to parallelism?

- Concurrency and parallelism refers to computer architecture which focus on how our task is performed

### Synchronous

Executing tasks one after the other

In singular thread

![[Untitled 28.png]]

In Multiple thread

![[Untitled 29.png]]

### Asynchronous

You can switch to a different running task without waiting for the previous one to complete.

In Single thread

![[Untitled 30.png]]

In Multi thread

![[Untitled 31.png]]

- Async programming model helps us to achieve concurrency 
- Async programming in multi-threaded environment is a way to achieve parallelism.

# **Summing up**

## **Concurrency and Parallelism ->**

Way tasks are executed.

## **Synchronous and Asynchronous ****>**

Programming model.

## **Single Threaded and Multi-Threaded**** ->**

The environment of task execution.