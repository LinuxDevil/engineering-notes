---
notion-id: 54f4c8b0-cd6a-4886-a4a7-d1cd8e687bc9
cover: "[[Cron Jobs.jpeg]]"
---
Same as what you did in schedule tasks “Spring boot”

[https://www.hivelocity.net/kb/what-is-cron-job/](https://www.hivelocity.net/kb/what-is-cron-job/)

[https://dev.to/risafj/cron-jobs-in-rails-a-simple-guide-to-actually-using-the-whenever-gem-now-with-tasks-2omi](https://dev.to/risafj/cron-jobs-in-rails-a-simple-guide-to-actually-using-the-whenever-gem-now-with-tasks-2omi)

[https://www.adminschoice.com/crontab-quick-reference](https://www.adminschoice.com/crontab-quick-reference)

 https://github.com/javan/whenever 

[https://www.airplane.dev/blog/docker-cron-jobs-how-to-run-cron-inside-containers](https://www.airplane.dev/blog/docker-cron-jobs-how-to-run-cron-inside-containers)

# What is Cron Job?

A **cron job** is a Linux command used for scheduling tasks to be executed sometime in the future. This is normally used to schedule a job that is executed periodically – for example, to send out a notice every morning. Some scripts, such as Drupal and WHMCS may require you to set up cron jobs to perform certain functions.

So, in a nutshell: 
    A cron job is a scheduling command to setup an action to be run in the future.

For most cron jobs, there are three components present:

1. The script that is to be called or executed.
2. The command that executes the script on a reoccurring basis. This is typically set in [cPanel](https://www.hivelocity.net/blog/cpanel-what-you-need-to-know/).
3. The action or output of the script, which depends on what the script being called does. Frequently, scripts called as cron jobs modify files or databases. However, they can perform other tasks that do not modify data on the server as well, such as sending out email notifications.

Most scripts that require the use of a cron job will give you specific instructions on what needs to be setup, frequently giving examples.

Now, let’s see what are Cronjobs with rails. “**Whenever gem”**

# What are cron jobs?

Cron is a job scheduler that lets you execute recurring tasks at fixed times (e.g. every minute, every hour, every day at 3pm).Jobs are written in a file called the [crontab](https://www.adminschoice.com/crontab-quick-reference) (short for “cron table”), typically saved here: `/usr/bin/`

# Use whenever for cron jobs in Rails

[`Whenever`](https://github.com/javan/whenever) is a gem that helps you set up cron jobs. Instead of having to manually edit the crontab yourself, you can let `whenever` update the crontab for you by writing your jobs in Ruby code. You'll make your edits in `schedule.rb`

**Note:** One thing worth mentioning is that the actual task itself (in my case, sending out batch messages periodically) should *not* be written in the crontab, or in `schedule.rb`, the Rails file for writing in your crontab. The task itself should be written separately as a Rake task. You can then schedule that Rake task on a regular basis as a cron job.
