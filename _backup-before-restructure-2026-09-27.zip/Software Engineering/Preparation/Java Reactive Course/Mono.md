---
notion-id: e9b12071-aab2-4305-9221-46779496dcbd
---

Publisher → Mono<T> & Flux<T>

Publisher can also no emit any value

Mono can emit 0 or 1 item followed by an onComplete / onError

Mono —> Subscriber

Flux Can emit 0 or N item (A stream) followed by onComplete / onError

Flux → Subscriber

Streams are lazy, it wont do anything unless it is connected to a terminal operator (like foreach)

Similar in RP, `Nothing happens until you subscribe`

The Mono.just method actually invokes the function even without subscribers, you can use just when you have data already! otherwise don’t.

use fromSupplier, you only want to do the work if a subscriber subscribe.

The default behaviour of Reactor is that it runs on the main thread
