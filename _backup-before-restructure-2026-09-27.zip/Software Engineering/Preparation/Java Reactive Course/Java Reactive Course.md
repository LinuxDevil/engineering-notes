---
notion-id: 4c7a4700-77ea-4f02-b78d-969e17485965
---
There are four different I/O models
The insurance company call with waiting example

1. Sync + Blocking (Default)
2. Async (It hires another thread so it can free itself from the actual task)
3. Non-Blocking (low level calling)
4. Non-blocking + Async (Hyped approach) 

[[Mono]]
