---
notion-id: d62cf505-c3ea-4f24-944b-a84127fb7c07
---

Java Refresher,
    Type inference: Now you can use the var so that we can get types to be inferred  
```typescript
Customer customer = new Customer();
// Can now be
var customer = new Customer();
```

    Lambda: is to method definition  what anonymous classes are to class definitions.
    You can create your own functional interface
```typescript
@FunctionalInterface
interface MyHandler {
	String handle(int one, Date two);
}

// This can be expressed in Java as follows
MyHandler handler = (one, two) -> "Hello";

void process(MyHandler m);
process((one, two) -> "Hello");
```
    If you want to cut out the intermediate lambda, you can use delegate (method reference) 
```typescript
class Delegate {
	String pleaseHandle(int one, Date two) {
		return one + " : " + two;
	}
}

// This can be expressed as follows:
Delegate delegate = new Delegate();
process(delegate::pleaseHandle);
```
	1. **Abstract Class**: An abstract class in Java is a class that can't be instantiated, which means you cannot create an object of an abstract class. It can contain abstract methods (methods without a body) as well as concrete methods (regular methods with a body). The purpose of an abstract class is to be extended (subclassed) by other classes, providing a common template for them.
	2. **Interface**: An interface is a completely abstract class that can only contain abstract methods (though since Java 8, interfaces can contain default and static methods). A class can implement any number of interfaces. An interface is used to define a contract for subclasses to follow or to act as a common way for classes to share public constants. Unlike classes, interfaces are not part of the class hierarchy and `**interface**` contracts can be implemented by any class from any inheritance tree.
	3. **Functional Interface**: This is an interface that contains exactly one abstract method (they may still contain other static or default methods). The purpose of a functional interface is to be used as the type for a lambda expression or method reference. A common example is the `**Runnable**` interface, which has a single `**run()**` method.
	4. **Method References**: A method reference is a feature from Java 8 onwards that provides a way to reference a method without executing it. It's often used to create more concise lambda expressions. For example, instead of providing a lambda expression that calls `**System.out.println**`, you can use the method reference `**System.out::println**`. Method references can reference static methods, instance methods, and constructors.

|   | **Abstract Class** | **Interface** | **Functional Interface** | **Method Reference** |
| --- | --- | --- | --- | --- |
| Definition | A class that can't be instantiated and is meant to be extended by other classes. | A template for a class that contains behaviors a class promises to implement. | An interface that contains exactly one abstract method. | A reference to a method without executing it. |
| Java Keyword | `**abstract**` | `**interface**` | `**interface**` with `**@FunctionalInterface**` annotation | `**::**` operator |
| Example | `**public abstract class Animal { abstract void makeSound(); }**` | `**public interface Flyable { void canFly(); }**` | `**@FunctionalInterface public interface Runnable { void run(); }**` | `**System.out::println**` |
| Can contain methods with implementation | Yes | Since Java 8, default and static methods allowed | Since Java 8, default and static methods allowed | No |
| Can contain abstract methods | Yes | Yes | Exactly one | No |
| Can be instantiated | No | No | No | No |
| Can be extended/implemented by a class | Yes, extended | Yes, implemented | Yes, implemented | No, but can be used to create instances of functional interfaces |
| Purpose | To provide a common template for subclasses | To define a contract for classes | To be used as the type for a lambda expression or method reference | To reference a method without executing it, often used with lambda expressions or functional interfaces |
