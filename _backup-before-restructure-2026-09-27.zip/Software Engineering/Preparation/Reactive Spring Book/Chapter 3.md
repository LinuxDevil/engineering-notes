---
notion-id: d8e2a18d-783e-4f7c-a1b0-c52f66e75f4a
---
DI, IoC, Java Configuration, Spring application context, aspect-oriented-programming and Spring Boot auto configuration.

Starter Libraries/Packages:
    Web → Brings everything to build a web application based on the servlet specification and traditional spring MVC, it brings Form validation, JSON/XML marshalling, websocket support, REST and HTTP-Controller support.

    JDBC → Supports JDBCTemplate for working with SQL-based databases.

    Lombok → Compile-time annotation processor that synthesizes things like getter, setter, toString …etc

    Actuator → Contributes HTTP Endpoints to state the health of the application.

    TransactionTemplates let’s u commit a transaction or fail not if you throw an exception.


Spring is just a big bag of beans.

`@Configuration` class. It is a class that has methods annotated with `@Bean` whose return values are objects to be stored and made available for other objects in the application context

`BeanPostProcessor` is a callback interface. It provides two (default) methods. Here, our class overrides postProcessAfterInitialization which is invoked for every object in the Spring application. We interrogate the type of the object, to confirm it’s a DataSource of some sort, and then we initialize it. This way it doesn’t matter how or where the DataSource is created, the BeanPostProcessor ensures it is properly initialized. Spring has other lifecycle events and associated callback interfaces that might be interesting that you’ll see from time to time. BeanPostProcessor is one of the more common.

Spring supports a command line argument, `—spring.profiles.active=prod`

Spring can *implicitly *learn the wiring of objects in the application graph if we let it perform component
scanning when the application starts up. If we added the @ComponentScan annotation to our application,
Spring would discover any objects in the current pacakge, or beneath it, that had identifying marker -
or "stereotype" - annotations


When Spring finds such an annotated object it’ll inspect the constructor(s). If it finds no constructor it’ll instantiate an instance of the application using the default constructor. If it finds a single constructor with no arguments, it’ll instantiate that. If it finds a constructor arguments whose values may be satisfied by other objects in the Spring application (the same way that they might for our bean definition provider methods), then Spring will provide those collaborating objects. If it finds multiple, ambiguous constructors, you can tell Spring which constructor to use by annotating that constructor with the @Autowired annotation to disambiguate it from other constructors.

