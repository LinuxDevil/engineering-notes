---
notion-id: f12aaeba-d78b-4c6a-b919-e180344c83a9
---
Reactive programming offers a solution to a reasonably old problem: how do we handle more users? How do we scale? How do we make more efficient use of our threads? **Reactive programming supports cooperative multithreading**

Reactive programming requires that we rewrite our code to signal to the runtime when we’re using or not using a given thread

Reactor moves the flow of execution from one thread to another in the course of its work. It’s a scheduler

Message queues are a critical component of a distributed system. They ensure that decoupled components remain alive by buffering the messages, allowing the consumers of those messages to consume the messages as they can, and no faster. This regulated consumption of data is flow control.




In the world of reactive programming, flow control is sometimes referred to as ***backpressure***. It ensures that data is **consumed at a regulated rate** so that consumers are <u>not overwhelmed</u> with data. This is achieved by using message queues to buffer messages and allow consumers to consume them as they can, and no faster. The subscriber controls the flow of data and requests more data with the `request(int)` method. The publisher will not produce more data than the amount for which the subscriber has asked. If the subscriber is ever overwhelmed, it has only itself to blame.

The Reactive Streams specification consists of four interfaces and a single class. Let’s look at **the four interfaces**

1. *The Reactive Streams ***Publisher**<T> *interface.
*The first interface, Publisher<T>, *publishes *- broadcasts! - data (of type T) to a Subscriber<T>.
2. *The Reactive Streams ***Subscriber**<T> *interface.
As soon as a Subscriber<T> subscribes, it receives a Subscription, which is arguably the most crucial class from the whole Reactive Streams specification.*
3. *The Reactive Streams *Subscription *interface.
*The Subscription, which the Subscriber<T> receives in the onSubscribe method, is unique for each
Subscription. New Subscriber<T> instances create new Subscription instances. The subscribers will
have three distinct subscriptions. A subscription is a link between the producer and the consumer, the
Publisher<T> and the Subscriber<T>. The Subscriber<T> uses the Subscription to request more data with
the request(int) data. This last point is critical: the subscriber controls the flow of data, the *rate *of
processing. The publisher will not produce more data than the amount for which the subscriber has
asked. The subscriber can’t be overwhelmed (and if it is ever overwhelmed, it has only itself to blame)
4. *The Reactive Streams *Processor<T,R> *interface.*
Processor<T> is the last interface in the Reactive Streams specification. It is just a bridge, implementing
both Publisher<T> and Subscriber<T>. It is a producer *and *a consumer, a source *and *a sink. That’s it.
5. FlowAdapters 
is a concrete class that helps you adapt the Reactive Streams types interchangeably to and from the Java 9 Flow. analogs

Reactor provides two specializations of Publisher<T>. The first, Flux<T>, is a Publisher<T> that produces zero or more values. It’s unbounded. The second, Mono<T>, is a Publisher<T> that emits zero or one value.


Both **Mono<T> **and **Flux<T>** implement **Publisher<T>** we recommend that your methods accept Publisher<T> instances but return Flux<T> or Mono<T>*
-

In the Reactor world, we say that a stream emits *signal*. Each time it emits a new message, that’s a
signal. Each time a subscriber gets a new subscription, that’s a signal. Each time a stream aborts
abnormally, that’s a signal. A Signal is a concept and a part of the interface for these types, and we’ll
see later that we can listen for these signals.


There are four different I/O models
The insurance company call with waiting example

6. Sync + Blocking (Default)
7. Async (It hires another thread so it can free itself from the actual task)
8. Non-Blocking (low level calling)
9. Non-blocking + Async (Hyped approach) 