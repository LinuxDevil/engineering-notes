---
notion-id: 7abf7fa2-67a4-40bc-920d-c765659704d0
---
Reactive programming is an approach to writing software that embraces asynchronous input and output (IO).

The idea behind reactive programming is to utilise unused resouces that would be idle as they wait for I/O (a client of a stream of data is notified of new data instead of asking for it)

We can’t have true concurrency beyond the number of cores on our machine.

Threads in Java, .NET, and other popular runtimes like Python and Ruby, are backed by operating system threads that the operating system schedules They have context associated with each one of them. By default, it’s 1MB of stack space on the JVM

It’s worth mentioning that platforms like the JVM, .NET and others take a natural middle-of-the-road approach to concurrency. Delegating to the operating system is a safe bet that leads to predictable results and requires very little in the way of concessions from the programmer

If it’s CPU-bound (e.g.: fibonacci, bitcoin mining, or cryptography) then reactive programming won’t buy us anything.

Reactive Streams Initiative defines four types:

Subscriber<T>

Publisher<T>

Subscription<T>

Processor<T>

Those types are useful, but they do one thing and one thing only, really well: move data from producer to consumer

1. `**Publisher<T>**`: A publisher is a provider of a potentially unbounded number of sequenced elements, publishing them according to the demand received from its `**Subscriber(s)**`. The `**Publisher**` can serve multiple `**Subscribers**` subscribed `**subscribe(Subscriber)**` dynamically at various points in time.
2. `**Subscriber<T>**`: A subscriber is a receiver of signals (data elements, error signals, or completion signals) from a `**Publisher**`. It has methods for handling subscriptions (`**onSubscribe(Subscription)**`), elements (`**onNext(T)**`), errors (`**onError(Throwable)**`), and stream completion (`**onComplete()**`).
3. `**Subscription**`: A subscription represents a one-to-one lifecycle of a `**Subscriber**` subscribing to a `**Publisher**`. It is used to both signal desire for data and allows the `**Subscriber**` to cancel demand (and allow resource cleanup).
4. `**Processor<T,R>**`: A processor represents a processing stage, which is both a `**Subscriber**` and a `**Publisher**` and obeys the contracts of both. It represents a stage in a processing pipeline that both consumes and produces data.

The type parameter `**T**` represents the type of item being processed by the `**Publisher**`, `**Subscriber**`, and `**Processor**`. The `**Subscription**` interface does not take a type parameter as it only deals with the mechanics of subscription and not the data being passed. In the `**Processor<T, R>**` interface, `**T**` is the type of item being consumed (input) and `**R**` is the type of item being produced (output).