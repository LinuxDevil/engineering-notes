---
notion-id: b9615e2b-c4da-4bd3-bd3b-106b9a3493c0
---

—> Article
    jOOQ is a java library that builds type-safe queries, it has generators for DAO’s and POJOs to effectively complete CRUD.

    Why jOOQ?
		- Code Generation (JPA-annotated entity classes)
		- Type Safety SQL (Embed SQL as internal domain-specific language)
		- Database First
		- Domain-Specific language

