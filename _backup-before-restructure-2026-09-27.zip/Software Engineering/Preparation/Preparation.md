---
notion-id: 7ca3e9cd-caaf-4305-b3fe-ae539435cf7e
---

Integration

SpringBoot

Reactive Programming (Reactor)

[[Reactive Spring Book]]

[[Java Reactive Course]]

PostgreSQL

jOOQ

[[jOOQ (java Object Oriented Querying)]]

OOP

System Design

Distributed Systems 

Message Brokers

High Available and stable by pub-sub

SOLID & Code Principles

[[Problem Solving]]