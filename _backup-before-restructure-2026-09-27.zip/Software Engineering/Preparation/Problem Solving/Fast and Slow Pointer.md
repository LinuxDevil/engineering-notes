---
notion-id: af8ef600-0adf-448c-b2f6-6cf1f5478e30
---

Also known as Tortosie and Hare algorithm / Floyd’s Cycle Detection Algorithm

uses two pointers to determine some traits about Linked List, Array, Graph (Cycle or middle or flatting)

Slow pointer travels one node at a time

Fast pointer travels two nodes at a time

To implement the algo, the tow pointers starts at a location (head in case detecting a loop), then with each iteration the two pointers will advance to different locations (They can move at any rate as long as the rates are different)

```java
Node slow = head, fast = head;

while (fast != null && fast.next != null) {
	slow = slow.next; // 1 move
	fast = fast.next.next; // 2 moves
	// Logic for the problem
}
// Logic for the problem
```

If the two pointer never meet then there is no cycle.

Problem 1: Find the middle of the Linked List

```java
Node fast = head, slow = head;

while (fast != null && fast.next != null) {
	slow = slow.next;
	fast = fast.next.next;
}

return slow;
```

**O(N + N/2)**

Problem 2: Detect Cycles in Linked List:

```java
Node fast = head, slow = head;

while (fast != slow) {
	if (fast == null || fast.next == null) {
		return false;
	}
	fast = fast.next.next;
	slow = slow.next;
}
return true;
```

Time complexity of the above approach will be O(N) with space complexity as O(1).

Find k-th element from the end

```java
Node findKthFromEnd(int k) {
    if (head == null) {
        return null;
    }
    
    int length = 0;
    
    Node temp = head;
    while (temp != null && temp.next != null) {
        temp = temp.next;
        length++;
    }
    
    if (k > length) return null;

    temp = head;
    
    for (int i = 0; i < length - k + 1; i++)  {
        temp = temp.next;
    }        
   
    return temp;
}
```

Reverse Between

```matlab
public void reverseBetween(int m, int n) {
        // Return if the list is empty
        if (head == null) return;

        // Create a dummy node and connect it to the head
        Node dummy = new Node(0);
        dummy.next = head;
        Node prev = dummy;

        // Move prev to the node just before the sublist
        for (int i = 0; i < m; i++) {
            prev = prev.next;
        }

        // Set current to the first node of the sublist
        Node current = prev.next;

        // Reverse the sublist iteratively
        for (int i = 0; i < n - m; i++) {
            // Save the next node in the original order
            Node temp = current.next;
            // Update current's next to skip temp
            current.next = temp.next;
            // Reverse the order of temp and current
            temp.next = prev.next;
            // Update prev's next to maintain reversed order
            prev.next = temp;
        }

        // Update the head of the list
        head = dummy.next;
    }
```
