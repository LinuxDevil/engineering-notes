---
notion-id: 236c456a-51ac-43a9-a5c7-97ae686e3d09
---

[[Fast and Slow Pointer]]