---
notion-id: bd50dc71-2086-44f0-b987-0256d8862e91
cover: "[[MVC.jpeg]]"
---
Model View Controller Arch. was “Thing Model View Editor”
![[Untitled 18.png]]
    **MVC** is a pattern for the <u>architecture</u> of a software application. It separates an application into the following components:
		1. **Models** for handling data and business logic.
		2. **Controllers** for handling the user interface and application.
		3. **Views** for handling graphical user interface objects and presentation.
    This separation results in user requests being processed as follows:
![[Untitled 19.png]]
		1. The browser (on the client) sends a <u>request</u> for a page to the <u>controller</u> on the server.
		2. The <u>controller</u> retrieves the data it needs from the <u>model</u> in order to respond to the request.
		3. The <u>controller</u> gives the retrieved data to the <u>view</u>.
		4. The <u>view</u> is rendered and sent back to the client for the browser to display.
        ## **Model**
        It is known as the lowest level which means it is responsible for maintaining data. Handle data logically so it basically deals with data. The model is actually connected to the database so anything you do with data. Adding or retrieving data is done in the model component. It responds to the controller requests because the controller never talks to the database by itself. The model talks to the database back and forth and then it gives the needed data to the controller. Note: the model never communicated with the view directly.
        ## **View**
        Data representation is done by the view component. It actually generates UI or user interface for the user. So at web applications when you think of the view component just think the Html/CSS part. Views are created by the data which is collected by the model component but these data aren’t taken directly but through the controller, so the view only speaks to the controller.
        ## **Controller**
        It’s known as the main man because the controller is the component that enables the interconnection between the views and the model so it acts as an intermediary. The controller doesn’t have to worry about handling data logic, it just tells the model what to do. After receiving data from the model it processes it and then it takes all that information it sends it to the view and explains how to represent to the user. Note: Views and models can not talk directly.

    **The MVC Cycle**
    Although MVC comes in different flavors, control flow generally works as follows:
		1. The user interacts with the interface and triggers a request to the server (e.g., submits a registration form).
		2. The server routes the request to a controller, passing any data that was sent by the user’s request.
		3. The controller may access one or more models, perhaps manipulating and saving the data in some way (e.g., by creating a new user with the form data).
		4. The controller invokes a view template that creates a response to the user’s request, which is then sent to back to the user (e.g., a welcome screen).
		5. The interface waits for further interaction from the user, and the cycle repeats.
![[314622_4_En_1_Fig1_HTML.jpeg]]


