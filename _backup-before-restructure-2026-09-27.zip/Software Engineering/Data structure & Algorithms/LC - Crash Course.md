---
notion-id: 2c1d91f9-7a99-808a-942a-e1e556b2efa9
cover: "[[LC - Crash Course.jpeg]]"
---

# Sliding Window

Sliding window is all about sub-arrays, each subarray is defined by the left bound and the right bound which will make a sub array which is called here “window”

![[image 17.png]]

