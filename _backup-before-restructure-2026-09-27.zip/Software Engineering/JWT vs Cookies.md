---
notion-id: d59ca861-8fa5-40e5-9fc8-18d35a07ad3a
cover: "[[JWT vs Cookies.jpeg]]"
---

There are primarily two different approaches to **session management,**

- **Session or Cookies based approach**
- **JWT (JSON Web Tokens) based approach**

**Session Cookie based approach:**

```plain text
1. Server generates a"sessionId" (signs it using "secret key"), and
(a) saves the sessionId in asessionDB, and
(b) sends a cookie with the sessionId to the browser (client side).
2. The browser (client side) receives the "cookie" in the response from server, and saves it in the "cookie" storage. 
3. The browser then includes the "cookie" within every subsequent request to the server.
```

**JWT JSON Web Token approach:**

```plain text
1. Server generates an"accessToken", encrypting the "userId" and "expiresIn", with the ACCESS_TOKEN_SECRET,
and sends the "accessToken" to the browser (client side).
2. The browser (client side) receives the "accessToken" and saves it on the client side.
3. The "accessToken" is included in every subsequent request to the server.
```