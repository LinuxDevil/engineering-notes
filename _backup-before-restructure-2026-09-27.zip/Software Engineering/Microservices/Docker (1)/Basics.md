---
notion-id: 4c94de6e-ab9c-4cef-ae25-1bad44701bd4
cover: "[[Basics.jpeg]]"
---
[[diagrams.xml]]

Open in draw.io

Usually when people refer to docker, they refer to the of docker ecosystem 

![[Screenshot_2023-04-08_at_6.22.49_PM.png]]

Image → Single file that contains the configurations and dependencies required to run a program

Container → Instance of an image.

Docker CLI (Client) —> Tool that we issue commands to

Docker Daemon (Server) —> Tool that is responsible for creating images, running containers, etc..

![[Screenshot_2023-04-08_at_6.26.31_PM.png]]

Container

![[Screenshot_2023-04-10_at_6.48.26_PM.png]]

![[Screenshot_2023-04-10_at_6.50.35_PM.png]]


So how’s docker running on my MAC/Windows ?

![[Screenshot_2023-04-10_at_6.52.22_PM.png]]

Docker running on Linux? 

Containers —> Linux Kernal —> Hardware

![[Screenshot_2023-04-10_at_6.53.13_PM.png]]

Create and Run a container from an image

```bash
docker run <image name>
```

![[Screenshot_2023-04-10_at_6.55.40_PM.png]]

Let’s run

```bash
docker run hello-world
```

This is what happened:

![[Screenshot_2023-04-10_at_6.56.18_PM.png]]

Create an run a container from an image with an override for the default command

```bash
docker run <image name> command
```

![[Screenshot_2023-04-10_at_6.58.45_PM.png]]

```bash
docker run busybox ls
```

![[Screenshot_2023-04-10_at_7.00.43_PM.png]]

So what happened ?

![[Screenshot_2023-04-10_at_7.01.07_PM.png]]

Listing all running containers

```bash
docker ps
```

![[Screenshot_2023-04-10_at_7.26.44_PM.png]]

![[Screenshot_2023-04-10_at_7.32.30_PM.png]]

![[Screenshot_2023-04-10_at_7.32.49_PM.png]]

List all containers created on this machine

```bash
docker ps --all
```

![[Screenshot_2023-04-10_at_7.34.20_PM.png]]

What is docker run anyway ?

it is a combination of docker create and docker start

![[Screenshot_2023-04-10_at_7.38.10_PM.png]]

Creating a container is just about setting up the files needed inside the container, installing the dependencies and make sure that everything in the image config is met

![[Screenshot_2023-04-10_at_7.41.49_PM.png]]

To start the container, we actually executing the startup command from the image

![[Screenshot_2023-04-10_at_7.43.03_PM.png]]


run them separately ?

```bash
docker create busybox
docker start -a <id of the created busybox container>
```

![[Screenshot_2023-04-10_at_7.39.47_PM.png]]

![[Screenshot_2023-04-10_at_7.43.43_PM.png]]

![[Screenshot_2023-04-10_at_7.44.09_PM.png]]

![[Screenshot_2023-04-10_at_7.44.52_PM.png]]

<u>**the -a is for making docker watch for the log of the started container, -attach**</u>

So basically the docker <u>**container**</u> lifecycle is 

![[Untitled 67.png]]

1. **Create**: A Docker container is created from an image using the `**docker run**` command. This command pulls the image from a registry (if it's not already available locally) and starts a new container instance based on that image.
2. **Start**: Once a container is created, it can be started using the `**docker start**` command. This command initializes the container's file system and starts the processes defined in the image.
*When you start a container with the default command or an override command, it can’t be changed unless you destroyed that container.*
3. **Run**: After a container is started, it is considered to be "running" until it is stopped or killed. During this stage, the container is executing its main processes and can be interacted with using the `**docker exec**` command.
4. **Pause**: The `**docker pause**` command can be used to pause a running container's processes. This can be useful for debugging or troubleshooting purposes.
5. **Unpause**: The `**docker unpause**` command can be used to resume a paused container's processes.
6. **Stop**: The `**docker stop**` command can be used to stop a running container's processes. This sends a SIGTERM signal to the container, allowing it to perform any necessary cleanup tasks before shutting down.
7. **Kill**: If a container does not respond to the SIGTERM signal, the `**docker kill**` command can be used to forcibly terminate the container's processes.
8. **Restart**: The `**docker restart**` command can be used to stop and start a container in one command. This can be useful for applying updates or configuration changes to a running container.
9. **Remove**: The `**docker rm**` command can be used to remove a stopped container from the system. This command removes the container's file system and any associated metadata.

And the docker <u>**image**</u> lifecycle:

10. **Create**: A Docker image is created using a Dockerfile, which contains instructions for building the image.
11. **Build**: The `**docker build**` command is used to build the image from the Dockerfile. This command reads the instructions in the Dockerfile and creates a new image based on those instructions.
12. **Push**: Once an image is built, it can be pushed to a Docker registry (such as Docker Hub) using the `**docker push**` command. This makes the image available to others for use and distribution.
13. **Pull**: Other users can pull the image from the registry using the `**docker pull**` command. This command downloads the image from the registry and makes it available for use on the user's local machine.
14. **Tag**: The `**docker tag**` command can be used to assign a tag (a human-readable name and version number) to an image. This makes it easier to identify and manage different versions of the image.
15. **Remove**: The `**docker rmi**` command can be used to remove an image from the local machine. This command deletes the image's file system and associated metadata.

To **delete** all exited (Stopped) containers and your image cache, you can run 

```bash
docker system prune
```

![[Screenshot_2023-04-10_at_11.51.11_PM.png]]

To get the logs of a container you can run (You are not re-running the container here)

```bash
docker logs <container id>
```

![[Screenshot_2023-04-10_at_11.53.47_PM.png]]

Stopping and killing containers

![[Screenshot_2023-04-10_at_11.56.27_PM.png]]

To stop a container

```bash
docker stop <container id>
```

![[Screenshot_2023-04-10_at_11.56.40_PM.png]]

When we issue a docker stop, we send a hardware signal SIGTERM (Terminate Signal) to the process, telling it to shutdown at its down. it is used to give the process a little bit of time to shut itself down and doing a cleanup.

if the container didn’t stop in 10 seconds docker will automatically fallback to the kill command and close it immediately.

![[Screenshot_2023-04-11_at_12.01.46_AM.png]]

To kill a container 

```bash
docker kill <container id>
```

![[Screenshot_2023-04-10_at_11.58.50_PM.png]]

When you issue a docker kill, we send a hardware signal SIGKILL (Kill Signal) to the process, telling it to shutdown immediately.

![[Screenshot_2023-04-11_at_12.02.11_AM.png]]

 

Running redis

```bash
redis-server
```

![[Screenshot_2023-04-11_at_12.03.52_AM.png]]

to talk with redis you need the redis-cli

```bash
redis-cli
```

Running redis in docker

```bash
docker run redis
```

and to run redis-cli in docker, you have to run the exec command for docker

![[Screenshot_2023-04-11_at_12.07.11_AM.png]]

```bash
docker exec -it <container id> <command>
```

the -it allows us to provide input to the container

- `**i**`: This flag stands for "interactive" and tells Docker to keep STDIN open even if not attached. This allows you to interact with the container's shell and provide input.
![[Screenshot_2023-04-11_at_12.11.58_AM.png]]
- `**t**`: This flag stands for "TTY" and tells Docker to allocate a pseudo-TTY (terminal) for the session. This enables you to see the output from the container's shell and use features such as command history and tab completion.

When you run `**docker exec -it <container id> <command>**`, Docker will attach an interactive terminal session to the specified container and execute the specified command inside the container. This allows you to run commands or interact with the shell inside the container as if you were logged in directly to the container's command line.

![[Screenshot_2023-04-11_at_12.10.30_AM.png]]

![[Screenshot_2023-04-11_at_12.11.00_AM.png]]

You can also get a shell access too with docker exec 

```bash
docker exec -it <container id> sh
```

![[Screenshot_2023-04-11_at_12.19.06_AM.png]]

Here you can get full terminal access through the container. to exit it you need to do ctrl+d

You can also use the -it with docker run

```bash
docker run -it busybox sh
```

Container isolation

Between 2 containers, they don’t share the file system. as each container is isolated with it’s own resources.


Creating Images

You need to create a Dockerfile, that will set how our container will behave, what programs it have and what it does when its launched

![[Screenshot_2023-04-11_at_4.35.25_AM.png]]

Docker Client —> CLI

Docker Server: Take the docker file and build an image

Creating a Dockerfile

![[Screenshot_2023-04-11_at_4.37.20_AM.png]]

Create a dockerfile

```bash
# Specify a base image 
FROM alpine

# Run some commands to install some dependencies
RUN apk add --update redis

# Tell the image what to do when it starts as a container
CMD ["redis-server"]
```

![[Screenshot_2023-04-12_at_1.14.46_AM.png]]

then inside your terminal run

```bash
docker build .
```

![[Screenshot_2023-04-11_at_4.45.04_AM.png]]

then to run it just do

```bash
docker run <container id>
```

![[Screenshot_2023-04-11_at_4.45.15_AM.png]]

So how did docker knew what to do ? interptted

```bash
FROM alpine
```

this here tells docker that we want to install. an operating system on it from the alpine image, or a startup image.

So why alpine?

Because it comes with preinstalled programs that are useful.

```bash
RUN apk add --update redis
```

This here the apk command is not a docker command but a Linux alpine command (Apache Package) to add. and update redis

the steps for the run and cmd is run in an intermidiate container 

![[Screenshot_2023-04-12_at_1.30.00_AM.png]]

![[Screenshot_2023-04-12_at_1.32.23_AM.png]]


So why to use docker build . ?

to give our dockerfile to the cli, and the . is the build context (the files that we want to encapsulate the files inside the container)

So why docker is fast when building <u>**again**</u> ?

Because it uses build cache from the previous build.

```bash
# Specify a base image 
FROM alpine

# Run some commands to install some dependencies
RUN apk add --update redis
RUN apk add --update gcc

# Tell the image what to do when it starts as a container
CMD ["redis-server"]
```

![[Screenshot_2023-04-12_at_1.41.47_AM.png]]

<u>**it only runs from the cache if the series of steps is not changed (Only the changed line and. on-down will be run without the cache).**</u>

Tagging an Image

![[Screenshot_2023-04-12_at_1.50.52_AM.png]]

→ You can create a container from. the. ran build 

```bash
docker run <container id>
```

So not to memorize the container id, the convention is:

![[Screenshot_2023-04-12_at_1.51.31_AM.png]]

```bash
docker build -t aligmohammad/dockerizing:latest .
```

Then you can run it like

```bash
docker run aligmohammad/dockerizing
```

If you didn’t. specify a version, it will take the latest.

If you want to manual generate image with docker commit.

You can create an image from a container without a dockerfile

Alpine in docker relm means that it is a small image and compact

```bash
docker run -it alpine sh
```

then inside the container

```bash
apk add --update redis
```


then in another terminal, to take a snapshot from that running container and asign a default command for it

```bash
docker commit -c 'CMD ["redis-server"]' <container id>
```

![[Screenshot_2023-04-12_at_2.01.09_AM.png]]

![[Screenshot_2023-04-12_at_2.00.55_AM.png]]


Let’s create a project with this knowledge

![[Screenshot_2023-04-12_at_2.02.55_AM.png]]

![[Screenshot_2023-04-12_at_2.10.59_AM.png]]

<u>**Port forwarding is a runtime constraint**</u>

![[Screenshot_2023-04-12_at_2.38.09_AM.png]]

![[Screenshot_2023-04-12_at_2.40.17_AM.png]]

Specificing Work directory 

![[Screenshot_2023-04-12_at_2.45.20_AM.png]]

```bash
# Specify a base image
FROM node:current-alpine3.16

# Specificing the working directory
WORKDIR /usr/app

# Copy the package.json file
COPY ./package.json ./

# Install some dependencies
RUN npm install

# Copy the rest of the files
COPY ./ ./

# Default command
CMD ["npm", "start"]
```
