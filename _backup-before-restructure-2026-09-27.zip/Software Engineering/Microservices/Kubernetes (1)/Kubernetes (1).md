---
notion-id: 4d4b19d2-9fb0-468a-a004-67fd9812cfe6
cover: "[[Kubernetes (1).jpeg]]"
---

[[Software Engineering/Microservices/Kubernetes (1)/Basics]]