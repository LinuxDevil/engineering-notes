---
notion-id: 4bfbab0d-5932-4a73-86c1-2bb945d99b51
cover: "[[Basics 1.jpeg]]"
---

**Kubernetes** is a tool for running a bunch of different containers, we give it some configuration to describe how we want our containers to run and interact with eachother.

To interact with Kubernetes cluster

```bash
kubectl
```


To create a container of the post in kubernetes

A Kubernetes **pod** is the smallest and simplest unit in the Kubernetes system. It is a <u>logical host</u> for one or more containers and represents a **single instance of an application**. A pod can contain one or more Docker containers, which are always co-located and co-scheduled on the same host machine. Containers within a pod share the same network namespace and can communicate with each other via localhost.

![[Screenshot_2023-04-12_at_3.20.09_AM.png]]

![[Screenshot_2023-04-12_at_3.26.48_AM.png]]

Configuring Kubernetes

We create config files to configure objects

![[Screenshot_2023-04-12_at_11.56.36_PM.png]]

First write the k8s for the container 

posts.yaml

```bash
apiVersion: v1
kind: Pod
metadata: 
  name: posts
spec:
  containers:
    - name: posts
      image: aligmohammad/posts:0.0.1
```

![[Screenshot_2023-04-13_at_1.12.21_AM.png]]

Then tell kubernetes to use this file

```bash
kubectl apply -f posts.yaml
```

In Kubernetes, the `**-f**` flag is used with the `**kubectl apply**` command to specify the path to a Kubernetes resource file in YAML or JSON format.

![[Screenshot_2023-04-13_at_1.20.27_AM.png]]

![[Screenshot_2023-04-13_at_1.10.22_AM.png]]

To view our pods running inside the cluster

```bash
kubectl get pods
```

![[Screenshot_2023-04-13_at_1.11.17_AM.png]]

Common Kubectl commands

[https://kubernetes.io/docs/reference/generated/kubectl/kubectl-commands#apply](https://kubernetes.io/docs/reference/generated/kubectl/kubectl-commands#apply)

![[Screenshot_2023-04-13_at_1.17.46_AM.png]]

Usually people don’t create pods that way, instead the use the deployment

Deployment doesn’t run code, it just manage the pods

![[Screenshot_2023-04-13_at_1.30.54_AM.png]]

It has 2 main jobs
	- If any pod shutdown, the deployment will re-create it
	- For versioning and updating it 
![[Screenshot_2023-04-13_at_1.31.52_AM.png]]


Let’s create a deployment config file

```bash
apiVersion: apps/v1
kind: Deployment
metadata:
  name: posts-depl
spec:
  replicas: 1
  selector:
    matchLabels:
      app: posts
  template:
    metadata:
      labels:
        app: posts
    spec:
      containers:
        - name: posts
          image: aligmohammad/posts:0.0.1
```

- `**apiVersion**`: This specifies the Kubernetes API version being used by the deployment.
- `**kind**`: This specifies the type of Kubernetes resource, which in this case is a deployment.
- `**metadata**`: This section provides metadata about the deployment, such as its name.
- `**spec**`: This section specifies the desired state of the deployment, including the number of replicas, selector, and template.
- `**replicas**`: This specifies the desired number of replicas of the application to be running at any given time. In this case, it's set to 1.
- `**selector**`: This specifies the labels used to select the pods that the deployment is managing. In this case, the deployment selects the pods that have the label `**app: posts**`.
- `**template**`: This section specifies the pod template that will be used to create the pods for the deployment.
- `**metadata**`: This specifies the metadata for the pod template, including its labels.
- `**labels**`: This specifies the labels for the pod template, which in this case is the same as the selector labels.
- `**spec**`: This section specifies the specification for the containers in the pod template.
- `**containers**`: This specifies the containers that will be run in the pod. In this case, there is only one container named `**posts**` and it is using the Docker image `**aligmohammad/posts:0.0.1**`.

![[Screenshot_2023-04-13_at_1.58.50_AM.png]]

Deployment Commands

![[Screenshot_2023-04-13_at_2.20.48_AM.png]]

![[Screenshot_2023-04-13_at_2.21.04_AM.png]]

Ready: the number of pods that we are trying to create and the number of pods that are running

![[Screenshot_2023-04-13_at_2.22.09_AM.png]]

If you delete the pod, it will automatically get initiated

![[Screenshot_2023-04-13_at_2.23.14_AM.png]]

When you delete a deployment 

```bash
kubectl delete deployment <name>
```

all the associated objects will be deleted too

Updating deployments

Method #1, its not used very often

because we are specifing an explicit version in the config file

```bash
apiVersion: apps/v1
kind: Deployment
metadata:
	name: posts-depl
spec:
	replicas: 1
	selectors:
		matchLabels:
			app: posts
	templates:
		metadata:
			labels:
				app: posts
		spec:
			containers:
				- name: posts
					image: aligmohammad/posts:0.0.2
```

![[Screenshot_2023-04-13_at_2.26.22_AM.png]]

![[Screenshot_2023-04-13_at_2.29.46_AM.png]]

Method #2: Preferred way to do deployments

![[Screenshot_2023-04-13_at_2.35.15_AM.png]]

change the config to use the latest for the config

```bash
apiVersion: apps/v1
kind: Deployment
metadata: 
	name: posts-depl
spec:
	replicas: 1
	selector:
		matchLabels:
			app: posts
	templates
		metadata:
			labels:
				app: posts
		spec:
			containers:
				- name: posts
					image: aligmohammad/posts
```

to push the image

```bash
docker push aligmohammad/posts
```

![[Screenshot_2023-04-13_at_2.40.54_AM.png]]




Kubernetes Services

We will create them to setup a communication between the pods and from the outside

This service is a cluster IP

![[Screenshot_2023-04-13_at_2.49.44_AM.png]]

This service is a Load balancer or a Node Port

![[Screenshot_2023-04-13_at_2.49.52_AM.png]]

Services Types

![[Screenshot_2023-04-13_at_2.50.20_AM.png]]

1. **ClusterIP**: This is the default service type in Kubernetes. It creates a virtual IP address inside the cluster to which external clients can connect. Requests are load balanced across the pods that match the service's selector. ClusterIP services are only accessible from within the cluster and not from outside the cluster.
![[Screenshot_2023-04-13_at_3.03.15_AM.png]]
2. **NodePort**: This service type exposes the service on a static port on each node in the cluster. The service is still assigned a ClusterIP, but the NodePort makes the service accessible from outside the cluster by forwarding traffic from a specified port on each node to the service. This service type is commonly used for development and testing.
![[Screenshot_2023-04-13_at_3.04.00_AM.png]]
3. **LoadBalancer**: This service type automatically creates an external load balancer in cloud environments that support external load balancers (such as AWS, GCP, or Azure) to distribute traffic across the pods that match the service's selector. The external load balancer can then route traffic to the service from outside the cluster. LoadBalancer services are useful when deploying an application in a cloud environment and want to expose it to the public internet.
![[Screenshot_2023-04-13_at_3.03.25_AM.png]]
4. **ExternalName**: This service type is used to create an alias for an external service name. It maps the service name to an external DNS name, and provides a CNAME record that maps the service name to the external DNS name. This allows services within the cluster to access external services by name instead of IP address.

To create a Node Port service:

![[Screenshot_2023-04-13_at_3.09.57_AM.png]]

```bash
apiVersion: v1
kind: Service
metadata:
	name: posts-srv
spec:
	type: NodePort
	selector:
		app: posts
	ports:
		- name: posts
			protocol: TCP
			port: 4000
			targetPort: 4000
```

- `**apiVersion**`: This specifies the Kubernetes API version being used by the service.
- `**kind**`: This specifies the type of Kubernetes resource, which in this case is a service.
- `**metadata**`: This section provides metadata about the service, such as its name.
- `**spec**`: This section specifies the desired state of the service, including the type, selector, and ports.
- `**type**`: This specifies the type of service. In this case, it's set to `**NodePort**`, which means the service will be exposed on a static port on each node in the cluster.
- `**selector**`: This specifies the labels used to select the pods that the service is managing. In this case, the service selects the pods that have the label `**app: posts**`.
- `**ports**`: This specifies the ports that the service will listen on and forward traffic to the pods.
- `**name**`: This specifies the name of the port. In this case, it's set to `**posts**`.
- `**protocol**`: This specifies the protocol of the port. In this case, it's set to `**TCP**`.
- `**port**`: This specifies the port number of the service. In this case, it's set to `**4000**`.
- `**targetPort**`: This specifies the port number that the pods are listening on. In this case, it's set to `**4000**`.

To apply it to the cluster

```bash
kubectl apply -f posts-srv.yaml
```

![[Screenshot_2023-04-13_at_3.16.51_AM.png]]

The randomly assigned port ( 31406 ) is the port that we are going to actually access the service

![[Screenshot_2023-04-13_at_3.19.00_AM.png]]

![[Screenshot_2023-04-13_at_3.20.09_AM.png]]

to see the services

```bash
kubectl get services
```

to see the details of the service

```bash
kubectl describe service posts-srv
```

![[Screenshot_2023-04-13_at_3.18.35_AM.png]]


To create a ClusterIP:
![[Screenshot_2023-04-13_at_3.48.22_AM.png]]
![[Screenshot_2023-04-13_at_3.45.41_AM.png]]
    Where the post pod will request to the event-bus-srv and the vise versa
	1. Build the docker image
![[Screenshot_2023-04-13_at_3.53.34_AM.png]]
	2. Push the docker image
![[Screenshot_2023-04-13_at_3.54.04_AM.png]]
	3. Create the Deployment configuration for the event-bus

```bash
apiVersion: apps/v1
kind: Deployment
metadata:
	name: event-bus-depl
spec:
	replicas: 1
	selector:
		matchLabels:
			app: event-bus
	template:
		metadata:
			labels:
				app: event-bus
		spec:
			containers:
				- name: event-bus
					image: aligmohammad/event-bus
```
	4. Apply the deployment configuration to the cluster
![[Screenshot_2023-04-13_at_3.56.34_AM.png]]
	5. Create the ClusterIP service for the event bus and posts colocated in each deployment file
event-bus-dpl.yml
```bash
apiVersion: apps/v1
kind: Deployment
metadata:
  name: event-bus-depl
spec:
  replicas: 1
  selector:
    matchLabels:
      app: event-bus
  template:
    metadata:
      labels:
        app: event-bus
    spec:
      containers:
        - name: event-bus
          image: aligmohammad/event-bus
---
apiVersion: v1
kind: Service
metadata:
	name: event-bus-srv
spec:
	type: ClusterIP # This is the default
	selector:
		app: event-bus
	ports:
		- name: event-bus
			protocol: TCP
			port: 4005
			targetProtocol: 4005
```
        Go ahead and apply it

![[Screenshot_2023-04-13_at_4.04.06_AM.png]]

        posts-dpl.yaml
```bash
apiVersion: apps/v1
kind: Deployment
metadata:
  name: posts-depl
spec:
  replicas: 1
  selector:
    matchLabels:
      app: posts
  template:
    metadata:
      labels:
        app: posts
    spec:
      containers:
        - name: posts
          image: aligmohammad/posts
---
apiVersion: v1
kind: Service
metadata:
	name: posts-clusterip-srv
spec:
	type: ClusterIP
	selector:
		app: posts
	ports:
		- name: posts
			protocol: TCP
			port: 4000
			targetPort: 4000
```
        Go ahead and apply it
![[Screenshot_2023-04-13_at_4.09.59_AM.png]]
        Get the running services to see them in action 😎
![[Screenshot_2023-04-13_at_4.10.22_AM.png]]
	6. Wire them up (Connecting them)
We need to change the code for the project for the correct url (the name of the cluster ip service) 
posts/index.js
![[Screenshot_2023-04-13_at_4.20.19_AM.png]]
        event-bus/index.js
![[Screenshot_2023-04-13_at_4.21.34_AM.png]]
        Update the images
```bash
cd posts
docker build -t aligmohammad/posts .
# -------
cd event-bus
docker build -t aligmohammad/event-bus .
```
        Push the images to docker hub
```bash
cd posts
docker push aligmohammad/posts
# -------
cd event-bus
docker push aligmohammad/event-bus
```
        rerun the rollout command
```bash
# Get the deployment names
kubectl get deployments

# Restart them
kubectl rollout restart deployment posts-depl
kubectl rollout restart deployment event-bus-dpl
```
![[Screenshot_2023-04-13_at_4.29.11_AM.png]]
	7. Verify them
Get the nodeport port
```bash
kubectl get services
```
![[Screenshot_2023-04-13_at_4.31.44_AM.png]]
        Try now to reach it on 31406 on postman!
![[Screenshot_2023-04-13_at_4.32.29_AM.png]]
        See the logs for the pods
```bash
# Get the pod names
kubectl get pods

# Get the logs
kubectl logs event-bus-depl-848d9bd744-ccvpt
kubectl logs posts-depl-9b9559c5c-tfg6f
```
![[Screenshot_2023-04-13_at_4.33.52_AM.png]]
![[Screenshot_2023-04-13_at_4.34.21_AM.png]]

        To apply all config files
```bash
kubeclt apply -f .
```

        Wiring up the React to our microservices!

        To clarify what is happening, what our react pod is actually doing is serving HTML,CSS, JS to the browser; then the browser is sending the actual requests to the other pods.
![[Screenshot_2023-04-16_at_3.20.57_AM.png]]

![[Screenshot_2023-04-16_at_3.21.09_AM.png]]

        So how will it make the requests ?
		- NodePort (Not Good), because we are openning a random port that can be randomly change overtime and because we are exposing the services to the outside world.
![[Screenshot_2023-04-16_at_3.22.39_AM.png]]
		- LoadBalancer (Good): One single point of entry to our cluster.
![[Screenshot_2023-04-16_at_3.23.48_AM.png]]

        So what is a LoadBalancer Service ?
![[Screenshot_2023-04-16_at_3.29.32_AM.png]]
        A **load balancer** is a service that distributes incoming network traffic across a group of backend servers in order to improve the availability and scalability of applications. In a Kubernetes cluster, a LoadBalancer service type automatically creates an external load balancer in cloud environments that support external load balancers (such as AWS, GCP, or Azure) to distribute traffic across the pods that match the service's selector. The external load balancer can then route traffic to the service from outside the cluster. LoadBalancer services are useful when deploying an application in a cloud environment and want to expose it to the public internet.
![[Screenshot_2023-04-16_at_3.33.34_AM.png]]

        **Ingress**: Ingress is a Kubernetes API object that manages external access to services in a cluster, usually through HTTP or HTTPS. It provides routing rules to direct external traffic to the appropriate backend services based on factors like the request's URL path or domain. Ingress allows you to consolidate routing rules into a single resource, enabling better organization and simplified management of external access to your applications. Ingress can also handle load balancing, SSL termination, and name-based virtual hosting

        **Ingress Controller**: The Ingress Controller is a component responsible for implementing and managing the rules defined in the Ingress resources. It watches for changes in Ingress configurations and updates the underlying infrastructure to route traffic accordingly. There are different Ingress Controllers available, such as NGINX, HAProxy, and Traefik, each providing specific features and capabilities. You need to deploy an Ingress Controller in your Kubernetes cluster for the Ingress resources to have any effect.
![[Screenshot_2023-04-16_at_3.35.46_AM.png]]

        NGNIX Ingress Controller 
        Install Krew, a plugin manager for kubectl
[https://krew.sigs.k8s.io/docs/user-guide/setup/install/](https://krew.sigs.k8s.io/docs/user-guide/setup/install/)
        Then install NGNIX Ingress Controller
![[Screenshot_2023-04-16_at_3.44.12_AM.png]]
[https://kubernetes.github.io/ingress-nginx/](https://kubernetes.github.io/ingress-nginx/)
        The goal of this **Ingress controller** is the assembly of a configuration file (nginx.conf). The main implication of this requirement is the need to reload NGINX after any change in the configuration file.

        Let’s create a config file for ingress-srv.yaml
```bash
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: ingress-srv
  annotations:
    kubernetes.io/ingress.class: nginx
spec:
  rules:
    - host: posts.com
      http:
        paths:
          - path: /posts
            pathType: Prefix
            backend:
              service:
                name: posts-clusterip-srv
                port:
                  number: 4000
```

        Now to test it in our local enviroment under posts.com/posts
        first, check if you have anything running on port 80
```bash
sudo lsof -i tcp:80
```
![[Screenshot_2023-04-19_at_3.40.44_AM.png]]
        We can host many different apps and many different domains in one single kubernetes cluster!
        then let’s tweak the host to trick our computer to think that [posts.com](http://posts.com/) is actually the [localhost](http://localhost/) rather than the real posts.com! 
![[Screenshot_2023-04-19_at_3.42.50_AM.png]]

```bash
##
# Host Database
#
# localhost is used to configure the loopback interface
# when the system is booting.  Do not change this entry.
##
127.0.0.1	localhost
255.255.255.255	broadcasthost
::1             localhost
# Added by Docker Desktop
# To allow the same kube context to work on the host and the container:
127.0.0.1 kubernetes.docker.internal
# End of section

127.0.0.1 posts.com
```
        Now when we type [posts.com](http://posts.com/) our computer will connect to 127.0.0.1
        So if we hit [posts.com](http://posts.com/) in postman now we will go to 127.0.0.1 and our ingress will think that we are trying to connect to posts.com and apply our routing rules
![[Screenshot_2023-04-19_at_3.46.41_AM.png]]

        To make create-react-app run inside docker
```bash
FROM node:alpine
 
# Add the following lines
ENV CI=true
ENV WDS_SOCKET_PORT=0
 
WORKDIR /app
COPY package.json ./
RUN npm install
COPY ./ ./
 
CMD ["npm", "start"]
```

        Update the axios calls to posts.com
        Then let’s build an image for the react app
```bash
FROM node:alpine

# ENV
ENV CI=true
ENV WDS_SOCKET_PROT=0

WORKDIR /app
COPY package.json ./
RUN npm install
COPY . .

CMD ["npm", "start"]
```
        then
```bash
docker build -t aligmohammad/client .
docker push aligmohammad/client
```

        Then let’s write another config file for the deployment of the react app
        client-depl.yaml
```bash
apiVersion: apps/v1
kind: Deployment
metadata:
  name: client-depl
spec:
  replicas: 1
  selector:
    matchLabels:
      app: client
  template:
    metadata:
      labels:
        app: client
    spec:
      containers:
        - name: client
          image: aligmohammad/client
---
apiVersion: v1
kind: Service
metadata:
  name: client-clusterip-srv
spec:
  type: ClusterIP
  selector:
    app: client
  ports:
    - name: client
      protocol: TCP
      port: 3000
      targetPort: 3000
```
        then apply it to the cluster
```bash
kubectl apply -f client-depl.yaml
```

        Now let’s start writing the routing rules for our other microservices
        The ingress controller cannot differentiate between the request methods (GET, POST, PUT…etc)
![[Screenshot_2023-04-19_at_5.19.05_PM.png]]

        First let’s make the change to the front end part with the new routes
        Then build the docker image for the client and push it
```bash
docker build -t aligmohammad/client .
```
        Then make the change to the posts microservice and build it and push it
Then restart the deployment for the client and posts
```bash
kubectl rollout restart deployment client-depl
```
        Then let’s write the config for the rest of the routes in the ingress config
        Just a note, our cluster doesn’t know about the params (:id) so we have to use a regex.
```bash
nginx.ingress.kubernetes.io/use-regex: "true"
```
        then 
```bash
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: ingress-srv
  annotations:
    kubernetes.io/ingress.class: nginx
    nginx.ingress.kubernetes.io/use-regex: "true"
spec:
  rules:
    - host: posts.com
      http:
        paths:
          - path: /posts/create
            pathType: Prefix
            backend:
              service:
                name: posts-clusterip-srv
                port:
                  number: 4000
          - path: /posts
            pathType: Prefix
            backend:
              service:
                name: query-srv
                port:
                  number: 4002
          - path: /posts/?(.*)/comments
            pathType: Prefix
            backend:
              service:
                name: comments-srv
                port:
                  number: 4001
          - path: /?(.*)
            pathType: Prefix
            backend:
              service:
                name: client-clusterip-srv
                port:
                  number: 3000
```
        Then apply it to our cluster
```bash
kubectl apply -f ingress-srv.yaml
```
![[Screenshot_2023-04-20_at_10.06.43_PM.png]]
        Then lets test it out..
        if you got 503 error, check your service name
```bash
kubectl get services
```
        and update it in the config, then re-apply
        If you got 502 error, check the logs for the service
```bash
kubectl logs query-depl-65db9cf969-2t96j
```
        It was an issue with cors, i solved it by adding this in the query microservice index file
```bash
app.use(cors({
    origin: [
        'http://client-clusterip-srv:3000',
        'http://event-bus-srv:4005',
    ]
}));
```

        So how we can automate the building, pushing and restarting the deployment and image ?
        We are going to use a tool called skaffold!
        It runs outside of our cluster
[https://skaffold.dev/](https://skaffold.dev/)
![[Screenshot_2023-04-20_at_10.29.08_PM.png]]

        Let’s configure it so it knows how to manage our micro-services
        let’s create at root level skaffold.yaml file
```bash
apiVersion: skaffold/v4beta4
kind: Config
manifests:
  rawYaml:
    - ./infra/k8s/*.yaml
build:
  local:
    push: false
  artifacts:
    - image: aligmohammad/client
      context: client
      docker:
        dockerfile: Dockerfile
      sync:
        manual:
          - dest: "."
            src: "src/**/*.jsx"
    - image: aligmohammad/comments
      context: comments
      docker:
        dockerfile: Dockerfile
      sync:
        manual:
          - dest: "."
            src: "*.js"
    - image: aligmohammad/event-bus
      context: event-bus
      docker:
        dockerfile: Dockerfile
      sync:
        manual:
          - dest: "."
            src: "*.js"
    - image: aligmohammad/moderation
      context: moderation
      docker:
        dockerfile: Dockerfile
      sync:
        manual:
          - dest: "."
            src: "*.js"
    - image: aligmohammad/posts
      context: posts
      docker:
        dockerfile: Dockerfile
      sync:
        manual:
          - dest: "."
            src: "*.js"
    - image: aligmohammad/query
      context: query
      docker:
        dockerfile: Dockerfile
      sync:
        manual:
          - dest: "."
            src: "*.js"
```
        What this does is
		1. When we start skaffold it runs all the config files
		2. When we stop skaffold it deletes the objects associated with it config files
		3. When we change the code it applies the config automatically
		4. For the build.. 
			1. It will automatically take any change from our jsx file and throw it in the pod
			2. If some other file was changes it will rebuild the whole image 
			3. and for the push: false, it is not required to push our image to docker hub locally.

        to get the API versions supported by skaffold
```bash
skaffold schema list
```
        then to fix your code
```bash
skaffold fix
```
        To start skaffold
```bash
skaffold dev
```
        There’s two levels of restarting here..
		5. Skaffold when he sees a change he will come and push the change to the pod
		6. Our create-react-app or nodemon for the services will detect the change and re run the primary process once again in the container
        
to stop skaffold 
```bash
Just hit ctrl+c
```
![[Screenshot_2023-04-20_at_11.06.39_PM.png]]
