---
notion-id: 213d91f9-7a99-8009-b4e6-de99b7607654
---
- Observer API
- Intersection Observer
- Mutation Observer
- Resize Observer