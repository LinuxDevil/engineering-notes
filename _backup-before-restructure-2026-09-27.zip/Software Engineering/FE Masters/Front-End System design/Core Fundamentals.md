---
notion-id: 213d91f9-7a99-801a-b616-dba492fb4c95
---
- Box Model
- Positioning System
- Formatting Context
- Stacking Context
- Browser Rendering Cycle and reflow
- Composition Layers
- GPU Acceleration


