---
notion-id: 213d91f9-7a99-8097-9494-c64224c762c4
---
- Pattern overview