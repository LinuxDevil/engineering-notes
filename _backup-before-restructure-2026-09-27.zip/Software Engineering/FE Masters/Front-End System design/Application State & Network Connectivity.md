---
notion-id: 213d91f9-7a99-80d2-a4ea-f54b10f6699a
---
Application State

- Search / Access optimization
- Browser storage
- Memory offloading

Network

- Introduction to browser networking
- Protocols
- Talking to server
	- Long-polling
	- Web-sockets
	- SSE
- Rest / GraphQL
