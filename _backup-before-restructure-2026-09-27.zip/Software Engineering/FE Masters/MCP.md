---
notion-id: 233d91f9-7a99-8028-b938-fc4c2cf7d9dd
---
Docs: [Inspector - Model Context Protocol](https://modelcontextprotocol.io/docs/tools/inspector)

SDK:  https://github.com/modelcontextprotocol/typescript-sdk 

Model Context Protocol (MCP): Is a protocol to provide context for LLMs (Large Language Models).

MCP helps you build agents and complex workflows on top of LLMs 

```bash

MCP Client   --> MCP Server 
           | 
	         | --> MCP Server

```

Architecture

![[image 14.png]]

- MCP Host: Program like Claude or Cursor that want to access your data.
- MCP Client: Protocol clients that maintain a 1:1 connection with the server.
- MCP Servers: Lightweight programs that each expose specific capabilities through the standardized model context protocol
- Local data sources: Your computer files, databases, services that MCP server can securely access
- Remote Services: External systems available over the internet 

MCP have 4 pillars:
	- Tools: A way for the client to call code on the server, a way to interact with programs and interfaces.
	- Resources: Set of data like database, files ...etc
	- Prompts: A pre-created prompt that you can ask the MCP for to do a specific task
	- Samplings: (When the server wants information from the AI) we will send a prompt from the server to the AI to get the data needed in the server.

There’s 2 protocols to run the MCP on, 

- Standard IO (Locally)
- HTTP Streaming (Remote)
- Server Sent Events <u>***(Deprecated)***</u>

To create a MCP server with a tool

1. Import the MCPServer
```typescript
import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
```
2. Create a server
```typescript
const server = new McpServer({
	name: 'Server name',
	version: '1.0.0',
	capabilities: {
		// What your server is capable of
		resources: {},
		tools: {},
		prompts: {}
	}
});
```
3. Create a tool
```typescript
server.tool('create-user', 'Create a new user in the database', {
	// What parameters do you need
	// z is from zod library for validation
	name: z.string(),
	email: z.string(),
	address: z.string(),
	phone: z.string(),
}, {
	// Options and meta data for the AI
	title: 'Create User',
	readOnlyHint: false, // Does your tool only read data
	destructuiveHint: false, // Does your tool delete data
	idempotentHint: false, // Does your tool have different outputs depending on the run
	openWorldHint: true, // Should the tool access different service than your app
}, async (params) => {
	// Here you will call your function to create user
	try {
		const id = await createUser(params);
		return {
			content: [
				{ type: 'text', text: 'User ${id} created successfully' }
			]
		}
	} catch (error) {
		return {
			content: [
				{ type: 'text', text: 'Faild to save user: ${error.message}' }
			]
		}
	}
});
```
4. Create a transport layer
```typescript
async function main() {
	const transport = new StdioServerTransport();
	await server.connect(transport);
}
```
5. Connect it and start it with the inspection
```bash
# DANGEROUSLY_OMIT_AUTH=true to omit the authentication everytime you run the server
npm run set DANGEROUSLY_OMIT_AUTH=true &&
 npx @modelcontextprotocol/inspector npm run server:dev
```
![[image 15.png]]

Now to create a resource

Create a resource
```bash
server.resource('all-users', 'users://all', {
	description: 'Get all users from the database',
	title: 'All Users',
	mimeType: 'application/json'
}, async uri => {
	const users = JSON.parse(
	return {
		contents: [
			{ uri: uri.href, text: JSON.strigify(users), mimeType: 'application/json' }
		]
	};
});
```
![[image 16.png]]


To create a resource template

```bash
server.resource('user-details', new ResourceTemplate('user://{userId}/profile', {
	list: undefined
}
```

To create prompts 

```bash

```