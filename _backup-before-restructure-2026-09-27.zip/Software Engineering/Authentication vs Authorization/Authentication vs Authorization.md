---
notion-id: a772c17e-4b4b-4a8f-8bdc-657fc95c700f
cover: "[[Authentication vs Authorization.jpeg]]"
---

**Authentication** is the process of verifying who someone is.

**Authorization** is the process of verifying what specific applications, files, and data a user has access to.

![[Authentication Vs Authorization.base]]

**Authorization** **Methods**:
    [*Role-based access controls (RBAC)*](https://www.sailpoint.com/identity-library/what-is-role-based-access-control/)*: *This authorization method gives users access to information based on their role within the organization.
    [*Attribute-based access control (ABAC)*](https://www.sailpoint.com/identity-library/what-is-attribute-based-access-control/)*: *ABAC grants users permissions on a more granular level than RBAC using a series of specific attributes.
