---
notion-id: 08d6bcd3-bf03-497e-8003-9926fe7aeb7a
base: "[[Authentication Vs Authorization.base]]"
Authorization: "Example: Once their level of access is authorized, employees and HR managers can access different levels of data based on the permissions set by the organization."
---
