---
notion-id: 606ce903-87df-4d66-9485-73b058b51e48
base: "[[Authentication Vs Authorization.base]]"
Authorization: Authorization always takes place after authentication.
---
