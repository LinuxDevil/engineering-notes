---
notion-id: 4a97456c-f459-41ed-8c5f-3f7027b0472a
base: "[[Authentication Vs Authorization.base]]"
Authorization: Authorization isn’t visible to or changeable by the user.
---
