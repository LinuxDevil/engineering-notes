---
notion-id: 4c37250c-09f0-44e5-ae9a-f62f2890f4ee
base: "[[Authentication Vs Authorization.base]]"
Authorization: Authorization works through settings that are implemented and maintained by the organization.
---
