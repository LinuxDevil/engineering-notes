---
notion-id: 9a66d50e-c5a3-46ca-abe2-09905b1322ad
base: "[[Authentication Vs Authorization.base]]"
Authorization: Authorization determines what resources a user can access.
---
