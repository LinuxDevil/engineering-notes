---
notion-id: 192d91f9-7a99-807c-804d-fdf018f36988
cover: "[[Grokking Algorithms.jpeg]]"
---
An algorithm is a set of instructions of solving a task

## Chapter 1

### Binary search

It’s input is a sorted list, it searches for the position of the element and return it, if not found it returns null.

It works by halving the search area into 2, [0,1,2,3,4,5,6,7,8,9], the search could start at the left or right array and check if the input search is bigger or lower from the list index 0.

So you will keep halving the search area until you find your solution

Logarithms and Exponentials

Exponentials

How many 10s do we multiply together to get 100?

```javascript
The answer is 2: 10 × 10. So log10 100 = 2. 
```

Logarithms

Logs are the flip of exponentials

![[Screenshot_2025-02-06_at_2.58.15_PM.png]]

Code

```javascript
function binary(list, n) {
  let low = 0;
  let high = list.length - 1;


  while (low <= high) {
    const mid = low + high;
    const guess = list[mid];

    if (guess == n) {
        return mid;
    }
      
    if (guess > n) {
        high = mid - 1;
    } else {
        low = mid + 1;
    }
  }

  return null;
}


console.log(binary([0,1,2,3,4,5,6,7,8,9,10], 5)) // 5
```




## Chapter 2

Arrays take a fixed contiguous spot in memory, if you want to expand it, you’ll have to move it to another address where the full length of the array is available to store.

In Linked List, your items can be anywhere in the memory.

> Linked lists are great if you’re going to read all the items one at a time: you can read one item, follow the address to the next item, and so on. But if you’re going to keep jumping around, linked lists are terrible

There are two different types of access: random access and sequential access.

- Sequential access means reading the elements one by one, starting
at the first element.
	- Linked lists can only do sequential access
- Random access means you can jump directly to the 10th element
	- Arrays are the champion here

### Selection Sort

Selection sort is a neat algorithm, but it’s not very fast. Quicksort is a faster sorting algorithm that only takes O(n log n) time. It’s coming up in the next chapter!

You’ll have to go through every item in the list to check. for example in the music player, imagine you have a list of songs and the times they were played in 

![[Screenshot_2025-02-16_at_9.03.55_AM.png]]

so, you’ll have to define a function

```javascript
function findSmallest(list) {
	let smallest = list[0];
	let smallestIndex = 0;
	for (let i = 0; i < list.length; i++) {
		if (list[i] < smallest) {
			smallest = list[i];
			smallestIndex = i;
		}
	}
	
	return smallestIndex;
}
```

Then, you’ll have to write the selection sort functionality

```javascript
function selectionSort(list) {
	let newArray = [];
	for (let i = 0; i < list.length; i++) {
		const smallest = findSmallest(list);
		newArray.push(smallest);
	}
	
	return newArray;
}

console.log(selectionSort([5, 3, 6, 2, 10]));
```

or you can do it like this

```javascript
function selectionSort(list) {
    for (let i = 0; i < list.length; i++) {
        let smallestItem = list[i];
        let smallestIndex = i;

        for (let j = i; j < list.length; j++) {
            if (list[j] < smallestItem) {
                smallestItem = list[j];
                smallestIndex = j;
            }
        }
        
        // in-place swapping
        const temp = list[i];
        list[i] = list[smallestIndex];
        list[smallestIndex] = temp;
    }


    return list;
}
```


## Chapter 3

### Recursion

Functions calling itself until the base-case is achieved

> Loops may achieve a performance gain for your program. Recursion may achieve a performance gain for your programmer. Choose which is more important in your situation!

Eery recursive function has two parts: the base case, and the recursive case

- Recursive case is when the function calls itself.
- Base case is when the function doesn’t call itself, it stops.
![[Screenshot_2025-02-16_at_9.40.35_AM.png]]


### The stack

The stack is like the sticky notes, when you insert an item it goes to the top of the list, when you read an item, you only read the topmost of the list; and it’s taken off the list.

![[Screenshot_2025-02-16_at_9.44.48_AM.png]]

### The call stack

> The computer internally uses a stack that is called the “call stack” to keep track of the functions run and their allocated memory address to them.

```javascript
def greet(name):
 print “hello, “ + name + “!”
 greet2(name)
 print “getting ready to say bye...”
 bye()
 
def greet2(name):
 print “how are you, “ + name + “?”

def bye():
 print “ok bye!”
```

Whenever you call a function in the computer, it allocate a memory address for it saving the arguments that it needs with the values inside 

![[Screenshot_2025-02-16_at_9.47.35_AM.png]]

Every time you call a function, it get added to the stack of functions 

![[Screenshot_2025-02-16_at_9.48.03_AM.png]]

Now, why did the greet 2 come before greet, it called it internally, so

> When you called the greet2 function, the greet function was partially completed. This is the big idea behind this section: when you call a function from another function, the calling function is paused in a partially completed state.

![[Screenshot_2025-02-16_at_9.49.49_AM.png]]

Recursion uses call stacks, for example the factorial function

```javascript
function factorial(number) {
	if (number === 1) return 1;
	return number * factorial(--number);
}
```

![[Screenshot_2025-02-16_at_9.51.46_AM.png]]

> [!tip] 💡
> Using the stack is convenient, but there’s a cost: saving all that info can take up a lot of memory.

### Tail recursion

> [!tip] 💡
> ***Tail recursion**** is defined as a recursive function in which the recursive call is the last statement that is executed by the function. So basically nothing is left to execute after the recursion call.*

The tail recursive functions are considered better than non-tail recursive functions as tail-recursion can be optimized by the compiler.

> [!tip] 💡
> Compilers usually execute recursive procedures by using a **stack**. This stack consists of all the pertinent information, including the parameter values, for each recursive call. When a procedure is called, its information is **pushed **onto a stack, and when the function terminates the information is **popped **out of the stack. Thus for the non-tail-recursive functions, the **stack depth** (maximum amount of stack space used at any time during compilation) is more.

> The idea used by compilers to optimize tail-recursive functions is simple, since the recursive call is the last statement, there is nothing left to do in the current function, so saving the current function’s stack frame is of no use ([See this for more details](https://www.geeksforgeeks.org/tail-call-elimination/)).

So a non-tail recursion factorial is

```javascript
function factorial(number) {
	if (number == 1) return 1;
	return number * factorial(--number);
}
```

> [!tip] 💡
> Although it looks like a tail recursive at first look. If we take a closer look, we can see that the value returned by fact(n-1) is used in **fact(n)**. So the call to **fact(n-1)** is not the last thing done by **fact(n)**.

To write it as a tail-recursion

```javascript
function factTailRec(number, baseCase) {
	if (number <= 0) return a;
	return factTailRec(number -1, number * baseCase); 
}

// then we make a wrapper on top of it
function fact(number) {
	return factTailRec(5, 1);
}

console.log(fact(5);
```

> [!tip] 💡
> The idea is to use one more argument and accumulate the factorial value in the second argument. When n reaches 0, return the accumulated value.


## Chapter 4

Quick sort & Divide and conquer (Divide and conquer algorithms are recursive functions)

Two steps for D&C

- Figure out the base case for it
- Then divide your problem until it becomes the base case

> With every recursive call, you have to reduce your problem

Quick sort is a sorting algorithm that uses D&C, in this algorithm we split the problem into partitions using a pivot.

In it, we have a base case of  having either an empty array or an array with only one item, which doesn’t need any sorting.

We take the pivot and find elements that is smaller than the pivot and the elements larger  than the pivot 

![[Screenshot_2025-02-16_at_1.53.21_PM.png]]

- A sub-array of all the numbers less than the pivot
• The pivot
• A sub-array of all the numbers greater than the pivot

After taking the two arrays, you can sort each one then combine them to get the fully sorted array. (smallerArray + pivot + biggerArray)

So the steps become: 

1. Pick a pivot
2. Partition the array into two sub-arrays
3. Call quick sort recursively on the two sub-arrays

```javascript
function quickSort(array) {
    if (array.length < 2) {
        return array;
    }
    const pivot = array[0];
    const less = [];
    const greater = [];

    for (let i = 1; i < array.length; i++) {
        if (array[i] >= pivot) {
            greater.push(array[i]);
        } else {
            less.push(array[i]);
        }
    }

    return [...quickSort(less), pivot, ...quickSort(greater)];
}

console.log(quickSort([10, 5, 2, 3]));
```

### I<u>**nductive proofs**</u>

We have something called I<u>**nductive proofs**</u>, this is a way to prove your algorithm works

It has two steps: the base case and the inductive case, the inductive case is when you can recursive back, (For example if you are climbing a ladder, “if your legs in the rung 1” you can go to the rung 2 …etc) and the base case says if my legs are on the rung i can climb the entire ladder one rung at a time.

> [!tip] 💡
> Quicksort versus merge sort is one example. Quicksort has a smaller constant than
merge sort. So if they’re both O(n log n) time, quicksort is faster. And quicksort is faster in practice because it hits the average case way more often than the worst case.


## Chapter 5

Hash tables is just an array list with a hash function to it a “Map”

Hash functions is just a function that maps string to numbers.

A hash function should be consistent, for example for the same input we must always yield the same output.

It should map different words to different numbers

![[Screenshot_2025-02-19_at_10.52.54_AM.png]]

