---
notion-id: 4e27e411-945e-4c68-b451-6f6e065733e5
---
Data comes from the network as a chunks of buffers

The default size for a patch(chunk) is 64KB They call it the high water mark and we can change that configuration.

A stream is chunks of data (like buckets of water each is 64KB), each time a chunk is arrived node will fire (broadcast) an event called data and we will have a function that auto runs when that data is arrived.

![[Screenshot_2023-05-05_at_5.44.26_PM.png]]

When the end of file and all the data is already has been read, node will flash out a “close” event.

![[Screenshot_2023-05-05_at_6.06.13_PM.png]]

When it starts the file stream opening a new event will be broadcasted and it’s called “open”.

![[Screenshot_2023-05-05_at_6.07.46_PM.png]]

When we ran the doOnNewBatch function, inside it when it still didn’t finish a new patch arrived.. so what should we do now ?

First, let’s clear somethings:

The Call <u>stack</u>:
<u>*JavaScript keeps track of what function is being run and where it was run from. Whenever a function is to be run, it’s added to the call stack.*</u>
A queue to keep track of what function is being run.

**Event **<u>**Loop**</u>** (”Its just a while loop that checks the queues, while theres stuff to run go check these queues (As the rules below)”)**
<u>*Determines what function/code to run next from the queue(s).*</u><u>
</u>When all global code get finished and popped from the call stack, and we are back to the global function only in the call stack, the libuv and node will check if there’s anything left, if not it will check the queues (totally 6 queues) and the callback queue it’s called the event loop and then it grabs from one of those queues and add it to the call stack queue and creates a brand new execution context that is created by node.
![[Screenshot_2023-05-05_at_9.09.37_PM.png]]

<u>**Turns out with the help of node and C++ libUV that they setup queues for us that is called:**</u> 
	1. **Callback queue**
<u>*any functions delayed from running (and run automatically by Node) are
added to the callback queue when the background Node task has completed (or there’s been some activity like a request).*</u>
So when the new patch arrives and node broadcast the data event for us and run the doOnNewBatch, it goes in the callback queue and it has to wait there.
	2. **Timer Queue (Min Heap)
**When a function we set to auto run by nodeJS when we use the timer feature of the Node C++ and when the status of it sets to be okay, it goes here in the timer queue.
	3. **IO Callback Queue
**When a function we set to auto run by NodeJS gets triggered by using NodeJS C++ file system/network socket ..etc  and when it’s status is okay, it goes here in the IO Callback queue.
	4. **Check Queue
**We get a function into a check queue by using the *setImmediate*
<u>It is the last queue to be checked.
</u>We can add a function that indicates that all I/O functions ran with a node feature called *setImmediate*.
	5. **Microtask Queue
**It has the highest priority and it is used with promises and it has 2 queues
1. the first one is when we run a function that we are not going to use anymore like process.nextTick()
2. any functions that gets delayed by promises it gets into the second queue.
	6. **Close queue
**It gets the function that set to auto run when we close event comes.


<u>**Rules**</u><u> for the automatic execution of the JS code by Node:</u>
![[Screenshot_2023-05-05_at_6.55.37_PM.png]]
	1. Hold each “deferred” (Auto run) function in one of the
task queues when the Node background API
‘completes’
	2. Add the function to the Call stack (i.e.
execute the function) ONLY when the call
stack is totally empty (Have the Event Loop
check this condition)
	3. Prioritize functions in Timer ‘queue’ over I/
O queue, over setImmediate (‘check’) queue

A note, not all auto run functions share the same queue, any one involves IO they share the same queue.

Promises here is alternitive way of setting up that auto run functions by node, so instead of making node runs an auto run function, it automatically updates data in that function and that triggers an auto run function inside JS and it’s added to the Microtask queue.