---
notion-id: 58678638-0770-402e-9942-911de78c6f97
---

**- "node.js is single thread or multi thread application ?" (topics: EventLoop)**

A: Yes, JS and Node is a single threaded application butttt nodejs and C++ enables concurrent work with the event loop.

**-What is the difference between multithreading and asynchrony?**

- **Multithreading**: A single CPU core can handle multiple threads of execution concurrently.
- **Asynchrony**: Make events run separately from the application’s primary thread and notify it via signals when an event is completed or failed.

**- "how can we make node.js simulate muti-threading?"**

**worker-threads module, which allows you to create threads and execute multiple JavaScript tasks in parallel.**

NodeJS comes with 2 forks, a general fork i used to spawn shard processes in Nodejs which is used to create a new instance of the v8 engine to run multiple workers to execute code which can run code in multiple cores of the matching host of the machine

**-What threads NodeJS is using behind the scene ?**

Node.js has two types of threads:

- The one **Event Loop** thread (aka the main thread).
- The **Worker Pool** (aka threadpool) threads.

**- "have you ever heard about V8 Engine?"**

Yes the JS engine that is provided by google.

**- "why nodeJS use V8?"**

It is optimize the compile and instead of employing an interpeter it converts js code into effiecent machine code to increase performance by using JIT and ignition

**- "what is the event loop?"**

The event loop is what allows JS to make concurrent work. It is just a mechanism (A while loop) that goes through a set of rules that checks the 6 queues and add the appropriate function to run at that time. also it goes into multiple phases like the timer, pending callbacks, idle prepare, poll, check and close callbacks.

**- "what do you understand about callbacks?"**

A function that is auto-run when a asynchronous operation finish or an event is broadcast.

 

**- "have you ever heard about callback hell?"**

Yeah its a problem that arises when developers try to implement asynchronous processes one after the other instead of using async await and you can use modularization which breaks each one into a separated function also you can use JS generators with promises.  

**-  "what kind of framework have been using with nodejs"**

Basically Express, Koa, NestJS

**- "what's the difference between Express.Js and NestJS"**

Both is a framework ontop of Node,, but nestJS gives you more exposure into the internal working of Nodejs and it is opinionated 

**- "what is dependency injection"**

Separating where you are using the object from where you create it

It comes from IoC like the service locator, it just identifies certain tokens on a pre-configured in the code and inject it in runtime.

**- "what do you understand about Streaming"**

A way of managing data that allows the data processed without being read completely.

**- "what do you understand about EventEmitter"**

It is build around streams, its just a way to write more decoupled code  you dispatch an event and listen to events.

**- "what is the difference between Event Emitters and publisher and subscriber design pattern "**

for pub-sub there need to be an established topic in which you subscribe to and publisher will publish to. 

Event emitter is limited with scope within the same local service and the pubsub is not.

**- "what databases are you familiar with"**

MongoDB, PostgreSQL, SQLite, H2

**- "in your understanding, what's the difference between mongodb and postgres"**

Major difference is that Postgres is relation database (Stores the data in a structure  format)

**- "do you have any experience with WebSockets"**

Yes, i wrote a singleton that utilizes websockets to connect with RoR action cable

**- "what's the difference between one that use WebSockets to communicate  with the backend, and one application that use RESTful API to do the same?**

RESTful works with request-response architecture, with web socket you introduce a 2 way connection.

**"do you have experience with graphQL? and What is it?"**

Yes, it used to dement the rest architecture.
