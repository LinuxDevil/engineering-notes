---
notion-id: 2de22d69-391d-4cd1-822c-fa9f35f1c703
---
In Libuv we always have an open channel with the computer internals to (Execution Threads) to move the file content to Node.

Thread is the computer ability to do one thing at a time or task.

Which IO in Node sets up a thread dedicated in Node through LibUV ?

fs sets up a thread and a socket through LibUV to start reading the file

The call stack

JS way of tracking what line is currently running 

always there’s a global function and then functions will be added then removed when it stops
