---
notion-id: 7759fa5a-8f19-4b74-acbd-d1a8fc31a4b7
---

NodeJS is just a runtime environment which we can write JS to it.

The elements that compose NodeJS is 

![[Untitled 68.png]]

- V8 Engine
- Libuv C++ Library
- http-parser 
- c-ares
- OpenSSL
- zlib

V8 is about 70% C++ and 30% JavaScript, while Libuv is almost completely written in C.


What is the JS Engine ?

JS Engine is nothing more than an on-demand execution environment for any JS code working or not. All that surrounds it, the environment, the event loop, is responsible for scheduling the JS code executions, which are called events.

![[Untitled 69.png]]

The engine is just a tiny bit of what makes JavaScript, well... JavaScript... There are browser-provided APIs which we call **Web APIs** — or also, **external APIs** — these APIs (like `DOM`, `AJAX` and `setTimeout`) are provided by the browser vendors — in this case, for Chrome, it's Google — or by the runtime itself, like Node (with different APIs). And they are the main reason why most people hated (and still hate) JavaScript. When we look at today's JavaScript we see a field filled with packages and other stuff, but mostly homogeneous on every side. Well... It wasn't always like that.

### Call stack

*The call stack is not a part of Javascript itself, it's a part of its engine, in our case, V8. *

![[Untitled 70.png]]

Most people have heard that JS is a single-threaded language, and they just accepted it as the final truth in the universe without ever really knowing why. Being single-threaded means we only have a single call stack, in other words, we can only execute one thing at a time.

## Libuv (it's a full abstraction around several key parts of every OS)

### What is libuv? Why do we need it?

Libuv is an open-source library that handles the thread-pool, doing signaling, inter process communications all other magic needed to make the asynchronous tasks work at all. Libuv was originally developed for Node.js itself as an abstraction around `libev`, however, by now, multiple projects are already using it.

Most people think libuv is the event loop itself, this is not true, libuv implements a full featured event loop, but also is the home of several other key parts of Node, such as:

- TCP and UDP sockets of the `net` package
- Async DNS resolutions
- Async file and file system operations (like the one we're doing here)
- File System events
- IPC
- Child processes and shell control
- Thread pool
- Signal handling
- High resolution clock

### Event Loop

The event loop is what actually takes care of asynchronous code execution for JS Engines, at least of the scheduling part. It is the one who calls the engine and send the commands to be executed, and also is the one who queues response callbacks which the engine returns to be called afterwards.



**Microtasks and Macrotasks**

It's a layer on top of the callback queue - which will now be called "**Macrotask Queue**" - that you'll most likely bump into when working with Promises.

Since there are no restrictions of what a Microtask can do to your code, it's possible for a Microtask to add another Microtask in the end of the same queue endlessly, causing what is called a "Microtask loop", which starves the program of the needed resources and prevent it from moving on the the next tick. This is the equivalent of having a `while(true)` loop running in your code, but asynchronously.

In order to prevent such starvation, the engine has built-in protection called `process.maxTickDepth`, which is set to the value of 1000, after 1000 microtasks have been scheduled and ran in the same tick, then the next macrotask is run.

One and exactly one, macrotask should be processed from the macrotask queue in one tick of the event loop. After this macrotask has finished, all other available microtasks should be processed within the same tick. Since microtasks can queue other microtasks, while there are microtasks in the microtask queue, they should all be run one by one until the microtask queue is empty. As shows this diagram:

![[Untitled 71.png]]

Not all tasks are microtasks, these are some examples of microtasks:

- `process.nextTick`
- Promises
- `Object.observe`

These are macrotasks:

- `setTimeout`
- `setInterval`
- `setImmediate`
- any I/O operation

## What is V8

V8 is Google's open source high-performance JavaScript and WebAssembly engine. It's written in C++ and used both in Chrome or Chrome-like environments, and Node.js. V8 has the full implementation for ECMAScript as well as WebAssembly. But it does not depend on a browser, in fact, V8 can be run standalone and be embedded into any C++ application.

**Ignition**: It runs your code the first time using a first non-optimised compiler called, it compiles the code straight to how it should be read, then, after a few runs

**JIT compile**: receives a lot of information on how your code actually behave in most cases and recompiles the code so it's optimised to how it's running at that time

V8 also uses a lot of different threads to make itself faster:

- The main thread is the one that fetches, compiles and executes JS code
- Another thread is used for optimisation compiling so the main thread continues the execution while the former is optimising the running code
- A third thread is used only for profilling, which tells the runtime which methods need optimisation
- A few other threads to handle garbage collection

### Abstract Syntax Trees

The first step in all compiling pipelines of almost every language out there is to generate what is called an **AST (Abstract Syntax Tree)**. An abstract syntax tree is a tree representation of the syntactic structure of a given source code in an abstract form, which means that it could, in theory, be translated to any other language. Each node of the tree denotes a language construct which occurs in the source code.

### Hidden Classes

Generally when we have statically-typed languages, we can easily determine where a property is in memory, since all objects and variables are determined by a fixed object layout you'll define as its type, and new properties cannot be added during runtime, which makes pretty easy for the compiler to find this properties' values (or pointers) in memory since they can be stored as a continuous buffer with a fixed [offset](http://en.wikipedia.org/wiki/Offset_%28computer_science%29) between each object. And this [offset](http://en.wikipedia.org/wiki/Offset_%28computer_science%29) can be easily determined by the object type, since all types have a fixed memory value. V8 takes advantage of these fixed layout object concept to use the approach of a hidden class

However, hidden classes are extremely volatile, they are one and only to that specific type of object. So, if we swap the order of our properties to be `y` and `x` instead of the opposite, V8 would have to create new hidden classes since C1 only has offsets for x in the position 0 and C2 only has offsets for y in the first position.

But keep in mind **this is done in the C++** because **JavaScript is a prototype-based language, therefore, it has no classes.**


## Old V8

V8 had an old execution pipeline which was composed of the full-codegen compiler, and a JIT compiler called Crankshaft, which had two subcomponents called Hydrogen and Lithium

![[Untitled 72.png]]

### **The full-codegen compiler**

Full-codegen compiler is a simple and very fast compiler that produced simple and relatively slow (not-optimised) machine code. The main purpose of this compiler is to be absolutely fast, but to write extremely shitty code. So it translates JS to machine code at the speed of light, however the code is not optimised and might be very slow. Also, it handles the type-feedback that collects information about data types and usage of our functions as our program runs.

It firstly takes our **AST(Abstract Syntax Tree)**, walks over all the nodes and emits calls to a macro-assembler directly. The result: generic native code. That's it! The full-codegen fulfilled its purpose.

The magic starts when V8 perceives hot and cold functions!

*(A hot function is a function that is called several times during the execution of our program so it needs to be optimised more than the others. A cold function is the exact opposite. That's when the Crankshaft compiled comes on.)*

## Crankshaft

The Crankshaft compiler used to be the default JIT compiler that handled all the optimisation parts of JS.

After receiving the type information and call information from the runtime that full-codegen created, it analyses the data and see which functions have become hot. Then Crankshaft can walk the AST generating optimised code for these particular functions. Afterwards, the optimised function will replace the unoptimised one using what is called **on-stack replacement (OSR)**.

### Hydrogen compiler

The Hydrogen compiler takes the AST with type-feedback information as its input. Based on that information it generates what's called a high-level intermediate representation (HIR) which has a control-flow graph (CFG) in the static-single assignment form (SSA) which is something like this:

For this given function:

```javascript
function clamp (x, lower, upper) {
  if (x < lower) x = lower
  else if (x > upper) x = upper
  return x
}
```

An SSA translation would be:

```plain text
entry:
  x0, lower0, upper0 = args;
  goto b0;

b0:
  t0 = x0 < lower0;
  goto t0 ? b1 : b2;

b1:
  x1 = lower0;
  goto exit;

b2:
  t1 = x0 > upper0;
  goto t1 ? b3 : exit;

b3:
  x2 = upper0;
  goto exit;

exit:
  x4 = phi(x0, x1, x2);
  return x4;

```

In SSA variables are never assigned again; they are bound once to their value and that's it. This form breaks down any procedure into several basic blocks of computation which ends with a branch to another block whether this branch is conditional or not. As you can see variables are bound to unique names at each assignment and, in the end, the `phi` function takes all the `x`s and merge them together, returning the one which has a value.

When the HIR is being generated, Hydrogen applies several optimisations to the code such as constant folding, method inlining and other stuff, The result Hydrogen outputs is an optimised CFG which the next compiler, Lithium, takes as input to generate actual optimised code.

### Lithium compiler

As we said, the Lithium compiler takes the HIR and translates into a machine-specific low-level intermediate representation (LIR). Which is conceptually similar to what a machine code should be, but also platform independent.

While this LIR is being generated, new code optimisations are applied, but this time those are low-level optimisations.

In the end, this LIR is read and Crankshaft generates a sequence of native instructions for every Lithium instruction, the OSR is applied and then the code is executed.

## **The new V8**

After version V8.5.9, V8 changed its old pipeline (composed of Full-Codegen and Crankshaft) to a new pipeline which uses two brand new compilers, the Ignition and TurboFan. This new pipeline is mostly why JS runs blazing fast nowadays.

![[Untitled 73.png]]

Basically, the initial steps have not changed, we still need to generate an AST and parse all the JS code, however, Full-Codegen has been replaced by Ignition and Crankshaft has been replaced by TurboFan.

### **Ignition**

Ignition is a bytecode interpreter for V8, but why do we need an interpreter? Compilers are much faster than an interpreter. Ignition was mainly created for the purpose of reducing memory usage. Since V8 don't have a parser, most code is parsed and compiled on the fly, so several parts of the code are actually compiled and recompiled more than once. This locks up to 20% of memory in V8's heap and it's specially bad for devices with low memory capabilities.

One thing to notice is that Ignition is **not** a parser, it is a bytecode interpreter, which means that the code is being read in bytecode and outputted in bytecode, basically, what ignition does is take a bytecode source and optimized it to generate much smaller bytecode and remove unused code as well. This means that, instead of lazy compiling the JS on the fly, like before, Ignition just takes the whole script, parses it and compiles all at once, reducing compiling time and also generating much smaller bytecode footprints.

So in short. This old compiling pipeline:

![[Untitled 74.png]]

Has become this:

![[Untitled 75.png]]

Which means that the AST, which was the source of truth for the compilers, is now fed into Ignition which walks all nodes and generates bytecodes that is the new source for all compilers.

Essentially, what Ignition does is turn code into bytecodes, so it does things like this:

![[Untitled 76.png]]

As you can see, this is a register-based interpreter, so you can see the registers being manipulated around function calls. `r0` is the representation of a local variable or a temporary expression which needs to be stored on the stack. The baseline to imagine is that you have an infinite register file, since those are **not** machine registers, they get allocated onto the stack frame when we start. In this specific function there's only one register that's used. Once the function starts, `r0` is allocated onto the stack as `undefined`. The other registers (`a0` to `a2`) are the arguments for that function (`a`, `b` and `c`) which are passed by the calee, so they're on the stack as well, this means we can operate them as registers.

There's also another implicit register called `accumulator`, which is stored in the machine's registers, where all the input or output should go, this means the results of operations and variable loadings

Reading that bytecode we have these set of instructions:

```plain text
LdaSmi #100 -> Load constant 100 into the accumulator (Smi is Small Integer)
Sub a2 -> Subtract the constant we loaded from the a2 parameter (which is c) and store in the accumulator
Star r0 -> Store the value in the accumulator into r0
Ldar a1 -> Read the value of the a1 parameter (b) and store into the accumulator
Mul r0 -> Multiply r0 by the accumulator and store the result also in the accumulator
Add a0 -> Adds the first parameter a0 (a) into the accumulator and stores the result in the accumulator
Return -> Return

```

After walking the AST, the generated bytecode is fed one at a time to an optimisation pipeline. So before Ignition can interpret anything, some optimisation techniques like register optimisation, peephole optimisations and dead code removal are applied by the parser.

![[Untitled 77.png]]

Ignition is basically written using the backend of the TurboFan compiler, a write-once macro assembler and compiles to all architectures. And also, we can have the low level optimisations that TurboFan generates for free.

### **Turbofan**

TurboFan is the JS optimizing compiler which, now, replaced Crankshaft as official JIT compiler. But it wasn't always like that. TurboFan was initially designed to be a very good webasm compiler. the initial version of TurboFan was actually pretty smart, with a lot of type and code optimisations that would perform very well in general JavaScript.

TurboFan uses what is called a Sea-of-Nodes representation that alone increased the overall compiling performance of JavaScript code by a lot. The whole idea of TurboFan is to implement everything that Crankshaft already had, but also make possible for V8 to compile faster ES6 code, which Crankshaft did not know how to deal with. So TurboFan started as a secondary compiler only for ES6 code:

![[Untitled 78.png]]

The whole problem with this, besides the technical complexity, is that the language features should be implemented in different parts of the pipeline and all those pipelines should be compatible with each other, including the code optimisations they all generated. V8 used this compiling pipeline for a while, when TurboFan couldn't actually handle all the use cases, but, eventually, this pipeline was replaced by this other one:

![[Untitled 79.png]]

As we saw in the previous chapter, Ignition came to interpret the parsed JS code into bytecode, which became the new source of truth for all compilers in the pipeline, the AST was no longer the single source of truth which all compilers relied on while compiling code. This simple change made possible a number of different optimisation techniques such as the faster removal of dead code and also a lot smaller memory and startup footprint.

Aside of that, TurboFan is clearly divided into 3 separate layers: the frontend, the optimizing layer and the backend.

The frontend layer is responsible for the generation of bytecode which is run by the Ignition interpreter, the optimizing layer is responsible solely for optimizing code using the TurboFan optimizing compiler. All other lower level tasks, such as low level optimisations, scheduling and generation of machine code for supported architectures is handled by the backend layer - Ignition also relies on TurboFan's backend layer to generate its bytecode. The separation of the layers alone led to 29% less machine-specific code than before.

![[Untitled 80.png]]

**Understanding Bytecodes**

Bytecodes are abstractions of machine codes. Think of it as something in between the code we can read and the code machines execute. However, bytecodes are **machine agnostic**, which means that bytecodes can be compiled into whatever machine architecture you're running on – however, compiling bytecode to machine code is way easier if you generate bytecode which was designed with the same computational model as the underlying CPU.

CPUs are Turing machines that are either based on stacks, registers or states. V8's Ignition interpreter is a **register-based interpreter with an accumulator** as well as most of the CPUs.

![[Untitled 81.png]]

In the end, bytecode is translated into assembly/machine code which can be sent to the processor and executed.

You can think of JavaScript as a series of small building blocks. Each operator (or sets of operators) have a bytecode notation in V8. So we have bytecodes for operators like `typeof`, `add`, `sub` and we also have operators for property loads like `LdaSmi` for small integers or `LdaNamedProperty`. The complete list can be found at the [header file](https://github.com/v8/v8/blob/master/src/interpreter/bytecodes.h)

## Registers

Ignition uses registers like `r0, r1, r2 ...` to store bytecode inputs or outputs and specifies which ones to use. Along with input registers, Ignition also has an accumulator register, which stores the results of operations, we'll call it `acc`. It's pretty much the same as common registers but operands do not specify it at all, for instance, `sub r0` is subtracting the value in `r0` **from** the value **in** the accumulator, leaving the result value in the `acc` itself.

You'll see that many bytecodes start with `Lda` or `Sta`, the `a` stands for "accumulator", while `Ld` is "load" and `St` is "store". So, by intuition, `LdaSmi [99]` loads the small integer `99` into the accumulator, while `Star r0` stores the value of the accumulator into the register `r0`.

This is because if we wrote: "LoadSmallIntToAccumulator" instead of "LdaSmi" we'd have to allocate more memory just to store the bytecode name. This is why bytecodes scare a lot of people.

> Shorter bytecodes = less memory

Let's take a real bytecode from a real function in JavaScript. We're not using our `readFile` function since it'd be too complicated. Let's use this simple function:

```javascript
function multiplyXByY (obj) {
  return obj.x * obj.y
}

multiplyXByY({ x: 1, y: 2 })

```

> *A small note*: V8 compiler is lazy, so if you don't run a function, it is not compiled, which means it does not generate any bytecode.

This will generate the following bytecode:

```plain text
[generated bytecode for function: multiplyXByY]
Parameter count 2
Register count 1
Frame size 8
   22 E> 0x334a92de11fe @    0 : a5                StackCheck
   43 S> 0x334a92de11ff @    1 : 28 02 00 01       LdaNamedProperty a0, [0], [1]
         0x334a92de1203 @    5 : 26 fb             Star r0
   51 E> 0x334a92de1205 @    7 : 28 02 01 03       LdaNamedProperty a0, [1], [3]
   45 E> 0x334a92de1209 @   11 : 36 fb 00          Mul r0, [0]
   52 S> 0x334a92de120c @   14 : a9                Return
Constant pool (size = 2)
Handler Table (size = 0)

```

> You can generate and print your bytecode using the command node --print-bytecode --print-bytecode-filter=functionName <file>

**LdaNamedProperty a0, [0], [1]**

This bytecode loads a named property of `a0` – Ignition identifies parameters as `a0, a1, a2...`, the number is the index of the argument, so `a0` is the first argument of the function (`obj`) – into the accumulator.

In this particular bytecode, we're looking up the named property on `a0`, so we're loading the first argument of the function, which is `obj`. The name we're looking at is determined by the first parameter: `[0]`. This constant is used to look up the name in a separate table – which can be accessed in the `Constant Pool` part of the print, but only in Node.js debug mode:

```plain text
0x263ab302cf21: [FixedArray] in OldSpace
 - map = 0x2ddf8367abce <Map(HOLEY_ELEMENTS)>
 - length: 2
           0: 0x2ddf8db91611 <String[1]: x>
           1: 0x2ddf8db67544 <String[1]: y>

```

So we see that position 0 is `x`. The `[1]` is the index of what is called "feedback vector", which contains runtime information that is used for optimizations.

**Star r0**

`Star r0` stores the value that is currently in the accumulator, which is the value of the `x` index we just loaded, in the register `r0`.

**LdaNamedProperty a0, [1], [3]**

This is the same thing, but we're now loading the index 1, which is `y`.

**Mul r0, [0]**

This operation multiplies the value that is currently in the accumulator (`y`) by `r0` (`x`) and stores the result into the accumulator.

**Return**

The return statement returns the value that is currently in the accumulator. It's also the end of the function. So the function caller will start with the result of our last bytecode operation – which is `2` – already in the accumulator.

### **Collecting the Garbage**

Garbage collection is a common practice for memory management in most languages. The only job of a [GC](https://docs.microsoft.com/dotnet/standard/garbage-collection/fundamentals?WT.mc_id=devto-blog-ludossan) is to reclaim the memory that is being occupied by unused objects. It was first used in LISP in 1959.

Since we do not need to worry about memory anymore, it's fully handled by the compiler. So, memory allocation is automatically done when we need to allocate a new variable and it's automatically cleaned up when this memory is no longer needed.

The way [GC](https://docs.microsoft.com/dotnet/standard/garbage-collection/fundamentals?WT.mc_id=devto-blog-ludossan) knows when objects are no longer used is by their references or how they reference each other. When an object is not referencing nor being referenced by any other object, it is garbage collected. Take a look at this diagram:

![[Untitled 82.png]]

You can see there are a few objects referencing and referenced, but there are two objects which are not being referenced or referencing anyone. So these will be deleted and their memory reclaimed. This is the diagram after the [GC](https://docs.microsoft.com/dotnet/standard/garbage-collection/fundamentals?WT.mc_id=devto-blog-ludossan) sweep:

![[Untitled 83.png]]

The downsides of using garbage collectors are that they might have a huge performance impact and might have unpredictable stalls.

- **The Stack**: The stack is where all local variables, pointers to objects or application control flow. In our function, both parameters will be placed on the stack.
- **The heap**: The heap is the part of our program where reference type objects are stored, like strings, or objects. So the `Point` object below will be placed on the heap.

In order to show how memory management works, let's take a simple example:

```javascript
function Point (x, y) {
  this.x = x
  this.y = y
}

const point1 = new Point(1, 2)  return a + b

add(4, 5)

```

If we take a look at the memory footprint in the heap, we would have something like this:

```plain text
root -----------> point1

```

Now let's add some other points:

```javascript
function Point (x, y) {
  this.x = x
  this.y = y
}

const point1 = new Point(1, 2)
const point2 = new Point(2, 3)
const point3 = new Point(4, 4)

```

We'd have this:

```plain text
     |-------------------> point1
root |-------------------> point2
     |-------------------> point3
```

Now, if the [GC](https://docs.microsoft.com/dotnet/standard/garbage-collection/fundamentals?WT.mc_id=devto-blog-ludossan) would run, nothing would happen, since all our object store references to the root object.

Let's add some objects in the middle:

```javascript
function Chart (name) {
  this.name = name
}

function Point (x, y, name) {
  this.x = x
  this.y = y
  this.name = new Chart(name)
}

const point1 = new Point(1, 2, 'Chart1')
const point2 = new Point(2, 3, 'Chart2')
const point3 = new Point(4, 4, 'Chart3')

```

Now we would have this:

```plain text
     |-------------------> point1 ----> Chart1
root |-------------------> point2 ----> Chart2
     |-------------------> point3 ----> Chart3

```

Now, what would happen if we set our `point2` to `undefined`?

```plain text
     |-------------------> point1 ----> Chart1
root |                     point2 ----> Chart2
     |-------------------> point3 ----> Chart3

```

Notice that, now, the `point2` object cannot be reached from the root object. So, at the next [GC](https://docs.microsoft.com/dotnet/standard/garbage-collection/fundamentals?WT.mc_id=devto-blog-ludossan) run it would be eliminated:

```plain text
     |-------------------> point1 ----> Chart1
root
     |-------------------> point3 ----> Chart3

```

This is basically how [GC](https://docs.microsoft.com/dotnet/standard/garbage-collection/fundamentals?WT.mc_id=devto-blog-ludossan) works, it walks the root to all objects, if there are any objects in the object list which has not been accessed by the walk, then it cannot be accessed by the root, so it'd be removed.

[GC](https://docs.microsoft.com/dotnet/standard/garbage-collection/fundamentals?WT.mc_id=devto-blog-ludossan) can happen in different methods.

## [GC](https://docs.microsoft.com/dotnet/standard/garbage-collection/fundamentals?WT.mc_id=devto-blog-ludossan) Methods

There are many methods to handle GC.

**New Space and Old Space**

This is the method [Node.js](https://docs.microsoft.com/windows/nodejs/?WT.mc_id=devto-blog-ludossan) uses.

The heap has two main segments: the *new space* and the *old space*. The new space is where allocations are actively happening; this is the fastest place where we could collect garbage, the new space is about 1 to 8 MBs. All objects in the new space are called the **young generation**.

In contrast, the old space is where the objects that survived the last garbage collection resides, in our case, the `point1` and `point3` objects are in the old space. They are called the **old generation**. Allocation in the old space is pretty fast, however, [GC](https://docs.microsoft.com/dotnet/standard/garbage-collection/fundamentals?WT.mc_id=devto-blog-ludossan) is expensive, so it's hardly ever performed.

But, hardly 20% of the young generation survives and it's promoted to the old generation, so this old space sweep does not actually need to be done very often. It's only performed when this space is getting exhausted, which means around 512mb, you can set this limit with the `--max-old-space-size` flag in Node.js. To reclaim the old space memory, the [GC](https://docs.microsoft.com/dotnet/standard/garbage-collection/fundamentals?WT.mc_id=devto-blog-ludossan) uses two different collection algorithms.

**Scavenge and Mark-Sweep Collection**

The scavenge collection is fast and runs in the young generation, while the mark-sweep collection method is slower and runs on the old generation.

Mark & Sweep algorithm works in just a few steps:

1. It starts with the root object. Roots are global variables that get referenced in the code. In [JS](https://docs.microsoft.com/azure/javascript/?WT.mc_id=devto-blog-ludossan) this may be either the `window` object or, in Node, the `global` object. The complete list of all those roots is built by the [GC](https://docs.microsoft.com/dotnet/standard/garbage-collection/fundamentals?WT.mc_id=devto-blog-ludossan).
2. The algorithm then inspects all roots and all their children, marking each one as active - so that means they're not garbage yet - logically, anything else the root cannot reach will not be marked active, which means: garbage
3. After that, all non-active objects are freed.

![[mark-sweep.gif]]

# **Compiler Optimizations!**

All of the optimizations below are done while the compiler is analyzing the code.

## On Stack Replacement

On Stack Replacement is the optimization technique that replaces a chunk of not-optimized code by another chunk of optimised code during execution. V8 does that every time it needs to optimize a single function or the running code. In short, on stack replacement means that the current stack frame will be replaced by another stack frame of optimised code without losing any other information and while the code is still executing. It's like changing the tires of a car in the middle of a race without stopping.

## Constant Folding

Replaces constant expressions by their final value at compile-time, rather than doing the calculation at run-time.

Example:

*not compiled:*

```javascript
const j = 3 + 9

```

*compiled:*

```javascript
const j = 12

```

## Induction Variable Analysis

In a loop, if a variable is a simple linear function of the index variable, for instance, `const p = 4 * i +1` then it can be updated appropriately each time the loop variable is changed.

This is what is called a strength reduction, a form of optimisation where costly operations are replaced by equivalent less costly ones, for instance, a costly multiplication is replaced by a series of cheaper additions.

## Rematerialization

The act of recalculating a value instead of loading it from memory, which prevents memory access to be performed too many times.

## Removing Recursion

Recursion is often very expensive, as we saw about stack overflows. Tail recursive algorithms (code that ends returning a call to itself) can be converted to iterative algorithms, which eliminates the stack problems. This is often done by using [**Tail Call Optimisations**](https://en.wikipedia.org/wiki/Tail_call), which is the process where you are able to avoid allocation a new stack frame for a function because the calling function will simply return the value that it gets from the called function. So this last call can be replaced by the function itself.

## Peephole Optimisations

These are usually performed late in the compilation process after the machine code has been generated. This optimisation technique examines a few adjacent instructions (like looking through a peephole) to see if they can be replaced by a single instruction or a shorter sequence of instructions. An example is a multiplication by a power of 2, which can be replaced by a bitwise left-shift. (which is also a strength reduction optimisation)

### Inline Expansion

This is the technique of replacing the call to a function by its body. This saves the overhead of adding another stack frame and also adds a great opportunity for parameter specific optimisations, but this comes at the cost of space. If the procedure is called several times during a program, its body will be replaced several times, which can lead to a bigger, heavier code.

Generally, inlining is very useful to performance-critical code that makes a large number of calls to small procedures, so there are fewer jumps.

## Inline Caching

Inline caching relies on the observation that repeated calls to the same method tend to occur on the same type of object. V8 maintains a cache of the type of objects that were passed as a parameter in recent method calls and uses this information to make an assumption about the type of object that'll be passed as a parameter in the future. If this assumption is good, then the next call can bypass the process of figuring out how to access the object's properties and, instead, use the stored information from precious lookups to the hidden class of that object.

This relates specifically to the concept of hidden classes because whenever a method is called on a specific object, the engine has to lookup the hidden class in order to find the memory offset for such called property. After two successful calls of that same method to the same hidden class, V8 omits the hidden class lookup and adds the offset to that property to the object pointer itself. This greatly increases execution speed.

## Dead Code Elimination

This process eliminates code that is never called in the program. It does this, roughly, by passing through all bytecodes during program execution, generates a graph and eliminates those parts which do not belong to any code path.

## Code Block Reordering

Code-block reordering alters the order of the basic blocks in a program in order to reduce conditional branches and improve locality of reference, which is the tendency of a processor to access the same set of memory locations repetitively over a short period of time.

## Jump Threading

Consecutive conditional jumps predicated entirely or partially on the same condition can be merged. E.g: `if (c) { foo; } if (c) { bar; }` becomes `if (c) { foo; bar; }`

## Trampolines

Many CPUs have smaller subroutines call instructions in order to access low memory. The compiler can save space using these small calls in the function's body. Multiplying space savings from code refactoring.

## Common subexpression elimination

Whenever we have repeated subexpressions, like in `(a+b) * 2+(a+b)`, the *common subexpression* is `a+b`. So, the compiler calculates the value of `a+b` only once and uses *constant folding* to replace it in the expression call, assuming the common subexpression will **not** change.