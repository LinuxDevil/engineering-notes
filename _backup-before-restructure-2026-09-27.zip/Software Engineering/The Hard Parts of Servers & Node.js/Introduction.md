---
notion-id: 9acb42b3-8e2e-4cc0-b379-2fec7ebebad9
---


Node calls c++ to execute filesystem and network.

![[Screenshot_2023-04-28_at_1.26.30_AM.png]]

const a = ‘ali’;

There’s Facade when writing` fs = require(’fs’)` to be able to talk with the network interface through C++ for example.

Node.js relies on various dependencies under the hood for providing various features.

- V8
- libuv
- llhttp
- c-ares
- OpenSSL

Node using Libuv to communicate with C++ for inbound messages.

**libuv:** libuv is a C library originally written for Node.js to abstract **non-blocking I/O operations**.

- Event-driven asynchronous I/O model is integrated.
- It allows the CPU and other resources to be used simultaneously while still performing I/O operations, thereby resulting in efficient use of resources and network.
- It facilitates an event-driven approach wherein I/O and other activities are performed using callback-based notifications.

**Example:** If a program is querying the database, the CPU sits idle until the query is processed and the program stays at a halt, thereby causing wastage of system resources. To prevent this, **libuv** is used in Node.js which facilitates a non-blocking I/O.

It also has mechanisms to handle services like [**File System**](https://www.geeksforgeeks.org/node-js-file-system/)**, **[**DNS**](https://www.geeksforgeeks.org/nodejs-dns/)**, network, **[**child processes**](https://www.geeksforgeeks.org/node-js-child-process/)**, pipes, signal handling, polling**,** and **[**streaming**](https://www.geeksforgeeks.org/node-js-streams/)**.**To perform blocking operations that can’t be done asynchronously at OS level, libuv also includes a **thread pool** to distribute CPU loads.

- **What is a thread pool?** 

Libuv assigns tasks to a pool of worker threads. However, all callbacks that occur on task completion are executed on the main thread. **Note:** After Node 10.5 worker threads can also be used to execute JavaScript in parallel. Libuv uses 4 threads by default, but can be changed using the **UV_THREADPOOL_SIZE**

The only <u>**2 things JS can do be itself**</u> is saving data and using data.

The JS stores data in the Global variable environment (Memory) 

The JS takes the function name an parameters and save it to memory.

![[Screenshot_2023-04-28_at_1.53.36_AM.png]]


**Thread execution** in JS means the ability to go line by line to execute.

To run the code inside a function, we need a new execution context.

JS is just doing saving data and code and runs code in the data.

JS other talent is built-in labels that triggers Node features.

The node feature that’s gonna access the network called net and more specialized one called http.

 

```bash
const http = require('http');

const server = http.createServer();
server.listen(80);
```

This code

```bash
http.createServer
```

is returning am object to a server (it’s actually a sudo function)

```bash
server.listen(80)
```

This code is a call for a node & C++ internal code Network library to a libuv (that insure that we can run node on any machine and links node to our machine hardware) so it opens a channel (socket) in our internal computer system. 

Ports (are entry points)
