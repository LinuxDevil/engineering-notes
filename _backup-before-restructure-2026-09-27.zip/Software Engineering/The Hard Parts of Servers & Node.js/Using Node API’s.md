---
notion-id: 6f75db0d-b8f4-4fc5-ab52-6ad96181ae3b
---

Node auto run and auto fill the arguments in the 

```bash
(req, res) => {
	// ...
}
```

Node not only will auto-run our function at the right
moment, it will also automatically insert whatever the
relevant data is as the additional argument (input).


Sometimes it will even insert a set of functions in an
object (as an argument) which give us direct access to
the message (in Node) being sent back to the user and
allows us to add data to that message

What happens when a request comes to us is 

it arrives at the network card then node runs our beloved function (req,res) and create 2 anonymous objects, node here will look at the content of the request and start parsing it then it will route to the uri that match that parsing on the execution context of the (req, res). and the second object is our response object that node automatically create for us with some functions label like `end` that will be used to add and send data to the client.

![[Screenshot_2023-04-29_at_1.45.04_AM.png]]

JS is an evaluated language

the HTTP request text request to <GET> /path and the Headers (meta data [data about data])