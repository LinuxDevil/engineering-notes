---
notion-id: afc55399-1339-4560-b650-68a7fe5feb2d
cover: "[[The Hard Parts of Servers & Node.js]]"
---
[https://frontendmasters.com/courses/servers-node-js/introduction/](https://frontendmasters.com/courses/servers-node-js/introduction/)

![[Hard-Parts-Servers-Node.pdf]]

[[Software Engineering/The Hard Parts of Servers & Node.js/Introduction]]

[[Using Node API’s]]

[[Node with HTTP]]

[[File System]]

[[Streams]]

[[Node JS Under the hood!]]

[[Questions]]