---
notion-id: 7c5883b8-a83b-41ed-bba5-e556a5d9e372
---

Middleware are just to modularize the functions by passing the node created objects req, res and analyse it, change it and then send it back to the next middleware 

![[Screenshot_2023-04-30_at_12.10.27_AM.png]]

