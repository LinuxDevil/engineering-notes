---
notion-id: 8522a291-6b03-4f4b-a9c6-1827ac688f11
---

What are pipes and how to you can create a custom pipe 
    Pipes are simple functions that use [template expressions](https://github.com/sudheerj/angular-interview-questions#what-are-template-expressions) to accept data as input and transform it into a desired output. For example, let us take a pipe to transform a component's birthday property into a human-friendly date using **date** pipe.
```plain text
import { Component } from '@angular/core';

@Component({
  selector: 'app-birthday',
  template: `<p>Birthday is {{ birthday | date }}</p>`
})
export class BirthdayComponent {
  birthday = new Date(1987, 6, 18); // June 18, 1987
}
```

What is a custom pipe? Apart from built-in pipes, you can write your own custom pipe with the below key characteristics:
	1. A pipe is a class decorated with pipe metadata `@Pipe` decorator, which you import from the core Angular library For example,
		`@Pipe({name: 'myCustomPipe'})`
	2. The pipe class implements the **PipeTransform** interface's transform method that accepts an input value followed by optional parameters and returns the transformed value. The structure of `PipeTransform` would be as below,
		`interface PipeTransform {
  transform(value: any, ...args: any[]): any
}`
	3. The `@Pipe` decorator allows you to define the pipe name that you'll use within template expressions. It must be a valid JavaScript identifier.
```plain text
template: `{{someInputValue | myCustomPipe: someOtherValue}}`
```

Pure pipes vs Impure pipes
    A pure pipe is only called when Angular detects a change in the value or the parameters passed to a pipe. For example, any changes to a primitive input value (String, Number, Boolean, Symbol) or a changed object reference (Date, Array, Function, Object). An impure pipe is called for every change detection cycle no matter whether the value or parameters changes. i.e, An impure pipe is called often, as often as every keystroke or mouse-move.

Lazy loading in angular and bundling
    Lazy loading is one of the most useful concepts of Angular Routing. It helps us to download the web pages in chunks instead of downloading everything in a big bundle. It is used for lazy loading by asynchronously loading the feature module for routing whenever required using the property `loadChildren`. Let's load both `Customer` and `Order` feature modules lazily as below,
```plain text
const routes: Routes = [
  {
    path: 'customers',
    loadChildren: () => import('./customers/customers.module').then(module => module.CustomersModule)
  },
  {
    path: 'orders',
    loadChildren: () => import('./orders/orders.module').then(module => module.OrdersModule)
  },
  {
    path: '',
    redirectTo: '',
    pathMatch: 'full'
  }
];
```

Requests and responses 
    Yes you interact with HttpClient to perform a http request, and you get the value as an observable that you can subscribe to (or await the result to)


libraries application 
    ### What is an angular library?
    An Angular library is an Angular project that differs from an app in that it cannot run on its own. It must be imported and used in an app. For example, you can import or add `service worker` library to an Angular application which turns an application into a Progressive Web App (PWA).
    **Note:** You can create own third party library and publish it as npm package to be used in an Application.


How we reuse the components
    If it is between the same project, through a shared Module, if through independant projects that are not connected to a monorepo we can use a create a **Storybook** angular library for the components that we can use through the projects.


Is it possible to include CSS stylesheet in libraries 
    Yes


How to handle JWT Token
    With Interceptors, We can store the JWT to a **sessionStorage** or **indexedDB** in the browser and bring it to send it with each request in that interceptor.


How to share data between components
    **There are five ways to share data between components:**
[https://levelup.gitconnected.com/5-ways-to-share-data-between-angular-components-d656a7eb7f96](https://levelup.gitconnected.com/5-ways-to-share-data-between-angular-components-d656a7eb7f96)
	1. Parent to child component.
	2. Child to parent component.
	3. Sharing data between sibling components.
	4. Sharing data using ViewChild property.
	5. Sharing data between not related components.

How to update the data that is sent from a parent to child
[https://stackoverflow.com/questions/41464871/update-parent-component-property-from-child-component-in-angular-2](https://stackoverflow.com/questions/41464871/update-parent-component-property-from-child-component-in-angular-2)
    You need to use 2 way data-binding.
    `@Input()` is one way data-binding. to enable 2 way data-binding you need to add an `@Output()` corresponding to the property, with a "Change" suffix
```plain text
@Input() getSearchStatus: boolean;
@Output() getSearchStatusChange = new EventEmitter<boolean>();

```
    when you want to publish the change made to your property to the parent, you need to notify the parent with:
```plain text
this.getSearchStatusChange.emit(newValue)

```
    and in the parent you need to use the banana-in-a-box notation for that property:
```plain text
[(getSearchStatus)]="myBoundProperty"

```
    you can also bind to the property and trigger a callback when it changes in child:
```plain text
[getSearchStatus]="myBoundProperty" (getSearchStatusChange)="myCrazyCallback($event)"
```


→ **What are directives**

[https://www.freecodecamp.org/news/angular-directives-learn-how-to-use-or-create-custom-directives-in-angular-c9b133c24442/](https://www.freecodecamp.org/news/angular-directives-learn-how-to-use-or-create-custom-directives-in-angular-c9b133c24442/)
    From the core concept, Angular directives are categorized into three categories.
	1. **Attribute Directives**
	2. **Structural Directives**
	3. **Components**
    Directives add behaviour to an existing DOM element or an existing component instance.
    `import { Directive, ElementRef, Input } from '@angular/core';

@Directive({ selector: '[myHighlight]' })
export class HighlightDirective {
    constructor(el: ElementRef) {
       el.nativeElement.style.backgroundColor = 'yellow';
    }
}`
    Now this directive extends HTML element behavior with a yellow background as below
```plain text
<p myHighlight>Highlight me!</p>
```

→ How can we create custom directives  

[https://codecraft.tv/courses/angular/custom-directives/creating-a-custom-directive/](https://codecraft.tv/courses/angular/custom-directives/creating-a-custom-directive/)
    We create directives by annotating a class with the `@Directive` decorator.
    Let’s create a class called `CardHoverDirective` and use the `@Directive` dectorator to associate this class with our attribute `ccCardHover`, like so:
```plain text
import { Directive } from '@angular/core';

@Directive({
  selector:"[ccCardHover]"
})
class CardHoverDirective { }
```


→ Different between pipes and directives
    To bring it to the point in the most simple terms, i would say **a pipe is to manipulate data, while a directive is more for DOM manipulation**. A pipe gets data as an input, transforms it and outputs this data in another way. A directive gets a DOM element it's "attached" to and enhances it with some kind of features.


→ Bounce 

How does angular finds components, directives and pipes?
    The Angular compiler finds a component or directive in a template when it can match the selector of that component or directive in that template. Whereas it finds a pipe if the pipe's name appears within the pipe syntax of the template HTML.

What are the differences between Component and Directive?
    In a short note, A component(@component) is a directive-with-a-template.
    Some of the major differences are mentioned in a tabular form

| Component | Directive |
| --- | --- |
| To register a component we use @Component meta-data annotation | To register a directive we use @Directive meta-data annotation |
| Components are typically used to create UI widgets | Directives are used to add behavior to an existing DOM element |
| Component is used to break down the application into smaller components | Directive is used to design re-usable components |
| Only one component can be present per DOM element | Many directives can be used per DOM element |
| @View decorator or templateurl/template are mandatory | Directive doesn't use View |

[C#]

—> Policies vs Rules

—> Where to use it 

[Code First approach]

Model creating

—> One place update for the created date, update at

[Middlewares]

[Singletons]
    Singleton
    Transient

Exceptions Filters 

JWT