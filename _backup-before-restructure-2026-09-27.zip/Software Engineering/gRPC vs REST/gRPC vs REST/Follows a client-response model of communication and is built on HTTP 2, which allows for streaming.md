---
notion-id: 0955391f-de16-4ff4-a4f9-3109556f8abf
base: "[[gRPC vs REST.base]]"
REST: Follows a request-response model of communication and is typically built on HTTP 1.1.
Features: HTTP 1.1 vs HTTP 2
---
