---
notion-id: 2498f0be-fa2b-4ea0-a5c7-eb683081886f
base: "[[gRPC vs REST.base]]"
REST: Developers must use a third-party tool like Swagger or Postman to produce code for API requests.
Features: Code Generation Features
---
