---
notion-id: aa032d9b-fc45-437e-80d5-12936b10ee07
base: "[[gRPC vs REST.base]]"
REST: REST mainly relies on JSON or XML formats to send and receive data.
Features: Payload Data Structure
---
