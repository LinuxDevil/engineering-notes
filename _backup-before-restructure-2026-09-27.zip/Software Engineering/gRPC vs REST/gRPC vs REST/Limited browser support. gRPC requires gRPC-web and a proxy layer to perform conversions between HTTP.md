---
notion-id: 68dae257-b8df-40b9-b945-932aacc1499c
base: "[[gRPC vs REST.base]]"
REST: Universal browser support.
Features: Browser Support
---
