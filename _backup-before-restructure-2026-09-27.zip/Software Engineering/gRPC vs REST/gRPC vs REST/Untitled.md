---
notion-id: 862c2fa9-e025-4f1a-b1cb-e14504a26262
base: "[[gRPC vs REST.base]]"
REST: ""
Features: ""
---
