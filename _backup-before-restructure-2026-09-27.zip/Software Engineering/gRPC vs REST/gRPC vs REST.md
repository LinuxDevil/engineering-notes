---
notion-id: 14d7943d-57d2-43f7-b693-2e3baee99f04
cover: "[[gRPC vs REST.jpeg]]"
---
![[Untitled 20.png]]

**gRPC** (Google Remote Procedure Call)

**REST **(Representational State Transfer)

What is an **API**
    APIs stand for Application Programming Interfaces. These interfaces serve as a software intermediary that establishes specific determinations and rules for **applications to interact and talk to each other.**
    An API specifies the **types of requests** that one application (web page or mobile app) can make to another and further establishes: how to make those requests; which **data formats** to use; and the practices that users have to follow.
![[Untitled 21.png]]


**APIs and Microservices**
    On the one hand, in a **monolithic application**, all the project's functionalities are included in a single unit, more precisely, in a <u>single codebase</u>. On the other hand, a **microservice architecture** comprises several smaller services that communicate with each other using protocols like <u>HTTP</u>. The component services that are part of the microservices architecture communicate and interact with each other through APIs. In other words, **APIs** allow all the services that are integrated into a microservice application to **connect and communicate**.

What is **RPC** 
    RPC uses a **client-server model**. The requesting server (in other words, the client) requests a message that is translated by the RPC and sent to another server. Once the server receives the request, it sends the response back to the client. While the server is processing this call, the client is blocked, and the internal message passing within servers is hidden.
    Further, RPC allows the client to request a function in a particular format and receive the response in the exact same format. Nonetheless, the method of submitting a call with RPC API is found in the URL. RPC supports remote procedure calls both in **local and distributed environments**.
    Like a REST API, RPC also establishes the **rules of interaction** and how a user can submit "calls" (requests) to invoke methods that communicate and interact with the service.
    There are three types of RPC
		1. **Callback RPC**
		2. **Broadcast RPC**
		3. **Batch-mode RPC**
    In a nutshell **a software communication protocol that one program can use to request a service from a program located in another computer on a network without having to understand the network's details**. RPC is used to call other processes on the remote systems like a local system.
    **RPC applications will use UDP when sending data, and only fall back to TCP when the data to be transferred doesn't fit into a single UDP datagram.**


What is **REST**
    When using REST APIs, the response from the back-end data is passed to the clients (or users) through the JSON or XML messaging format. This architectural model tends to follow the **HTTP protocol**. However, it is not uncommon for RPC designs to also select a couple of ideas from HTTP while maintaining the RPC model. In fact, the majority of modern APIs are implemented by mapping the APIs to the same HTTP protocol, despite the model used (RPC or REST).
    When the REST API is publicly available, each service that integrates the microservice application can be presented to the user/client as a **resource** which can be accessed through the following HTTP commands:`GET`, `DELETE`, `POST`, and `PUT`.
    **Typical RESTful services are in fact implemented using HTTP or HTTPS over TCP/IP connections**.


What is **gRPC**
    gRPC stands for **Google Remote Procedure Call** and is a variant based on the RPC architecture. This technology follows an RPC API's implementation that uses **HTTP 2.0 protocol**, but HTTP is not presented to the API developer nor to the server. Hence, there is no need to worry about how the RPC concepts are mapped to HTTP, which reduces complexity.
    Overall, gRPC aims to make data transmissions between microservices **faster**. It is based on the approach of determining a service, establishing the methods and respective parameters to enable remote calling and return types.
    Moreover, it expresses the **RPC API model in an IDL** (interface description language), which offers a more straightway to determine remote procedures. By default, the IDL uses **Protocol Buffers** (but other alternatives are also available) to describe the service interface as well as the payload messages' structure.

# **gRPC vs REST: comparison**

Now that we have an overview of **gRPC and REST**, let's look at their main differences.

# **HTTP 1.1 vs HTTP 2**

REST APIs follow a **request-response model of communication** that is typically built on **HTTP 1.1**. Unfortunately, this implies that if a microservice receives multiple requests from multiple clients, the model has to handle each request at a time, which consequently slows the entire system. However, REST APIs can also be built on **HTTP 2**, but the request-response model of communication remains the same, which forbids REST APIs to make the most out of the HTTP 2 advantages, such as **streaming communication** and **bidirectional support**.

gRPC does not face a similar obstacle. It is built on HTTP 2 and instead follows a **client-response communication model**. These conditions support bidirectional communication and streaming communication due to gRPC's ability to receive **multiple requests from several clients** and handle those requests simultaneously by constantly streaming information. Plus, gRPC can also handle **"unary" interactions** like the ones built on HTTP 1.1.

In sum, gRPC is able to handle unary interactions and different types of streaming:

- **Unary:** when the client sends a single request and receives a single response.
- **Server-streaming:** when the server responds with a stream of messages to a client's request. Once all the data is sent, the server additionally delivers a status message to complete the process.
- **Client-streaming:** when the client sends a stream of messages and in turn receives a single response message from the server.
- **Bidirectional-streaming:** the two streams (client and server) are independent, meaning that they both can transmit messages in any order. The client is the one who initiates and ends the bidirectional streaming.

![[Untitled 22.png]]

# **Browser Support**

This aspect is probably one of the main REST API advantages over gRPC. On the one hand, **REST is fully supported by all browsers**. On the other hand, gRPC is still quite **limited** when it comes to browser support. Unfortunately, it requires **gRPC-web and a proxy layer** to perform conversions between HTTP 1.1 and HTTP 2. Therefore, gRPC ends up being mainly used for internal/private systems (API programs within a particular organization’s backend data and application functionality).

# **Payload Data Structure**

As previously mentioned, gRPC uses **Protocol Buffer** by default to serialize payload data. This solution is lighter since it enables a highly compressed format and reduces the messages' size. Further, [**Protobuf**](https://developers.google.com/protocol-buffers) (or Protocol Buffer) is binary; thus, it serializes and deserializes structured data in order to communicate and transmit it. In other words, the strongly typed messages can be automatically converted from Protobuf to the client and server's [programming language](https://www.imaginarycloud.com/blog/python-vs-java/).

In contrast, REST mainly relies on JSON or XML formats to send and receive data. In fact, even though it does not mandate any structure, **JSON** is the most popular format due to its flexibility and ability to send **dynamic data** without necessarily following a strict structure. Another significant benefit of using JSON is its **human-readability** level, which Protobuf cannot compete with yet.

Nonetheless, JSON is not as light-weight or fast when it comes to **data transmission**. The reason for that lies in the fact that when using REST, JSON (or other formats) must be serialized and turned into the programming language used on both the client and server sides. This adds an **extra step** to the process of transmitting data which can consequently damage performance and open a possibility for errors.

![[gRPC vs REST.base]]
