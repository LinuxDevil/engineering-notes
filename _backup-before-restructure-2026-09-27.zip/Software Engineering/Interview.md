---
notion-id: 187d91f9-7a99-804f-ac6d-d0e9618ceab1
cover: "[[Interview.jpeg]]"
---
> [!note]+ # Concepts
> ### **JavaScript Basics**
> 
> 1. **Var vs let vs const**:
>     - `var`: Function-scoped, allows redeclaration, hoisted with undefined.
>     - `let`: Block-scoped, no redeclaration, hoisted but not initialized (temporal dead zone).
>     - `const`: Block-scoped, immutable references, hoisted but not initialized.
> 2. **Primitive vs Non-Primitive Types**:
>     - Primitive: `string`, `number`, `boolean`, `null`, `undefined`, `symbol`, `bigint`.
>     - Non-Primitive: Objects (arrays, functions, objects).
> 3. **Scopes**:
>     - Global Scope: Accessible everywhere.
>     - Function Scope: Variables declared inside a function.
>     - Block Scope: Variables declared with `let` or `const` inside `{}`.
> 4. **Arrow Functions vs Regular Functions**:
>     - Arrow Functions: Lexical `this`, no `arguments` object.
>     - Regular Functions: Dynamic `this`, `arguments` object available.
> 5. **Objects**:
>     - Collections of key-value pairs, mutable.
> 6. `**this**`** Keyword**:
>     - Refers to the execution context (varies based on how/where a function is called).
> 7. **Event Loop, Call Stack, Micro Queue, Macro Queue**:
>     - **Call Stack**: Tracks function execution.
>     - **Event Loop**: Ensures the stack is clear before processing queues.
>     - **Micro Queue**: Processes Promises (higher priority).
>     - **Macro Queue**: Processes tasks like `setTimeout`.
> 8. **Promises**:
>     - Handles asynchronous operations with `then`, `catch`, `finally`.
> 9. **Queue Types**:
>     - Micro Queue: Priority queue for Promises.
>     - Macro Queue: Standard queue for tasks like `setTimeout`.
> 10. **Set vs Map**:
>     - `Set`: Unique values collection.
>     - `Map`: Key-value pairs, maintains insertion order.
> 11. **Combining Set and Map (Union)**:
>     - Combine using spread operator or utility functions.
> 12. **Temporal Dead Zone**:
>     - Variables are inaccessible from the start of their scope until declared.
> 13. **Hoisting**:
>     - Variables/functions move to the top of their scope.
> 14. **Async/Await**:
>     - Cleaner syntax for Promises, pauses execution with `await`.
> 15. **Callback Hell**:
>     - Nested callbacks leading to hard-to-maintain code.
> 16. **Null vs Undefined**:
>     - `null`: Explicitly set to nothing, has memory address.
>     - `undefined`: Variable declared but not assigned.
> 17. **Higher Order Functions**:
>     - Functions that take or return other functions (e.g., `map`, `filter`).
> 18. `**setTimeout**`:
>     - Executes a function after a specified delay.
> 19. **Promise Methods**:
>     - `all`: Resolves when all promises resolve.
>     - `race`: Resolves with the first settled promise.
>     - `any`: Resolves with the first fulfilled promise.
>     - `finally`: Executes after a promise settles.
> 20. **HTML Tree in Memory**:
>     - Saved as a string-based tree structure.
> 21. **React-Fiber Tree**:
>     - Uses linked lists, not sequential.
> 
> ---
> 
> ### **React**
> 
> 22. **Component Lifecycle**:
>     - `mounting`, `updating`, `unmounting`.
> 23. **Shadow DOM vs Virtual DOM**:
>     - **Shadow DOM**: Encapsulated DOM subtree.
>     - **Virtual DOM**: Lightweight in-memory representation of the DOM.
> 24. **Regular DOM vs Virtual DOM**:
>     - Virtual DOM is faster due to minimal updates via diffing.
> 25. **Virtual DOM Nodes**:
>     - Types: Elements, text, components.
> 26. **Error Boundaries**:
>     - Catch errors in child components.
> 27. **State vs Props**:
>     - State: Component-owned, mutable.
>     - Props: Parent-owned, immutable.
> 28. **Controlled vs Uncontrolled Forms**:
>     - Controlled: Input state is managed by React.
>     - Uncontrolled: Inputs maintain their own state.
> 29. **Hooks**:
>     - `useEffect`: Runs after render.
>     - `useLayoutEffect`: Runs before paint.
> 30. **useRef vs forwardRef**:
>     - `useRef`: Persistent value, doesn't re-render.
>     - `forwardRef`: Pass refs to child components.
> 31. **Reconciliation and Diffing Algorithm**:
>     - Efficiently updates DOM by comparing tree changes.
> 32. **Fiber Object**:
>     - Contains component, state, props, and update metadata.
> 33. **Prop Drilling**:
>     - Passing props through multiple components.
> 34. **Context API**:
>     - Shares state across the component tree without prop drilling.
> 35. **React Components**:
>     - Fragments, Strict Mode, Profiler.
> 36. **useReducer**:
>     - Manages complex state logic.
> 
> ---
> 
> ### **Next.js**
> 
> 37. **SSR, ISG, CSR**:
>     - SSR: Server-side rendering.
>     - ISG: Incremental Static Generation.
>     - CSR: Client-side rendering.
> 38. **Caching**:
>     - Improves performance by storing data.
> 39. **SEO in Next.js**:
>     - Pre-rendering, meta tags, and dynamic content.
> 40. **Dynamic SEO**:
>     - Use APIs and dynamic routes.
> 41. **Google Ranking**:
>     - Optimize content, performance, and metadata.
> 42. **Web Vitals**:
>     - Metrics for user experience.
> 43. **Vercel Problems**:
>     - Lambdas can lead to cold starts.
> 
> ---
> 
> ### **CSS & HTML**
> 
> 44. **Semantic HTML**:
>     - Tags with meaningful names (e.g., `<article>`, `<nav>`).
> 45. `**defer**`**, **`**pre-fetch**`**, **`**async**`:
>     - Control script loading.
> 46. **HTML Parsing**:
>     - Converts HTML into DOM.
> 47. **Functional CSS**:
>     - Utility-first CSS like Tailwind.
> 48. **Performance with CSS**:
>     - Use `transform` for GPU acceleration.
> 49. **Box Model**:
>     - Content, padding, border, margin.
> 50. **CSSOM**:
>     - CSS Object Model, derived from CSS parsing.
> 51. **Accessibility Tree**:
>     - DOM subset representing accessible content.

> [!note]+ # Questions
> ### **CSS & HTML**
> 
> - What is semantic HTML, and why is it important?
> - How do `defer`, `async`, and `pre-fetch` differ?
> - What tools can be used to analyze the accessibility of a web page?
> 
> ---
> 
> CSS
> 
> - How to turn GPU Processing instead of CPU
> - What is BEM
> - What is CSSOM? and how does it get evaluated in the browser ?
> - What is functional CSS, and what are its benefits?
> - What is CSS Specificity ?
> 
> ---
> 
> ### **React Hooks**
> 
> - What is the purpose of `useState` and how does it work internally?
> - How does `useEffect` differ from lifecycle methods like `componentDidMount`?
> - What is `useReducer`, and how is it different from `useState`?
> - How does the Context API integrate with hooks?
> - Can hooks be used conditionally? Why or why not?
> 
> ---
> 
> ### **React Rendering and Lifecycle**
> 
> - How does React reconcile changes to the virtual DOM with the actual DOM?
> - What happens during the React rendering process?
> - Can you explain the React component lifecycle with examples?
> - What are React’s phases in updating a component?
> - How do functional components handle lifecycle events compared to class components?
> 
> ---
> 
> ### **Types of React Components**
> 
> - What are functional components, and how are they different from class components?
> - What are Pure Components, and when should they be used?
> - What are higher-order components (HOCs), and how do they differ from render props?
> - How do controlled and uncontrolled components differ?
> - What is a forwardRef, and when should it be used?
> 
> ---
> 
> ### **Reconciliation**
> 
> - What is React's reconciliation process?
> - How does React determine the minimal number of updates required for the DOM?
> - What is the diffing algorithm, and how does it optimize updates?
> - What is the role of keys in React's reconciliation process?
> - Can you explain the concept of React Fiber and its role in reconciliation?
> 
> ---
> 
> ### **Rendering Strategies (SSG, SSR, CSR, ISR)**
> 
> - What is Server-Side Rendering (SSR), and when would you use it?
> - How does Static Site Generation (SSG) differ from SSR?
> - What is Incremental Static Regeneration (ISR), and how does it work in Next.js?
> - How does Client-Side Rendering (CSR) impact performance and SEO?
> - What are the trade-offs of using ISR compared to traditional SSG?
> 
> ---
> 
> ### **Hydration and SEO**
> 
> - What is the hydration process in React/Next.js?
> - How does hydration differ from rendering?
> - What factors impact SEO in a React or Next.js application?
> - How can you optimize web vitals for SEO in Next.js?
> - What tools would you use to analyze and fix SEO issues?
> 
> ---
> 
> ### **Critical Rendering Path**
> 
> - What is the critical rendering path in a web page?
>     is the sequence of steps a browser takes to process and render a web page for the user. It encompasses the process of converting the HTML, CSS, and JavaScript into pixels on the screen.
> - How can you optimize the critical rendering path for faster page loads?
> - What role do CSS and JavaScript play in the rendering path?
> - How does the browser prioritize tasks during the rendering process?
> - What tools can help analyze and improve the critical rendering path?
> 
> ---
> 
> ### **JavaScript Basics**
> 
> - What is the difference between `var`, `let`, and `const`?
> - What are the primitive data types in JavaScript?
> - How do scopes work in JavaScript?
> - How does the `this` keyword behave in arrow functions versus regular functions?
> - What is hoisting, and how does it affect `var`, `let`, and `const`?
> 
> ---
> 
> ### **Advanced JavaScript**
> 
> - Can you explain the event loop and how it handles asynchronous tasks?
> - What are micro and macro tasks, and how are they prioritized in the event loop?
> - What is the difference between a `Set` and a `Map` in JavaScript?
> - How does the `Promise.all` method work, and what are its alternatives?
> - What is the temporal dead zone?
> 
> ---
> 
> ### **React Advanced Concepts**
> 
> - What is the difference between the virtual DOM and the shadow DOM?
> - What is the role of an error boundary in React?
> - How do `useEffect` and `useLayoutEffect` differ?
> - What is prop drilling, and how can it be avoided?
> - How do React Profiler and Strict Mode help in debugging?
> 
> ---
> 
> ### **Next.js**
> 
> - How does Next.js implement dynamic routing?
> - How can you configure caching in a Next.js application?
> - What is the difference between server-side rendering in Next.js and traditional SSR?
> - How does Next.js improve SEO compared to React?
> - What are the challenges of deploying Next.js apps on platforms like Vercel?
> 
> ---
> 
> ### **What is a Virtualized List?**
> 
> A **virtualized list** is a performance optimization technique used to render only the visible items of a large list or table instead of rendering all the items at once. This approach is particularly useful when dealing with datasets that contain hundreds or thousands of elements, as rendering all of them at once can be computationally expensive and slow down the browser.
> 
> Virtualization dynamically calculates which items should be visible based on the scroll position and only renders those items, improving memory usage and performance.
> 
> ---
> 
> ### **What is Windowing?**
> 
> **Windowing** is the specific implementation of virtualization where the "window" refers to the subset of the list items currently visible in the viewport (or slightly beyond it for smooth scrolling). The concept ensures that:
> 
> 1. Only the items within this "window" are rendered.
> 2. Items outside this "window" are removed from the DOM or kept in an optimized state.
> 
> This technique minimizes DOM updates and reduces the workload on the browser, leading to faster rendering and scrolling.
> 
> ---
> 
> - How do you approach A/B Testing with multiple variants ?

> [!note]+ ## Islands Architecture
> > architecture encourages small, focused chunks of interactivity within server-rendered web pages. The output of islands is progressively enhanced HTML, with more specificity around how the enhancement occurs. Rather than a single application being in control of full-page rendering, there are multiple entry points. The script for these “islands” of interactivity can be delivered and hydrated independently, allowing the rest of the page to be just static HTML.
> 

> [!note]+ ## **Progressive Hydration Implementation**
> solves this problem by allowing us to hydrate only certain parts of the application when the page loads. The other parts are hydrated progressively as required.
> 

> [!note]+ # Design Patterns
> ## Observer Pattern
> 
> we can *subscribe* certain objects, the **observers**, to another object, called the **observable**. Whenever an event occurs, the observable notifies all its observers
> 
> 


> [!note]+ ## Tree Shaking
> is aimed at removing code that will never be used from a final JavaScript bundle. When done right, it can reduce the size of your JavaScript bundles and lower download, parse and (in some cases) execution time. For most modern JavaScript apps that use a module bundler (like webpack or Rollup), your bundler is what you would expect to automatically remove dead code. ⁣⁣ ⁣⁣
