---
notion-id: a47b6619-f753-4c3a-8635-88891564e128
base: "[[Solid Principles.base]]"
Principle: Dependency Inversion Principle
---
