---
notion-id: 49dba16c-3f8b-4e82-97ad-6cb3fe2fba4b
base: "[[Solid Principles.base]]"
Principle: Single Responsibility Principle
---
