---
notion-id: 7b4de0e8-3d87-44ce-9bab-b80bfb2941c3
base: "[[Solid Principles.base]]"
Principle: Open-Closed Principle
---
