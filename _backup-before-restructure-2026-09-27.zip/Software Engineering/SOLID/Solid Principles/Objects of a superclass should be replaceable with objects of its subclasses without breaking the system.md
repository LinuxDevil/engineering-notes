---
notion-id: b36837dd-10ee-4e0a-a4be-b74db0b40202
base: "[[Solid Principles.base]]"
Principle: Liskov Substitution Principle
---
