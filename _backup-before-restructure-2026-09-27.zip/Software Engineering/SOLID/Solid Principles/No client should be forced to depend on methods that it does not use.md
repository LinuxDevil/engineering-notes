---
notion-id: 6c92a293-e2e1-4357-9564-53b16660cc3b
base: "[[Solid Principles.base]]"
Principle: Interface Segregation Principle
---
