---
notion-id: bf7ee473-b353-4c24-80e6-df04680f92f3
cover: "[[Database Round.jpeg]]"
---
[[ACID Overview]]

[[Transactions & ACID]]

[[Database internals]]

[[Row Vs Column Oriented Databases]]

[[Database Pages]]

[[CAP Theorem]]

[[Sharding & Partitioning]]

[[Indexes]]

[[Overview]]

[[Overview]]

[[Clustering and Scaling]]

[[Replication & 2PC 3PC]]

[[Database Backup]]

[[Don’t Use Offset, Use limit and an index with it]]

[[Connection Pooling]]

**ACID**
	1. Introduction to ACID (Atomicity, Consistency, Isolation, Durability)
	2. Importance of ACID in transactions
	3. Practical examples for each ACID property
	4. Drawbacks of ACID

**Transaction Boundaries**
	1. Definition of transaction boundaries
	2. How to define a transaction boundary in a database
	3. Impact of transaction boundaries on performance and concurrency
	4. Examples of transaction boundaries in different DBMS

**Isolation Levels**
	1. Definition of isolation levels in DBMS
	2. Different isolation levels (Read uncommitted, read committed, repeatable read, serializable)
	3. Pros and cons of each level
	4. How isolation level can impact the ACID properties

**How Locks Work on Transactions**
	1. Understanding the basic concept of locking
	2. Shared locks vs Exclusive locks
	3. Deadlocks: definition, prevention, and detection
	4. Optimistic locking vs Pessimistic locking

**CAP Theorem**
	1. Introduction to CAP Theorem (Consistency, Availability, Partition tolerance)
	2. Explanation of each property
	3. Examples of systems that favor each property
	4. Understanding the trade-off in the CAP theorem

**Distributed Transaction**
	1. Understanding distributed transactions
	2. Problems and solutions in distributed transactions
	3. The role of ACID and CAP theorem in distributed transactions
	4. Introduction to two-phase commit protocol (2PC)

**2PC (Two-Phase Commit)**
	1. Explanation of the two-phase commit protocol
	2. Coordinator and participant roles
	3. The phases: vote phase and commit phase
	4. Benefits and drawbacks of 2PC

**SQL**
	1. Basic SQL commands (SELECT, INSERT, UPDATE, DELETE)
	2. Understanding joins, subqueries, and indexes
	3. Writing stored procedures and functions
	4. SQL best practices and optimization techniques


---

**Database Management**
	1. Overview of DBMS
	2. Database design principles (Normalization, denormalization)
	3. Performance tuning and query optimization
	4. Security considerations

**Scaling**
	1. Definition of scaling (Vertical scaling, Horizontal scaling)
	2. Understanding when to scale
	3. Scaling strategies and their trade-offs
	4. Impact of scaling on system design

**Cluster**
	1. Definition of a cluster in DBMS
	2. Types of clusters (Fail-over, load-balancing, distributed)
	3. Role of clusters in high availability and scalability
	4. Examples of clustering in different DBMS

**Replication and Its Types**
	1. Understanding the concept of replication
	2. Types of replication (Master-slave, multi-master, peer-to-peer)
	3. Understanding replication lag
	4. Replication strategies in different DBMS

**Database Procedures (Backup, Recovery, Migration, etc)**
	1. Importance of backup and recovery
	2. Backup strategies (Full, incremental, differential)
	3. Disaster recovery planning
	4. Understanding database migration and its challenges

**How to Perform Bulk Operations**
	1. Bulk Insert: How to insert multiple rows in a single query
	2. Bulk Update: How to update multiple rows in a single query
	3. Bulk Delete: How to delete multiple rows in a single query
	4. Understanding performance considerations with bulk operations

