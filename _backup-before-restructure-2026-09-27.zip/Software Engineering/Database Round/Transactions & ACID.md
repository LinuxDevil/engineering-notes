---
notion-id: 4c83227b-2e86-4fab-9426-b3753b1b656d
cover: "[[Transactions & ACID.jpeg]]"
---

## **Concepts**

**Note**: <u>*You must always have a bounded query (the where clause)*</u>

### **Buffer Pool**

To effectively manage data movement between disk and main memory it saves data pages in memory for faster data reads (querying).

Buffer management operates at a lower level in the DBMS, managing the movement of data pages between disk and main memory. It is a fundamental mechanism to ensure data is efficiently read from and written to the disk when needed.

### Vacuum

Is the operation that removes old tuples that are not visible by anyone, no body is needing it. freeing up space in the page.

If you have a page(s) that has a lot of dead tuples, it will mark all the rows as deleted, but still lives in the disk (It will not be reclaimed)

Vacuum Full, removes from the disk (Physically remove them) reclaiming space, renaming pages so cleaning from 0 and move data around.

### **Cache**

It focus on storing the frequently accessed data, it Operates on the data in the Buffer pool.

Caching involves keeping a copy of data in RAM after it has been read from the disk.

Caching operates at a higher level in the DBMS, dealing with data that has already been fetched from the disk and stored in the buffer pool. The cached data is available for quick retrieval if the same data is requested again, reducing the need for repeated disk access.

### **MVCC **(Multi-Version Concurrency Control) 

A technique in DBMS used to avoid conflicts between simultaneous transactions allowing the users to access the DB without interfering with each other. It keeps multiple versions of each data item, so when a transaction wants to read a record, it sees the most recent version that was committed before the transaction started, and when a transaction wants to update a record, it creates a new version of that record, other transactions will see the old version until the new version is committed. 

However, there can be performance costs, especially if there are frequent updates or if transactions are long-lived, as each version of each updated record has to be stored and managed. Additionally, the database may need to periodically clean up old versions of records that are no longer needed, a process known as vacuuming or garbage collection.

Databases that supports it: *PostgreSQL, MySQL with InnoDB, Oracle, SQLite, SQL Server with Snapshot Isolation or Committed Snapshot isolation* [They will read the original table]

Database that don’t support it: *MySQL with MyISAM engine, SQL Server (Default)* (They keep a table that call undo where all the previous values) [They will read from undo table]

---

## Transaction

**A Transaction** is a Single Indivisible Logical Unit that consists of multiple operations that appears as a single instruction to the user.

### **Transaction Boundaries**

Where the transaction BEGIN, COMMIT and ROLLBACK.

### Transaction Locks

Postgres stores lock information inside the row as another field, this columns lives in the heap.

When a row is released, postgres will refresh its value in any pending transaction that is either a or above read committed isolation.

**Deadlocks**: Things that happen when two transactions block each other by holding a lock on a resource which another transactions are trying to lock.

**Locking** is the mechanism of preventing data inconsistency that occur when multiple transactions attempt to modify or read shared data concurrently.

**There are 2 Main types of locks:**
	1. Shared Lock (Read Lock)
When you want to read a value, i want to make sure that no one is changing that, if anybody does make it fail
This lock is requested when a transaction wants to read data, multiple shared locks can exists on the same data item, as long as there is no exclusive lock.
	2. Exclusive Lock (Write Lock)
This lock is requested when a transaction wants to modify data. Only one exclusive lock and be found with no shared locks.
When you want to read a data, when you rtead this value or update it no body is connecting or can read it or do anything with it really

**Two phase lock** (2PL) (Around Serializability)

It came to solve the problem of double booking, when 2 users begin a transaction and update the same row and commit, the last commit wins, this is called double booking. 

To implement it in the DB Level, you need to obtain an exclusive lock on that row

```sql
// In postgres we can't have a timeout, but in oracle there is a time out for the FOR UPDATE row level execlusive lock
SELECT * FROM Seats WHERE ID = 14 FOR UPDATE; // Growing Phase
// If any other transaction wants to do anything else, the can't they will be waiting
UPDATE Seats SET isbooked = 1, name = 'Ali' WHERE ID = 14;
COMMIT; // Shrinking Phase, now everyone can read it.
```

    The process of getting and releasing a lock is usually follows two phases that ensures serializability in concurrent transactions. These phases must not overlap.
		1. Growing Phase
The transaction can obtain (get) locks, but can’t release any.
		2. Shrinking Phase
The transaction may release locks but can’t obtain any new ones.

**Ways of using Locks**:
> [!note]+ Explicit Locking
> A way of using Locks where the User is responsible for acquiring the lock and releasing it, it provides a finer control over the locking process but you need to manage everything.
> It is used to override the default transaction behavior for concurrency control.
> Types of Explicit Locking:
> 
> 1. Table Locks
> It is automatically acquired but you can explicitly get it by using the `LOCK` statement or `SELECT FOR UPDATE`, `SELECT FOR NO KEY UPDATE`, `SELECT FOR SHARE`, `SELECT FOR KEY SHARE`. 
> You can use it like this
> ```sql
> BEGIN;
> LOCK TABLE table_name IN lock_mode;
> -- CODE
> COMMIT;
> ```
>     Where the lock mode can be 
> ![[Screenshot_2023-07-23_at_3.25.01_PM.png]]
>     - Access Share (Default, Lowest Level)
> It acquires by normal `select` any query that only reads the table and doesn’t modify it will acquire that lock mode. If it was acquired and the transaction is still open, you can’t truncate, delete, vacuum full the table (Anything with Access exclusive).
>     - Row share
> It happens when you do `SELECT FOR UPDATE`, `SELECT FOR NO KEY UPDATE`, `SELECT FOR SHARE`, `SELECT FOR KEY SHARE` in addition to ACCES_SHARE locks
>     - Row exclusive
> This happens when you do any DML (`Update`, `Insert`, `Delete`, `Merge`) The table is marked as a row exclusive.
>     - Share update exclusive
> Acquired by `VACUUM` (Without Full), `Analyze`, `Create Index concurrently`, `Create statistics`, `comment on`, `reindex concurrently`
> This protects against **concurrent schema changes** and VACUUM runs.
>     - Share
> This mode protects a table against concurrent data changes (You can’t change that table)
> Acquired by `CREATE INDEX (without concurrently)`
>     - Share row exclusive
> This mode protects a table against concurrent data changes (You can’t change that table) but only one session can have it. 
> Acquired by `CRETE TRIGGER`, and some forms of `ALTER TABLE`
>     - Exclusive
> This mode allows only concurrent `ACCESS SHARE` locks, i.e., only reads from the table can proceed in parallel with a transaction holding this lock mode
> Acquired by `Refresh materialized view concurrently`
>     - Access Exclusive (Highest Level)
> This guarantees that the holder of this lock is the only one accessing the table in any way. This can be acquired by `VACUUM FULL`, `REINDEXING`, `CLUSTERING`, `TRUNCATING`.
> 2. Row-Level Locks
> You can acquire a Row lock using `SELECT FOR UPDATE`, `SELECT FOR NO KEY UPDATE`, `SELECT FOR SHARE`, `SELECT FOR KEY SHARE`. 
> Here, the select statement LOCKS the row it retrieves, ensuring no other transaction modifies these rows until the current transaction is committed or rolled back.
> 
> <u>Theres Four types of Row-Level locks:</u>
> **For Update:
> **You can only read the rows that is retrieved, but can’t do any DML. this mode is also acquired by DELETE also UPDATE on certain values that have unique index that can be used in foreign key.
> 
> **For No Key Update:
> **Behaves similarly to `FOR UPDATE`, except that the lock acquired is weaker: this lock will not block `SELECT FOR KEY SHARE` commands
> 
> **For Share
> **Behaves similarly to `FOR NO KEY UPDATE`, except that it acquires a shared lock rather than exclusive lock on each retrieved row. A shared lock blocks other transactions from performing `UPDATE`, `DELETE`, `SELECT FOR UPDATE` or `SELECT FOR NO KEY UPDATE` on these rows, but it does not prevent them from performing `SELECT FOR SHARE` or `SELECT FOR KEY SHARE`.
> 
> **For Key Share
> **Behaves similarly to `FOR SHARE`, except that the lock is weaker: `SELECT FOR UPDATE` is blocked, but not `SELECT FOR NO KEY UPDATE`. A key-shared lock blocks other transactions from performing `DELETE` or any `UPDATE` that changes the key values, but not other `UPDATE`, and neither does it prevent `SELECT FOR NO KEY UPDATE`, `SELECT FOR SHARE`, or `SELECT FOR KEY SHARE`.
> ![[Screenshot_2023-07-23_at_3.25.29_PM.png]]
> ```sql
> -- FOR UPDATE
> BEGIN;
> SELECT * FROM table_name WHERE <condition> FOR UPDATE;
> -- CODE
> COMMIT;
> ```
> 3. Page-Level Locks
> You can lock a certain page
> These are automatically managed by the system, it is used when modifying the structure of a table.
> 4. Advisory Locks (Application Lock)
> It is up to the application to use them correctly, It is a way of making application respect each other locks.
> It can be a Session level or a Transaction level
> You can acquire the advisory lock by using `pg_advisory_lock`, `pg_try_advisory_lock`, `pg_advisory_lock_shared` and `pg_try_advisory_lock_shared`. And you can release them by `pg_advisory_unlock` ,
> `pg_advisory_unlock_all` , `pg_advisory_unlock_shared` , `pg_advisory_unlock_shared_all` .
> ```sql
> BEGIN;
> SELECT pg_advisory_lock(<LOCK_KEY>);
> -- CODE
> COMMIT;
> ```
>     In the lock key. Any other transaction that tries to acquire an advisory lock with the same key will be blocked until the current transaction is committed or rolled back.

> [!note]+ Implicit Locking
> A way of using Locks where the system automatically manages locks and abstracting away the complexity from the end user.
> 
> Types:
> 
> 1. Row-Level locks
> PostgreSQL implicitly acquire a Row-Lock whenever the row us updated or deleted in the transaction, the lock is held until the end of the transaction.
> 2. Table-Level locks
> It depends on the command, for instance update or delete or truncate acquire ROW EXCLUSIVE lock which prevents other transaction from acquiring other locks
> 3. Page-Level locks
> Automatically acquired during table and index modification.
> 4. Tuple-Level Locks
> When a transaction updates a row, PostgreSQL acquire tuple-level lock on the version of the row produced by the update.
> 5. Shared and exclusive locks
> Shared automatically acquired for Read operations and Exclusive for write operations



### **Transaction Life-Cycle**

1. Begin Transaction 
When the DBMS receives the BEGIN/START TRANSACTION command
2. Read-Write Operations
After the transaction begins, it can perform read and write operations
3. Intermediate States
The transaction might enter a several intermediate states during execution like active, failed, partially committed
4. Commit or Rollback
After all operations are completed, the transaction tries to commit, signalling it want to persist the changes, if all checks pass (Integrity constraints) the DBMS changes the sate to committed and changes are saved. If not, the transaction is rolled back discarding all changes.
5. Post-Transaction cleanup
After the transaction is committed or aborted, the DBMS needs to cleanup, which includes releasing locks, cleaning up redo-undo logs, truncating the transaction log and updating the transaction state in the transaction management system.
6. Terminated
Finally, the transaction is marked as terminated.

### **Transaction States**

7. Active: The initial state, where the transaction is executing SQL commands
8. Partially committed: When a transaction executes its final statement, where the DB is still in the process of updating itself, if any issue happens here, the transaction can’t be rolled back.
9. Committed: When all the transaction statements have been executed successfully and the changes has been persisted.
10. Failed: If a transaction encounter any issue(error) while in the active state, the changes it has made to the database cannot be saved an must be rolled back.
11. Aborted: If a transaction has been rolledback from a failed state, or manually aborted from the active state. Here any changes that has been done to the DB is undone returning to the state before the transaction begin.
12. Terminated: Once a transaction has been committed or aborted and all post-transaction cleanup has been completed.

### Post-transaction cleanup

The process in the DB that reclaims resources and ensures data integrity after a transaction has either committed or aborted.

13. Undo Log and Redo Log Cleanup
	The DB maintains a log to help ensure data integrity, the undo log contains information to reverse changes if a transaction is aborted, while the redo log contains information to re-apply the changes if a transaction is committed but the DB crashes. 
Once a transaction is finished the Logs can be safely removed.
14. Lock Releases
	If the transaction uses Locks for concurrency control, the held locks must be released
15. Data file cleanup
If the DB uses (MVCC) like postgreSQL, it might need to clean old versions of records that no longer needed.
16. Memory cleanup
Freeing up the memory held by the transaction.
17. Transaction Log truncation
Transaction logs keep record of all changes made in the system
It frees unnecessary log entries from the transaction log
18. Update the transaction states
It update the state of the transaction in the transaction management system

### Properties of a transaction: **ACID** properties

- Atomicity → Refer to all or none, as if anything happen to the transaction it will fail as a whole or work as a whole.
- Isolation → The db actions to insure that no other statement interfere with our transaction.
	Read Phenomena (Problems)
		- Dirty Read (Not committed, Not flushed)
			- Dirty means it didn’t persist
		- Non-repeatable reads (You read same entry again, that changes values)
			- In the same transaction you read the same row twice but with different outcome in each
		- Phantom Reads (Something inserted a row that satisfies your query and read it)
			- Like range queries, when you query them then a new row was inserted but it satisfies ur range query, then when you do a new select you will read the new phantom new row.
		- Lost Updates (I wrote something, but before i commit i read what i wrote, but some other transactions can change what you wrote)
			-   This can be solved by locking

        Isolation Levels that solves Read phenomenas
            - Read uncommitted - No Isolation
            - Read committed - Default - Each query in a transaction sees committed changes by other transactions.
            - Repeatable Read (In Postgre it is a snapshot)- To fix the repeatable read - The transaction will make sure that when a query read the row, the row will remain unchanged while its running.
            - Snapshot - Each query in a transaction only sees changes that have been committed up to the start of the transaction (Like a snapshot of the DB at that moment).
            - Serializable - No Concurrency (Almost running in parallel) It serialize things 

        Implementation of Isolation
            - Pessimistic - Row level locks, table locks, page locks to avoid lost updates.
            - Optimistic - No locks, just track if things changed and fail the transaction if it did.
            - Repeatable read locks the rows it reads, but it is expensive if you read a lot of rows. Postgre implement RR as a snapshot.
            - Serializable are usually implemented with optimistic concurrency control, you can implement with pessimistically with **SELECT FOR UPDATE.**

- Durability → Transactions must persist across crashes.
	 The system is durable only when the commit is successful( the data is fully written to disk)
		The process of persisting the writes that happen to a durable non-volatile storage system [Like SSD/DISK](Anything we write is persists even if the power was lost).
		Durability Techniques:
			- WAL - Write ahead log (Any changes goes to Disk, We didn’t update the table yet but it is persisted in the Disk on a wal entries) like Redis.
				- DBMS persists a compressed version of the changes known as Write-ahead-log segments because writing a lot of data to disk is expensive. (It tells us what to change).
			- Asynchronous Snapshot (Keep them in memory, but in the background we persist everything to disk) like Redis
			- Append Only File (AOF) Similar to WAL, Keeps track then writes it to Disk.
		OS Cache
			- A write request in OS usually goes to the OS Cache (In memory Cache As it wants to patch them to do less IO) So when the writes go to the OS cache, it could lead to loss of data, So `Fsync` OS command forces write to always go to disk (<u>To pypass the OS cache</u>) But it is expensive and slow. 
Not similar to `Fdatasync` which doesn’t flush the metadata about the buffer cache page with it unless it is necessary 
[https://man7.org/linux/man-pages/man2/fsync.2.html](https://man7.org/linux/man-pages/man2/fsync.2.html)
- Consistency → When you start and end a transaction it must preserve the consistency of the DB.
Types of Consistency: 
	1. Consistency in data (The state of data)  - Table In a DB Instance
		- Defined by the User
		- It comes down to referential integrity (foreign keys)
		- Atomicity will lead to consistency in data.
		- Isolation also leads to consistency in data.
	2. Consistency in Read (Multi-Instance reads) - System as a whole
		- When you Update X The Database now persists X So when you read X you will get it.
    Eventually Consistent 
        Both relation and NoSQL database suffer from this when we want to scale horizontally or introduce caching.
        When ever your data is in two places, you are Eventually Consistent.
        When ever you introduce a cache, you are Eventually Consistent.
        Eventually Consistent means that when you update a value and then read it, it will give you the old one but eventually will get updated, like for example if we have a main node (master) and we update the value there then we access the value in one of the follower nodes (Slaves) we will get the old value, and eventually the main (master) node will start pushing the update to make the worker nodes consistent.
     