---
notion-id: 2aceb8b2-26a3-48dc-b9f0-6f221d888d67
cover: "[[Replication & 2PC 3PC.png]]"
---

## Replication (When you do it, it is called a cluster)

Sharing information to insure consistency between redundant database instances

Keeping a multiple copies of DB
Strategy that involves sharing information between duplicate database instances.


Why We need replication?

1. Availability
2. Latency
3. Scalability 

We can make some set of replicas only for reads and some only for writes.

We can load balance the replicas.

There’s 3 Types of Replication

4. Master-Slave (Active/Passive)(Master/Backup) (Leader Based)
This also is called one way replication
One leader that accepts writes/ddls
One or more backups/salves nodes that receives those write from the master ( The master replicates the data to the slaves ).
You can read from the replica or from the master.

This model one of the database servers (The master) accepts the <u>write</u> operations  and distribute the changes to one or more slaves, the read operation can be distributed between the replicas (Slaves) to increase system throughput.
If the master failed, one of the slave servers can be <u>promoted</u> to master via voting.
This will introduce a <u>single point of failure</u>.
![[Screenshot_2023-07-29_at_3.54.08_PM.png]]
![[Screenshot_2023-07-29_at_3.55.51_PM.png]]

5. Master-Master (Multi-Master)
You scale the writes, here we have multiple leader(master) nodes that accepts writes/ddls
One ore more followers(slaves) nodes that recieves those writes from the master.

Here you MUST RESOLVE CONFLICTS (2PC, 3PC)

In this model, two or more database server act as the master, and accepts write operations, changes made to one master node is transferred to the other master node(s).
In this model, every master is responsible for a different section of the database but hold the whole database.
6. Peer-Peer
In this model all nodes are equal, where all nodes can accepts write operations, changes made on one needs to be transferred to all other nodes.

Replication Strategies 

7. Synchronous Replication
When you issue a write to the master node the client has to wait until the transaction is written for the master, then to wait for the child replicas before you are unblocked (Cassandra corum)
You have the options to wait for the first 1 or 2 or Any in postgres based on the priority of the replicas.

This model in-forces <u>strong consistency</u> as the changes made to the master node will <u>not be marked complete</u> until the data has been copied/transferred to other database nodes.
The data is immediately copied to the slave database, and the transaction will be marked as successful after the slave db saves them successfully.
This will impact performance as we need to wait for the replicas to get the new data.

8. Asynchronous Replication
This model is <u>Eventual Consistence</u>, as the changes made to the master node are <u>marked as complete</u> and then they are copied/transferred to the replicas in the background.
If the primary database failed for some reason, changes can be lost.

You have puppet patches that do work to update.
9. Semi-Synchronous Replication
This model is <u>Eventual Consistence</u>, changes that are made to the master node is<u> not market complete</u> until they are written to the master’s transaction log and at least one replica (slave) transaction log.


To do replication

First spin up the master then the replicas, then copy the entire the data from the master to the replicas

To create the master




```sql
docker run --name pmaster -p 5432:5432 -e POSTGRES_PASSWORD=postgres -v /Volumes/AloushSSD/_Fundementals\ of\ DB/replication/pmaster_data:/var/lib/postgresql/data -d  postgres
```

To create the replica

```sql
docker run --name preplica -p 5433:5432 -e POSTGRES_PASSWORD=postgres -v /Volumes/AloushSSD/_Fundementals\ of\ DB/replication/preplica_data:/var/lib/postgresql/data -d  postgres
```

Then stop the docker containers

Then copy the files

```sql
mv preplica_data preplica_data_backup
cp -R pmaster_data preplica_data_backup
```

Start it up

Then go to the master to update the config

```sql
vim pg_hba.conf
```

add at the end of file

```sql
host replication postgres all md5
```

Go to your replica file and vim postgres.config then

```sql
primary_conninfo = 'application_name=standby1 host=host.docker.internals port=5432 user=postgres password=postgres'                     # connection string to sending server
```

then create a file 

```sql
touch standby.signal
```

Then go to your master data file

```sql
vim postgres.config
```

and 

```sql
synchronous_standby_names = 'first 1 (standby1)'        # standby servers that provide sync rep
```



### Master Slave Replication (Active/Passive Replication) (Leader Based Replication)

![[Screenshot_2023-07-24_at_2.16.59_PM.png]]

The DB Master will replicate the changes to the Sub replicas (Slaves).

If the requests can be <u>overwhelmed</u>, so what can we do is only make the write requests goes to the master  and for the read request will go to the replicas (Slaves).

![[Screenshot_2023-07-24_at_2.23.47_PM.png]]

If the master goes down, one of the replicas(Slaves) will replace the master and become the master via voting.

### Two-Phase Commits

Its a Atomic commitment protocol (ACP) that is used in distributed systems that insures a transaction either commits all or aborts at all nodes.

It is a blocking protocol, if the coordinator fails before sending commit or abort, the participants will be left waiting.

Phases:

10. Prepare Phase
The coordinator first execute its local transaction, then it sends a prepare message to all participants node, the participant nodes then execute the transaction up to a point of commit and <u>hold</u> a lock on the resources the accessed during the transaction, Once prepared, the participant node respond to the coordinator with “Yes” i can commit or “No” i can’t commit, hence i abort. 
11. Commit Phase
If all participants respond with a “Yes” vote, the coordinator sends a “commit” message to all nodes, if any participant respond with a “No” vote, the coordinator sends an “Abort” message to all nodes.


Without the 2 Phase Commits, Automicity of the requests might be in danger, like for example if you are ordering Burger from Careem, and the first request to the shop was successful but the request for assigning a driver is not, we will prepare the food with no driver to drive our beloved burger to us, or even if it was the other way around. Thus the 2 Phase commit comes to the rescue.

![[Screenshot_2023-07-24_at_2.34.47_PM.png]]

Now we need to guarantee the two steps are done.

The 2 Phase commit, split the flow into 2 Phases where the prepare phase is to reserve and the commit phase is to book.

![[Screenshot_2023-07-24_at_2.36.35_PM.png]]

 If both fails, the transaction fails, if one succeeds, we cancel the reservation and abort the transaction.

![[Screenshot_2023-07-24_at_2.44.10_PM.png]]

![[Screenshot_2023-07-24_at_2.44.21_PM.png]]

Advantages: 

- Guarantees ATOMIC transactions
- Guarantees Isolations

Disadvantages:

- Slow
- Prone to deadlock


### Three-Phase Commit

This ACP (Atomic Commitment Protocol) is more fault-tolerant of the 2PC protocol, it introduce extra phase to handle coordinator failures gracefully. 

This is none-blocking protocol, as if the coordinator fails, the participant nodes are left to decide weather to commit or abort the transaction 

Phases: 

12. Can-Commit Phase
The coordinator sends a “Can-Commit?” Message to all participants nodes, asking them if they are able to commit. The nodes reply either with a Yes or No.
13. Pre-Commit Phase
If all participants responded with a “Yes”, the coordinator sends a “Pre-Commit” message making all the nodes execute the transaction and write the undo and redo logs to <u>disk</u> then the nodes will respond with an Acknowledgment to the coordinator.
If any node sends “No” it will send an “Abort” message.
14. Do-Commit Phase
On recieving the “Acknowledgement” from all the participant nodes, the coordinator sends a “Do-Commit” message. The participants then commit the transaction and release all resources held, cleaning the undo log and send an “Acknowledged” Message to the coordinator.