---
notion-id: b2569de8-65dd-4ff0-8c78-eda40cae945c
cover: "[[Sharding & Partitioning.jpeg]]"
---
*Sharding works on a Database Level*

*Partitioning works on a table level*

## Sharding (Horizontal Scaling Strategy)

The process of segmenting the data into partitions that is spread into multiple servers

You split the table (row based) into multiple databases across multiple servers on a` Shard-Key` .

![[Screenshot_2023-07-28_at_3.12.57_PM.png]]

In case of strings, we need consist hashing.

Consistent Hashing

You take an input and figure out what database instance it lives on based on the input hash value.



Is the process of storing large database into multiple machines.

It enables parallel processing pf shards to overcome the slow bottle neck problems

A logical shard is the chunk of data that is stored in the DB node

DB Node is called a physical shard.

Shard key: Is the key that determine how to shard “Group” data.

It works on shard-nothing architecture, as each node doesn’t know of any other shard node. and that is called a hash ring.

Cassandra uses this hash ring.

Difference between HP and Sharding

![[Screenshot_2023-07-28_at_3.18.38_PM.png]]

### Method of sharding:

1. Range based (Dynamic)
Splits rows based on a range of values
2. Hashed
It assigns a shard-key to each row of the DB table by using a hash function, the application then uses the hash function value as a shard-key to store the info in the correct physical shard.
3. Directory Sharding
It uses a lookup table that stores column-shard key, the app then references to this table to insert data.
4. Geo Sharding
The DB splits data in different GEO location, it can use “City” as a shard key for example

Pros in sharding: 
	1. Scale
	2. Security (Users can access certrain shards)
	3. Optimal and Smaller index size

<u>The last thing you want to do is hard your DB.</u> Please ask the questions to begin then decide.

Only Do sharding when the DB can’t handle the connection amount anymore

Cons Of Sharding

![[Screenshot_2023-07-28_at_7.11.22_PM.png]]

## Partitioning 

Is the process of breaking One large table into multiple tables in the same DB and let the DB decide which partition to hit depending on the `where` clause.

With partitioning we have smaller files which leads to faster queries, Smaller indexes can fit into memory.

Anything that you want to partition against must be not null

### Partitioning Ways/Strategies 

Horizontal Partitioning
    Splitting rows into partitions
    Can be range or list

Vertical partitioning
    Splitting the columns into partitions
    Can be used for blob or large column that you can store in a slow access drive in its own table space


### Partitioning Types

5. List of values (Like order status) 
One down side is that you have to constantly move data between partitions
Discrete values like cities or zip codes
6. Range
Dates, ids ..etc
7. Hash of a key
Hash functions (Consistent hashing)

Creating Partitions

```sql
create table grades_org (
    id serial NOT NULL,
    g integer not null
);

INSERT INTO grades_org(g) 
SELECT floor(random()*100) 
from generate_series(0, 10000000);

CREATE INDEX grades_org_index on grades_org(g);

EXPLAIN ANALYZE
SELECT count(*) from grades_org 
where g between 35 and 40;

-- MAKE SURE THE ENABLE PARTITION PRUNING IS ON
SET enaable_partition_pruning on;

-- Create the original table and specify how you want to partition it
CREATE TABLE grades_parts (
id serial not null,
 g integer not null) 
partition by range(g);
-- Create the partitions
CREATE TABLE g0035 
(LIKE grades_parts including indexes);
CREATE TABLE g3560 
(LIKE grades_parts including indexes);
CREATE TABLE g6080 
(LIKE grades_parts including indexes);
CREATE TABLE g80100 
(LIKE grades_parts including indexes);
-- Attach the partitions to the main tables
ALTER TABLE grades_parts ATTACH
 PARTITION g0035 for values from (0) to (35);

ALTER TABLE grades_parts ATTACH
 PARTITION g3560 for values from (35) to (60);

ALTER TABLE grades_parts ATTACH
 PARTITION g6080 for values from (60) to ( 80);

ALTER TABLE grades_parts ATTACH
 PARTITION g80100 for values from (80) to (100);
-- Copy the old data, the DB will decide which partition it will go into
INSERT INTO grades_parts SELECT * FROM grades_org;
-- VERIFY
SELECT COUNT(*) from grades_parts;
SELECT MAX(g) FROM grades_parts;
-- CREATING INDEX, BEFORE Postgres11 we needed to create for each partition now nope
-- This will create an index on all partitions
CREATE INDEX grades_parts_idx ON grades_parts(g);
-- VERIFY
EXPLAIN ANALYZE SELECT COUNT(*)
 from grades_parts WHERE g = 30;
EXPLAIN ANALYZE SELECT MAX(g) FROM grades_parts;

-- Check the relation size
SELECT pg_relation_size(oid), 
relname from pg_class 
order by pg_relation_size(oid) DESC;
```

### Partitioning vs Sharding

Partitioning splits big table into multiple tables in the same database, the client doesn’t know

Sharding splits big table into multiple table across multiple servers 

Partitioned table changes name (or schema)

Sharding everything stay the same but in different server

![[Screenshot_2023-07-27_at_11.23.15_PM.png]]

![[Screenshot_2023-07-27_at_11.23.24_PM.png]]
