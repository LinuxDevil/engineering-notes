---
notion-id: 0b19bedf-ee26-488b-a5ae-df5e999a62d1
---
A pattern of creating a pool of connections (Usually TCP connection) and allow multiple clients to share this pool of connections.

The old way was with every request, you open a connection to the database, query the result and close it. This is very expensive to do.

So the good way of doing it, you will create a pool, not a client and connect once. specify a max connection like 20.

When you execute a query, it will pick one of the 20 pools connections and execute it.

Add a connectionTimeoutMillis, how much should i wait until one of the pools is empty

idleTimeoutMillis, when to git rid of the old connections