---
notion-id: 26de4e60-9146-44d4-9590-c5e049783284
cover: "[[CAP Theorem.png]]"
---
CAP theorem is mostly about writes, and mostly in NoSQL.

CAP stands for
    Consistency
    Availability
    Partition Tolerance 

→ If you want to favor consistency, all nodes see the same data

→ If you want to favor availability, all nodes are able to write, so they won’t see the same data.

→ In conflict resolution, we have 2 ways to apply the data
	- What majority of the nodes have will be applied.
	- Depending on the timestamp of the writes.

**Consistency**

The term consistency can mean different things depending on context. In this chapter, it refers to "linearizability" or "atomic consistency" which is a specific model of consistency in distributed systems.

- Linearizability: This means that each operation appears to happen atomically, in a single instant. But the catch is, this "instant" must be between the time the operation was requested and the time its response was received.

**CAP Theorem**

The CAP theorem, introduced by Eric Brewer, postulates that it is impossible for a distributed data store to simultaneously provide more than two out of the following three guarantees: Consistency, Availability, and Partition tolerance.

- Consistency: (As per CAP) Every read receives the most recent write or an error.
- Availability: Every request receives a (non-error) response, without the guarantee that it contains the most recent write.
- Partition tolerance: The system continues to operate despite an arbitrary number of network failures.

In reality, most distributed systems are network partitioned due to failures and hence cannot compromise on Partition tolerance. Therefore, the choice often boils down to trading off between Consistency and Availability.

**Consistency versus latency**

There's a detailed discussion about the trade-off between consistency and latency. For example, in a distributed system, in order to provide consistent data, you might need to wait for a response from several nodes, which increases latency.

**Eventual consistency and causal consistency**

In this part of the chapter, Kleppmann talks about eventual consistency and causal consistency.

- Eventual consistency is a model allowing for some delay (from milliseconds to hours) during which reads might not reflect all writes.
- Causal consistency is a compromise model between linearizability and eventual consistency which captures the notion that if operation A causally precedes operation B, then everyone must observe operation A before operation B.

**Solutions for achieving consistency**

Lastly, the chapter discusses some practical solutions and algorithms for achieving consistency such as read repair, anti-entropy, Merkle Trees, vector clocks, and version vectors.