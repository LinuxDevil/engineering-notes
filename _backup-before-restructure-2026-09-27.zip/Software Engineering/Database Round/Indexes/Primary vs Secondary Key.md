---
notion-id: e2e37bd4-ebef-4660-a152-326a8582ac66
cover: "[[Primary vs Secondary Key.jpeg]]"
---

When we add a primary key to that table we introduce clustering

**Clustering (Index Organized Table IOT/ Clustered Index)** is organizing the table around the added key.

(Heap Organized Table HOT) When the heap organize the table (random) theres no index that organize the table.

Like if you inserted a value of 1 that is primary key and then 8 it will go below it, but if you insert now 2 it will need to sit between 1 and 8 (They don’t put them in the same page).

So if you executed a range query, it almost like a 1 IO, because they are stored together.

In Postgres All Indexes are secondary not primary, can you create a clustered index ?

But in case of secondary key, that is a separate Data structure, no order in that table but ordered in that separate Data structure, so if you execute a query, you will need to go to the index data structure to collect the pages/tuples you want to query then you need to go to the heap (Jump)

