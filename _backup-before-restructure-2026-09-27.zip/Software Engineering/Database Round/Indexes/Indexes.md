---
notion-id: 04623d22-eef4-46e4-bfb8-90f06e89193e
cover: "[[Indexes.jpeg]]"
---
Indexes are used to logically sort data in order to speed lookups/Searches


You can create an index on one or more columns to keep a sorted list to your own usage

When you create an index on a field, it creates another Data structure that contains that field value as well as a <u>pointer</u> to that record/field to which it relates to. Then this index is stored making Binary Search possible.

### Indexes is either a B-Tree or a Hash Table

B-Tree is having a Tree regular one

B-Tree+ is having the leaf nodes points to each other

### Indexes in PostgreSQL is by default a secondary index

[[Primary vs Secondary Key]]

### Types of indexes

- Clustered (Index organized table)
Creates a Physical order of rows around that index, When you create a PK you create a cluster index
- Non-Clustered
Doesn’t create a physical order, the leaf will contain PK if it exist
- Unique
An index that assures the uniquness of the index value, when you create a unique constraint, you create a unique index
- Partitioned
When you create a none partitioned index on a partioned table, it creates a Single Object index that points to all rows in a table space
- Composite
Two or more indexes together 
- Bi-Directional
Allows scanning on both sides, the default when you create an index is ASC order scanning
- Expression Based 
You can create an index that contains an expression, like you can create and index and add lower function to make it case insensitive.

*Without an index, tables will have to do a *<u>*Full-Table Scan*</u>*.*

### Scan Types

- Sequence Scan
We read all the pages (Heap) until we find the page that we want
- Index Scan
It will find the exact B-Tree node page and get the key or row_id from it, then it pulls the pointed page from the heap and read it.
Fetch from B-Tree → Fetch From Heap …etc
This will cause a random page access and random I/O
- Bitmap Search (BitMap Heap Scan)
The bitmap heap scan will ask for a tuple from the BitMap Index Scan
The BitMap Index scan works an index scan but instead of returning the TID(Page No, Offset) corresponding to the heap page data, it will append it to the bitmap (Tuple hash of all pages) Then the Bitmap scan reads the BitMap to get the heap data to stored pages and check for visibility and qualification.


An index is a data structure that you build and assign to your table that will act as a shortcut to lookups. Indexes are used to logically sort data in order to speed lookups/Searches

Every primary key has a B-Tree index by default

There are <u>two types</u>

**B-Tree. (Balanced/Broad/Bayer Tree)**

There are 3 Values that get stored in the node of the B-Tree, the index and the tuple id (TID/RID) and the pointer to the child element

![[Screenshot_2023-07-27_at_3.39.51_PM.png]]

![[Screenshot_2023-07-27_at_3.38.41_PM.png]]

![[Screenshot_2023-07-27_at_3.45.12_PM.png]]

It is a self balancing sorted tree structure that maintains sorted data. It optimize for individual read and write operations.

It minimizes disk I/O operations.

Most databases use B-Tree+ not regular B-Tree

![[Screenshot_2023-07-27_at_3.51.36_PM.png]]

![[Screenshot_2023-07-27_at_3.53.53_PM.png]]

![[Screenshot_2023-07-27_at_3.58.05_PM.png]]

![[Screenshot_2023-07-27_at_4.01.14_PM.png]]

![[Screenshot_2023-07-27_at_4.01.27_PM.png]]


**LSM Tree (Log-Structured Merge-Tree)**

A disk based data structure for optimizing heavy write-workloads, unlike B-Tree which optimize for individual read and write operations, LSM tree aggregate and buffer many write operations in memory before flushing them to the disk in large sequential I/O operation.

Because it buffers/patches write operations it is slower than B-Tree in read operations, but faster for intensive write-workloads.

When the data is inserted it puts it in memory (memtable), Once the memtable reaches it limit, it is flushed to disk as Sorted String Table (SSTable) which is a sorted log of key-value pairs, SSTables are periodically merged to consolidate overlapping entries and remove deleted ones. 

Key, vs non-key column indexes

```sql
CREATE INDEX id_idx ON students(id) 
			 INCLUDE (name);

-- id here is a key column index (For searching)
-- name is none-key column (What will be fetched)
```

None-key is abilities, when you create an index and you include another columns in the index but include other columns not to search for but to include.

Index Scan vs Index only scan

<u>**Index scan**</u> when the database needs to go to the heap to fetch other columns not included in the index

<u>**Index**</u><u> </u><u>**only scan**</u> when your query can be fetched from the index 

When you create an composite index

```sql
CREATE INDEX students(g, name)
```

And you query only for the left side of the composite, the database will use the index unlike when you query for the right side.

You can use with `AND` but you can’t use it with `OR` operations.

Bloom Filters 

Cassandra uses this in consistent hashing.

IS a probabilistic data structure used to test if an element is in a set, it  has certain probability or returning false values (Indicating an element is in the set when it is not) but it guarantees no false negatives (If it says an item is not in the set it is not).

When an element is added to the bloom filter it is hashed which generate an index position in a bit array

The bit array at these positions are set to 1

To check if an element is in the array, the element is hashed and the bit values that generated index positions are checked, if all bits are 1 the bloom filter returns it is in the set, if any bit is not 1 the element is not in the set.

![[Screenshot_2023-07-27_at_1.21.23_PM.png]]

![[Screenshot_2023-07-27_at_1.23.32_PM.png]]

![[Screenshot_2023-07-27_at_1.24.14_PM.png]]
