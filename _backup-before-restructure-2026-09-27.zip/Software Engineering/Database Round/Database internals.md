---
notion-id: 8d27c20c-595c-4d6d-a6cf-76e25f6000a5
cover: "[[Database internals.jpeg]]"
---

Always use <u>EXPLAIN ANALYZE</u> with <u>**Buffers**</u>

`Explain` provides the query plan but doesn’t execute the query

`ANALYZE` executes the query and provide statistics

`Buffers` provides information about how many blocks where hit in the buffer pool or read into from the underlying cache or disk.

Tuple is the physical version of the row in the system, when you change data PostgreSQL add a new version of the row, the tuple. 

When you execute a `DELETE` operation, <u>it doesn’t immediately free disk space</u>, instead it marks the tuple as dead, but stays around until a `VACUUM` deletes it. If a large number of dead tuples got deleted by a VACUUM this will result in index and table <u>bloating</u>.

When you `UPDATE` a row in PostgreSQL, it doesn’t modify the existing tuple, instead <u>it creates a new version of that row</u> (a new tuple) and marks the old one as <u>deleted</u>.

When you *rollback* an `INSERT`, the created tuple will remain but will be marked as <u>deleted/dead</u>.

Postgres have these columns automatically added to each row:
    `CTID` → represent the tuple’s location (<u>page</u>, <u>page offset</u>)
    `XMIN` → Birth date
    `XMAX` → Death date

So if you executed 

```sql
SELECT ctid, xmin, xmax, * FROM products
WHERE id = 1;
```

You will get 

![[Screenshot_2023-07-26_at_3.43.51_PM.png]]

Then if you update 

```sql
UPDATE products SET name = 'Cupcake' WHERE ID = 1;
```

And executed 

```sql
SELECT ctid, xmin, xmax, * FROM products
WHERE id = 1;
```

You will get

![[Screenshot_2023-07-26_at_3.44.11_PM.png]]

### What happens when you do a query ?

Imagine that we executed 

```sql
SELECT employee.name salaries.amount 
FROM employees, salaries 
JOIN ON employee.id = salaries.emp_id 
ORDER BY salaries.amount;
```

> [!note]+ Parsing (Click to extend)
> - The parsing stage involves checking the SQL query for syntax errors.
> - Convert it to a Data structure that the DBMS can understand an manipulate, usually referred as a parse tree or a query tree. 
> - Then it checks the query’s syntax against the rules of SQL, including checking all the keywords, operators and identifiers like (SELECT and FROM) if they are present and if they are used correctly.
> - If the query is valid, the parser will generate a parse tree (A tree like data structure that represent the component of a query and their relationships) where each node represent an operation (like a join or an aggregation), a table or a value.
> 
> ```sql
>                         ORDER BY
>                         /      \
>                      JOIN    salaries.amount
>                        /                \
>                     SELECT                ON
>                    /  \                  /  \
>                  FROM  =               id  emp_id
>                /        \              /          \   
>     employees.name  salaries.amount  employees  salaries
> ```

> [!note]+ Validation (Click to extend)
> After the parsing stage the DBMS will validate the existence of the tables and columns requested, the compatibility of column data types.
> 
> It will check the tables employees and salaries and then the columns (name, id, amount, emp_id) and will verify that each data type and the values are compatible. 

> [!note]+ Optimization (Click to extend)
> In the optimization stage the DBMS determine which is the best way (The most efficient) of executing the query. It will take the parse tree and generate a couple of execution plans (Which are sequence of operations that the DBMS can execute to perform the query). 
> The query optimizer estimates the cost of each query plan (IO, CPU, Memory, Network) these estimates are based on data that is maintained in the DB, like the number of rows, distribution of values in each column, if there is an indexes.
> Then the query optimizer will select a query plan with the lowest cost.

> [!note]+ Query Plan  (Click to extend)
> It is a sequence of instructions that the DBMS can follow to perform a query, it includes operations like (Table scans, Index Scans, Sort, Joins, aggregations …etc) and it includes the specific order in which these operations must execute and how the data will flow between them.
> So it will output a query plan like this
> 
> ```plain text
> 1. Scan the employees table.
> 2. For each row in employees, look up the matching 
> 	 rows in the salaries table using the emp_id field 
> 	 (this is a join operation).
> 3. For each matching pair of rows, combine the name field
> 	 from employees and the amount field from salaries.
> 4. Sort the resulting rows by the amount field.
> 5. Return the resulting rows to the client.
> ```

> [!note]+ Scans or Seeks (Click to extend)
> The DBMS now needs to retrieve the relevant rows from the tables, depending on the query plan it can have a table scan or an index scan, bitmap scan …etc
> 
> If there was no index, it will go to the heap and start scanning all the pages until it gets the desired rows.
> 
> If there was an index, it will perform an index scan (It will scan the index tree) to get the specific page and pull it then read it.

> [!note]+ Join Operations (Click to extend)
> There are some common types of how the join is performed
>     1. Nested Loop Join, which loops over each row in one table (employee) and checking if it matches any row in the other table (salaries)
>     2. Hash Join, which involves building a hash table (HashMap) of one of the tables (usually the smaller one) and then scanning the other table, looking up each row in the hash table.
>     3. Merge Join, Where the tables first sorted on the join column (id, emp_id) then merged together.

> [!note]+ Aggregating and sorting (Click to extend)
> Once the operations has been completed and the DBMS has a set of rows that matches the query, it will perform the aggregations and sorting (ORDER BY).
> 
> It will perform a sorting operation comparing the “amount” field in each row and rearranging the rows, this can be done by quick sort, merge sort, heap sort ..etc it depends on the size of the data.
> Once the sorting and aggregation is complete the result will be returned to the client. 

### Storage Concepts (Operation that are operated on the storage itself)

- Table
Tables are usually stored in a form of pages or blocks on the disk, where each page usually being a few kilobytes in size (depending on the DBMS). Each row is stored in these pages and the DBMS keeps track of where each table data is located on the disk.
- Row_id (CTID)
Most DB’s create their own system-maintained row, it is internal and system maintained
In certain DB’s like MySQL with innoDB engine it is the same as the primary key but other databases like postgres have a system column row_id (tuple_id). 
Which is a position in the row.
![[Screenshot_2023-07-22_at_11.48.57_PM.png]]
- Page
Nothing but a fixed-size memory location which translates to a disk location of a bunch of bytes.
If you thought about he table, depending on the storage model (row vs column) the rows are stored and read in the logical pages.
A page can fit many rows (but it depends on the row size and column types sizes).
Disk reads a page (When u do an IO you get a page or more, it depends on the disk partitions, but one page can have rows (8KB for postgres 16KB for MySQL) and these pages are stored on Disk, but they physically have a start and an end.
![[Screenshot_2023-07-22_at_11.49.35_PM.png]]
- IO
An operation and read request to the disk
We try to minimize this.
An IO cannot read a single row, its a page with many rows in them, you get them for free.
The page will be loaded (Loading everything)
The DB will then have to filter what you want and then get rid of what you don’t want and throught it away.
Then deserialize them back into the memory
Some IO can go to the OS cache (Like Postgres realise heavily on IO cache)
![[Screenshot_2023-07-22_at_11.49.43_PM.png]]
- Heap data structure
A collection of pages that represent points to the data table, it have everything for the table
A data structure where the table is stored with all its pages one after the other. 
This is where the actual data is stored including everything.
Traversing the heap(Querying the heap) is expensive as we need to read so many data to find what we want.
This is why we need indexes that help tell us exactly what part of the heap we need to read, What page(s) of the heap we need to pull to read.
![[Screenshot_2023-07-22_at_11.49.52_PM.png]]
- Index data structure B-Tree
Another Data structure that help us point where to go to the heap, it is separate from the heap. 
It has part of the data and used to quickly search for something
You can index a column or more. 
Once you find a value of the index, you can go to the heap to fetch more info.
Index tells you exactly which page to fetch in the heap instead of taking the hit to scan every page on the heap.
The index is also stored as pages and cost IO to pull the entries of the index, it lives in disk some indexes can fit in memory but if it was heavy it will live on the disk.
The smaller the index, the more it can fit in memory for faster search.
popular data structure for index is B-Trees.
A Clustered index is usally the primary key unless othersiwe specified, the DB Table will be organized around that index (Like in MySQL or InnoDB)
Postgres only have secondary indexes and all indexes point directly to the row_id which lives in the heap.
![[Screenshot_2023-07-22_at_11.50.07_PM.png]]

### Example of how the data is stored on the disk

![[Screenshot_2023-07-22_at_11.52.15_PM.png]]

![[Screenshot_2023-07-22_at_11.50.56_PM.png]]

→ Employee with <u>*emp_id*</u><u> </u><u>*10*</u><u> </u>is stored on the <u>**page 0**</u> and has the <u>**row_id of 1**</u>

So if we don’t have an index, and we did

```sql
SELECT * FROM emp WHERE emp_id = 10000;
```

It will query every page and scanning the emp_id of them until it reaches the page with that emp_id.
Some DB’s uses parallel searching (Where each search is in separate thread to walk over the heap)

This is very expensive.

![[Screenshot_2023-07-22_at_11.55.20_PM.png]]

So with an index:

```sql
SELECT * FROM emp WHERE emp_id = 10000;
```

It will query Index tree until we find exactly what page to look at, so we go to that page in the heap.

![[Screenshot_2023-07-22_at_11.57.31_PM.png]]

![[Screenshot_2023-07-22_at_11.58.29_PM.png]]
