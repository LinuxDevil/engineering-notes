---
notion-id: ae8d2e07-9446-4a4a-b54d-051fab4ad781
cover: "[[Database Backup.jpeg]]"
---
The process of creating copies of your database that can be restored if needed.

### Backup Strategies

1. Full backup
Copies all data from the database
2. Incremental Backup
Backing up only the data changed from the last backup
3. Differential backup
Similar to the incremental but backing up all the data changed 
4. Log Backup
backing up the transaction log which contains all the transaction performed in the database, this allows point-in-time recovery
5. Snapshot backup
Taking a read-only copy of the database at a given point of time.
6. Hot/Cold backup
A hot backup (Online backup) is taken when the database is running and accessible by the users.
A cold backup (Offline backup) is taken when the database is shutdown