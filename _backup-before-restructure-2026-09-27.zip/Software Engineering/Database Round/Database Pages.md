---
notion-id: 35a6e3fd-b87c-4b2f-b0e6-4daf071ec9d9
cover: "[[Database Pages.jpeg]]"
---
Databases usually use a fixed size page to store data. where data ends up as bytes in the page, this way the storage engine (Where everything is stored) can be separated from the Front-End layer where the data formatting and API lives. Also this makes caching, reading and writing data easier when everything is a page. 

## What goes in a page

### <u>**SQL Server Page layout**</u>

![[Screenshot_2023-07-23_at_5.42.00_PM.png]]

### <u>**PostgreSQL Page layout**</u>

![[Screenshot_2023-07-23_at_6.01.01_PM.png]]

![[Screenshot_2023-07-23_at_6.01.28_PM.png]]

## Database Pages

Databases read and write in pages. 

![[Pages_in_DB.drawio.png]]

When you read a row from a table in the database, the database first finds out where that page where the request row lives, and identifies the file and offset of where the page lives in disk.

Then the database asks the OS to read that file on the particular offset and length of page (8KB in case of Postgresql), Then the OS checks the file system <u>cache</u> if the data requested is <u>NOT</u> in there, then the OS issues the read and pulls the page in memory for the database to consume.  

The database allocates a pool of memory (Dedicated Memory space) often called shared or buffer pool. Pages read from disk are placed in the buffer pool. Once the pages are in the bugger pool, we get access to the requested row and the rows in the page where the requested row lives. This makes reads efficient especially those resulting from index range scans. The smaller the row the more rows fit in a single page the less IO we need.

The same goes for writes, when a user updates a row, the database finds the page where the row lives, pull the page in the buffer pool and update the row in memory, and make a journal entry of the change (Write ahead log) persisted to disk. The page can remain in memory so it receives more writes before finally it is flushed back to disk, Delete and Insert works the same way but implemented differently.

### Page Content

What you store in the page is really up to you. Row-Store db’s writes rows and all their attributes one after the other packed in the page so OLTP workloads are better.

Column-Store DB’s writes rows in pages column by column, so OLAP workloads is faster

Document based DB’s compress documents and store them in page just like row stores. 

Graph based DB’s persist the connectivity in pages such that page read is efficient for traversing graphs.

The goal here is to make the page read effective, the page should give you as much useful information as possible to help the client side workload.

### Small Vs Large Pages

Small pages are faster to read and write especially if the page size is closer to the media block size, however the cost of the page header metadata compared to useful data is very high, on the other hand, Large pages can minimize the page header metadata for more useful information and page splits, but at the cost of cold read and write.

PostgreSQL default page size is 8KB, MySQL inno is 16KB, Mongo WiredTiger is 32KB, SQL Server is 8KB and oracle is also 8KB.

You can configure it to best suite your use case.

### How page are stored on Disk

There are many ways we can store pages in disk, one way is to make a file per table or collection as a fixed size page array, Page 0 followed by Page 1 followed by page 2. To read something from the disk, we need this information (file name, offset and length) and with the current design we have it all!

To read page X, we have the file name from the table, to get the offset it is (X * Page_Size) and the length in bytes are the page size.

So to read pages 2 through 10 in table test with page size of 8KB, we have to read file where table test lives, with an offset of (2 * 8192) for ((The number of requested pages = 8) * 8192).

### PostgreSQL page layout

![[Screenshot_2023-07-23_at_6.01.01_PM.png]]

Page Header - 24 Bytes: Metadata about what is in the page 

ItemId’s - 4 Bytes each: This is an array of item <u>pointers</u> (Not the item themselves). Each itemId has 4 Bytes constructed like (Offset:Length) where the offset is where the item lives in the page and the length is how large the item is.

It is the fact that this pointer exist allows Heap Only Tuple (HOT) optimization, when an update happens to a row in Postgres a new tuple is generated if the tuple happens to get in the same page as the old tuple the HOT changes the old item id pointer to point to the new tuple. This way indexes can still point to the old tuple id.

To clarify: 

- Rows are what the user sees
- Tuple is the physical instance of the row in the page.
- The item is the tuple
- The same row can have 10 tuples 7 left for old transactions (MVCC reasons) to read, 2 dead tuples that no one needs and one active tuple.

Items - Variable length

This is where the items themselves live in the page one after the other.

Special - Variable length

Information about page pointers are stored here.

This section is only applicable to B+Tree index leaf pages, where each page links to the previous and forward. 