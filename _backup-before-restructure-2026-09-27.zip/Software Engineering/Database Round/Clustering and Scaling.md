---
notion-id: d36fc901-259e-43a5-9961-a99b7403e275
cover: "[[Clustering and Scaling.png]]"
---
### Failover

Is the process of switching to a redundant or standby server/database.

### Redundancy

Is the duplication of the critical components or function of a system with the intention of increasing reliability, and storing the same data more than in one place

Redundancy can be achieved in two ways

1. Replication
The same data is stored in multiple databases
2. Redundant Array of Independent Disk (RAID)
This is a data store virtualization technology that combines multiple disks into one logical unit for the purpose of data redundancy and performance improvements.

Scaling there’s 2 ways

3. Vertical scaling (Scaling up)
Adding resources to the same instance
4. Horizontal scaling (Scaling out)
Firing up multiple instances

### Clustering

Clustering refers to the use of multiple servers or storage devices that works together but <u>viewed</u> as a single system/unit.

Clustering can perform:

5. Load balancing
Distributes loads across multiple computers to optimize resources 
6. High Availability
Provides redundancy and failover
7. Fault Tolerance
It allows the system to continue working even if one component is down.
8. Increased capacity
Allows the system to handle high volume of workload.

Clustering Types

9. Database Clustering
Multiple databases can work on different servers. 
10. Load balance clustering
Incoming traffic is distributed into multiple servers.
11. High availability clustering
If one server is down, the other one is ready to take the workload
12. Computational clustering
Providing more computational power, the workload is divided among multiple nodes allowing parallel computations. 