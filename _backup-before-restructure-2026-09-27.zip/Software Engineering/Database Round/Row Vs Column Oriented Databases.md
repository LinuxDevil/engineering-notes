---
notion-id: c73cd05e-4ca3-4534-9112-8b12d2d34916
cover: "[[Row Vs Column Oriented Databases.jpeg]]"
---


## Row Oriented Database (Row Store)

![[Screenshot_2023-07-23_at_4.48.37_PM.png]]

- Tables are stored as rows in the disk  (Contiguous bits [first row, second row]), and a row can span multiple blocks
```sql
1001, 1, John, Smith, 111, 101,000, 1/1/1991, eng, 1/1/2011|||
1002,2,Kary,White,222,102,000,2/2/1992,mgr,2/1/2012
```
- A single block IO read to the table fetches multiple rows with all their columns (Block) So you need more IO to find the required row.

Let’s execute some <u>queries</u> against the table, Where there is <u>**No indexes**</u>

```sql
SELECT first_name FROM emp WHERE ssn = 666;
SELECT * FROM emp WHERE id = 1;
SELECT SUM(salary) FROM emp;
```

When you execute the first query, it will scan the heap on the pages, it will open the first page and checks, the second and checks, ..etc until it reaches the row requested.

![[Screenshot_2023-07-23_at_4.56.08_PM.png]]

The second query, if it is a sequence the DB can link this with the row_id.

![[Screenshot_2023-07-23_at_4.58.05_PM.png]]

The third query, you will get all the data, every block we pull we sum.

![[Screenshot_2023-07-23_at_4.59.14_PM.png]]

---

## Column Oriented Database (Column Store)

![[Screenshot_2023-07-23_at_5.03.16_PM.png]]

- Tables are stored as column first in disk (Column, Column, Column) The row_id is duplicated in every column
```sql
1:1001, 2:1002, 3:1003, 4:1004, 5:1005, 6:1006, 7:1007, 8:1008
John:1001, Kary:1002, Norman:1003, Nole:1004, Dar:1005, Yan:1006, Hasan:1007, Ali:1008
Smith:1001, White:1002, Freeman:1003, Sol:1004 Thee:1005, Ali:1006, Bilal:1007, Ali:1008
```
- A single read IO reads to the table fetches multiple columns with all matching rows
- Less IOs are required to get more values given of a column, but working with multiple columns require more IO.
- The DML commands will be super expensive


Let’s execute some <u>queries</u> against the table, Where there is <u>**No indexes**</u>

```sql
SELECT first_name FROM emp WHERE ssn = 666;
SELECT * FROM emp WHERE id = 1;
SELECT SUM(salary) FROM emp;
```

First Query, It will pick the <u>SSN block</u> / <u>page</u> and pull the second block until it finds the required one. Then it will pull the <u>first_name block</u> / <u>page</u> and will get the first_name that mapped with that <u>row_id</u>.

![[Screenshot_2023-07-23_at_5.08.22_PM.png]]

Second Query, it will start with the ID, then it will start to pull every block that mapped with that row_id. The select * is the worst thing that you could do.

![[Screenshot_2023-07-23_at_5.11.17_PM.png]]

Third Query, It will only do a one read or multiple blocks but that is super great. + Column based do compression, where if there exists the same value it will make one block that mapped to multiple row_id as an array

![[Screenshot_2023-07-23_at_5.13.44_PM.png]]

Pros & Cons

**Online Transaction Processing (OLTP)** and **Online Analytical Processing (OLAP)**.

![[Screenshot_2023-07-23_at_5.15.37_PM.png]]
