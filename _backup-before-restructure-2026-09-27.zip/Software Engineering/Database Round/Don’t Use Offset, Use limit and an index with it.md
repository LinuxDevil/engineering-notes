---
notion-id: 715e6aa4-1ed8-4aa8-8387-cd1e5bf408eb
cover: "[[Don’t Use Offset, Use limit and an index with it.jpeg]]"
---

When you execute a 

```sql
SELECT title FROM news 
OFFSET 100
LIMIT 10;
```

The database will physically fetch the first 110 rows and drop the first 100, when the offset is huge, the database is doing more work.

Another problem with offset is you might even read duplicate records if there was an insert statement executed when the offset is executing in parallel.


Use the id as the offset for example 

the user will send the last id that the use sees

```sql
SELECT title, id FROM news WHERE
id < 10099993 order by id desc limit 10;
```

 