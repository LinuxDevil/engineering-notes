---
notion-id: a6586bc0-3191-48cd-af67-e5b1f564b4a4
base: "[[Unix Commands.base]]"
Command: rm -rf <directory>
Example: $ rm -rf tmp/
---
