---
notion-id: 18f08aef-dd2b-424e-bcc8-464a2a419fda
base: "[[Unix Commands.base]]"
Command: rmdir <directory>
Example: $ rmdir environment/
---
