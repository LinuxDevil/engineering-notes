---
notion-id: 04600c1b-a4cf-40d9-a72a-fbf531677255
base: "[[Unix Commands.base]]"
Command: ls
Example: $ ls -l
---
