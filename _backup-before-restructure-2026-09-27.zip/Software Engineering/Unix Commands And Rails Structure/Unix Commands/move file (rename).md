---
notion-id: 03b64f7d-0c25-45ce-bf0f-959593285322
base: "[[Unix Commands.base]]"
Command: mv <source> <target>
Example: $ mv foo bar
---
