---
notion-id: 977fd6d8-7b79-4472-a5fa-429a2e84f912
base: "[[Unix Commands.base]]"
Command: ""
Example: $ cd ~ or just $ cd
---
