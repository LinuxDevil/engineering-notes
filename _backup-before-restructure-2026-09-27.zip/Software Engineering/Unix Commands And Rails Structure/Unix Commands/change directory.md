---
notion-id: 266c1ad6-372d-434e-a59b-6e45dd30130d
base: "[[Unix Commands.base]]"
Command: cd <dirname>
Example: $ cd environment/
---
