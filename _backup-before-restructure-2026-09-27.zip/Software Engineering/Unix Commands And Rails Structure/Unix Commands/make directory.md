---
notion-id: b12f7cfd-4f54-411a-98dd-57c548929b9c
base: "[[Unix Commands.base]]"
Command: mkdir <dirname>
Example: $ mkdir environment
---
