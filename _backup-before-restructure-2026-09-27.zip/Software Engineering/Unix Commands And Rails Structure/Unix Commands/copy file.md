---
notion-id: 797874c0-d9f3-410b-a521-a47a0db72c3b
base: "[[Unix Commands.base]]"
Command: cp <source> <target>
Example: $ cp foo bar
---
