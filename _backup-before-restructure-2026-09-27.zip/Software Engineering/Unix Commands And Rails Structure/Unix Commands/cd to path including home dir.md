---
notion-id: ecfec707-e987-4a11-a295-290d4b9316df
base: "[[Unix Commands.base]]"
Command: ""
Example: $ cd ~/environment/
---
