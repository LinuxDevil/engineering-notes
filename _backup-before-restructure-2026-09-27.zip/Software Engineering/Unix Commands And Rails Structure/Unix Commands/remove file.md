---
notion-id: e3d06a8c-6d77-4ba3-b650-fd16f0eb8f16
base: "[[Unix Commands.base]]"
Command: rm <file>
Example: $ rm foo
---
