---
notion-id: 6c72eee3-5695-4ab5-8e3e-4424eecb4d90
base: "[[Unix Commands.base]]"
Command: ""
Example: $ cd ..
---
