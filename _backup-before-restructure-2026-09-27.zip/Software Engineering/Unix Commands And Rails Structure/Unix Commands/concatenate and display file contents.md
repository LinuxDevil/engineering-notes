---
notion-id: 7ab98bd4-fd4d-45dd-bc4b-a45ef60113e1
base: "[[Unix Commands.base]]"
Command: cat <file>
Example: $ cat ~/.ssh/id_rsa.pub
---
