---
notion-id: b33b9659-e5e8-418e-9962-66d9ef728d5f
base: "[[Rails File Structure.base]]"
File/Directory: .gitignore
---
