---
notion-id: b23667a5-6928-4683-b895-eb5b8dee881f
base: "[[Rails File Structure.base]]"
File/Directory: Gemfile.lock
---
