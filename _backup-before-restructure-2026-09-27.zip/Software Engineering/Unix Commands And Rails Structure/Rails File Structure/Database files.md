---
notion-id: e0c57eaf-fa31-465f-b5d9-0eabea23dc3f
base: "[[Rails File Structure.base]]"
File/Directory: db/
---
