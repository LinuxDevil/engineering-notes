---
notion-id: fa63f6e0-5c78-4ec0-96bf-011d588ee0da
base: "[[Rails File Structure.base]]"
File/Directory: bin/
---
