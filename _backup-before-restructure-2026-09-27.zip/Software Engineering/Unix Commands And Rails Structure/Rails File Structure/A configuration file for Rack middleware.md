---
notion-id: 3e8aff9d-0974-466b-88bf-535c60a8ad8c
base: "[[Rails File Structure.base]]"
File/Directory: config.ru
---
