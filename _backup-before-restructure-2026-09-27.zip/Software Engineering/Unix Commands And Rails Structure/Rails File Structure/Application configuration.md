---
notion-id: 3ee0ed20-532a-4ee0-8f71-7a7c02d4bc5c
base: "[[Rails File Structure.base]]"
File/Directory: config/
---
