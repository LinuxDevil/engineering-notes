---
notion-id: fe876b62-9701-4d23-8fd2-60d9de3523e1
base: "[[Rails File Structure.base]]"
File/Directory: log/
---
