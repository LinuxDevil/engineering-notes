---
notion-id: 3d027714-43e1-440e-90b0-48060aaca761
base: "[[Rails File Structure.base]]"
File/Directory: public/
---
