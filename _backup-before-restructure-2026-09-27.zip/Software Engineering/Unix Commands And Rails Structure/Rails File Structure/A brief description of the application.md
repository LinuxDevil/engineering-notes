---
notion-id: 3df64ec4-faf9-4899-a143-c5e535cc2b27
base: "[[Rails File Structure.base]]"
File/Directory: README.md
---
