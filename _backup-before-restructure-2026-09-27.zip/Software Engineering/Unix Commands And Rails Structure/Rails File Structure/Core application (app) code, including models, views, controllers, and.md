---
notion-id: 0bf285ba-1892-4d81-ad1c-24317f4eeb50
base: "[[Rails File Structure.base]]"
File/Directory: app/
---
