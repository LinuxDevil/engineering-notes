---
notion-id: cde4bc4a-93ce-4aea-89d6-8949841f0efa
base: "[[Rails File Structure.base]]"
File/Directory: lib/
---
