---
notion-id: 46dbed8a-944a-489a-aba5-c83fa8f19c4f
base: "[[Rails File Structure.base]]"
File/Directory: app/assets
---
