---
notion-id: d7f8c60f-0903-42ce-a431-1866763e2f02
base: "[[Rails File Structure.base]]"
File/Directory: Gemfile
---
