---
notion-id: 912c775f-c4ec-4acd-8caa-533a542e8202
base: "[[Rails File Structure.base]]"
File/Directory: bin/rails
---
