---
notion-id: 8482e8e1-eb27-4a4a-b225-b6012008d406
base: "[[Rails File Structure.base]]"
File/Directory: tmp/
---
