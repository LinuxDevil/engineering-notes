---
notion-id: 987fa508-1b4a-4052-a508-9218cc7c8171
base: "[[Rails File Structure.base]]"
File/Directory: doc/
---
