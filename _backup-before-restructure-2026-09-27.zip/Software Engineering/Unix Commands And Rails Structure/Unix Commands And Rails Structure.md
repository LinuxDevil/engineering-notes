---
notion-id: 27c99819-b926-48ae-bbe0-a80470fa23e1
cover: "[[Unix Commands And Rails Structure.jpeg]]"
---

Common Unix Commands List:

![[Unix Commands.base]]

File Structure for Rails application using the rails new command

![[Rails File Structure.base]]