---
notion-id: 4253e035-291b-4836-8009-d944f1edecae
cover: "[[OOP.jpeg]]"
---
Object Oriented Programming
![[Untitled 16.png]]

    **Basic Terminologies:**
        ## **Object:**
        It’s the instance of a class/ it’s the working entity of a class.
        ## **Class:**
        It is a template or blue print about the capability of what an object can do.
        ## **Method:**
        The behaviours of a class. It tells what a method can do.
        ## **Instance:**
        Object and Instance both are same with small difference.

    # **OOPs Concepts:**
	1. Encapsulation
	2. Abstraction
	3. Polymorphism
	4. Inheritance
    # **Encapsulation:**
    Encapsulation is a mechanism of wrapping the data (instance variables) and code acting on the data (methods) together as a single unit like a Class.
    The main purpose of encapsulation is you would have full control on data by using the code.
    In encapsulation, the variables of a class **can be made hidden** from other classes, and can be accessed only through the methods of their current class. Therefore, it is also known as **data hiding**.
    # **Abstraction:**
    “You abstract only when you discover the abstraction”
    Abstraction is a process of hiding the implementation details from the user, only the functionality will be provided to the user.
    In other words, the user will have the information on what the object does instead of how it does it.
    Abstraction has 2 types:
		1. Control Abstraction.
		2. Data Abstraction.
        ## **Control Abstraction:**
        Programming languages offer control abstraction as one of the main purposes of their use. Computer machines understand operations at the very low level such as moving some bits from one location of the memory to another location and producing the sum of two sequences of bits. Programming languages allow this to be done in the higher level. For example, consider this statement written in a [Pascal](https://en.wikipedia.org/wiki/Pascal_(programming_language))-like fashion:
```plain text

a := (1 + 2) * 5
```
        ## **Data Abstraction:**
        Abstraction of data structures. Data abstraction refers to defining the behaviour of the data structure. Data may be internally represented in different ways in concrete implementations.
        Example: Collection, ArrayList

	- The difference between concepts of encapsulation and abstraction is that encapsulation is about the packaging of the class (like how data should be accessed (setters/getters) and what data should be accessed (access specifiers)), whereas abstraction more about what the class does for you at a conceptual level.
	- Encapsulation is hiding unnecessary data in a capsule or unit and Abstraction is showing essential feature of an object
	- Abstraction encompasses encapsulation, information hiding, and generalisation.
	- abstraction is a form of generalisation: writing code that applies to more than one specific situation.
	- Abstraction is where you focus on only those details that are important for your purpose.
	- Inheritance is also an example of abstraction.
	- **Encapsulation leads to Abstraction**

    # **Inheritance:**
    Inheritance can be defined as the process where one class acquires the properties (methods and fields) of another.
    # **Types Of Inheritance:**
	5. Single Inheritance
	6. Multiple Inheritance
	7. Multi-Level Inheritance
	8. Hierarchical Inheritance
	9. Hybrid Inheritance
![[Untitled 17.png]]


# **Polymorphism:**

In object-oriented programming, polymorphism (from the Greek meaning “having multiple forms”) is the characteristic of being able to assign a different meaning or usage to something in different contexts — specifically, to allow an entity such as a function, or an object **to have more than one form**.

There is two types of polymorphism:
	1. Static Polymorphism
	2. Dynamic Polymorphism
    **Static polymorphism is polymorphism that occurs at compile time, and dynamic polymorphism is polymorphism that occurs at runtime (during application execution)**. An aspect of static polymorphism is early binding. In early binding, the specific method to call is resolved at compile time.

The work of polymorphism can be addressed in two different ways;
	1. Method Overloading 
	2. Method Overriding
    ## **Method Overriding **
    Implements Runtime Polymorphism
    This is used in situations where a method inherited by a child class from a parent class doesn’t fit in the child's class. Meaning, we’d have to re-implement the method in the child class.
    You want to change the behaviour or extend upon it. Same signature different functionality.
    When the method signature (name and parameters) are the same in the superclass and the child class, it’s called Overriding.
    ## **Method Overloading**
    Implements Compile time polymorphism
    Overloading, in programming, refers to the ability of a method to behave in different ways depending on the parameters that are passed to the method.
    When two or more methods in the same class have the same name but different parameters, and even a different return type it’s called Overloading.
    ## Overriding vs Overloading
	3. Overriding implements Runtime Polymorphism whereas Overloading implements Compile time polymorphism.
	4. The method Overriding occurs between superclass and subclass. Overloading occurs between the methods in the same class.
	5. Overriding methods have the same signature i.e. same name and method arguments. Overloaded method names are the same but the parameters are different.
	6. With Overloading, the method to call is determined at the compile-time. With overriding, the method call is determined at the runtime based on the object type.
	7. If overriding breaks, it can cause serious issues in our program because the effect will be visible at runtime. Whereas if overloading breaks, the compile-time error will come and it’s easy to fix.