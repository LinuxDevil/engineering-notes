---
notion-id: 206f71ff-35e0-44cf-a4a4-8cccb0562e34
cover: "[[Dry & Kiss.jpeg]]"
---

**DRY**: Don’t repeat yourself

**Kiss**: Keep it simply stupid

**Dry**
    "Every piece of knowledge or logic must have a single, unambiguous representation within a system."
    To avoid violating the DRY principle, divide your system into pieces. Divide your code and logic into smaller reusable units and use that code by calling it where you want. Don't write lengthy methods, but divide logic and try to use the existing piece in your method.
    One good example of the DRY principle is the helper class in enterprise libraries, in which every piece of code is unique in the libraries and helper classes.


**Kiss**
    The KISS principle is descriptive to keep the code simple and clear, making it easy to understand. After all, programming languages are for humans to understand so keep coding simple and straightforward. Keep your methods small.
    <u>Each method should never be more than 40-50 lines</u>.
    Each method should only solve <u>**one**</u> small problem, not <u>**many use cases**</u>. If you have a lot of conditions in the method, break these out into smaller methods. It will not only be easier to read and maintain, but it can help find bugs a lot faster.

    Example 1:
```java
public String weekday1(int day) {
	switch (day) {
		case 1:
			return "Monday";
		case 2:
			return "Tuesday";
		case 3:
			return "Wednesday";
		case 4:
			return "Thursday";
		case 5:
		return "Friday";
		case 6:
				return "Saturday";
		case 7:
			return "Sunday";
		default:
			throw new InvalidOperationException("day must be in range 1 to 7");
	}
}
```
```java
public String weekday2(int day) {
	if ((day < 1) || (day > 7)) throw new InvalidOperationException("day must be in range 1 to 7");
	string[] days = {
	    "Monday",
	    "Tuesday",
	    "Wednesday",
	    "Thursday",
	    "Friday",
	    "Saturday",
	    "Sunday"
	};
	
	return days[day - 1];
}
```
        To avoid violating the KISS principle, try to write simple code. Think of many solutions for your problem, then choose the best, simplest one and transform that into your code. Whenever you find lengthy code, divide that into multiple methods. Try to write small blocks of code that do a single task.