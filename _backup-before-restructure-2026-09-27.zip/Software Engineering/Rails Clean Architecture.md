---
notion-id: b700552d-d816-4c45-a1d1-de0c0cb24de1
cover: "[[Rails Clean Architecture.jpeg]]"
---

**POROs**: Plain Old Ruby Object (It’s basically a ruby class)

**Services**: A **service** provides a piece of functionality that can be used in other application components (in our case, the controllers). While including services isn't an intrinsic feature of Rails, it's an important design principle that's popular with many developers and frameworks (such as Angular). don’t forget to enable **eager load.**

What is **The Service Object**
    The Service Object pattern involves the creation classes that represent business logic or behaviour that would otherwise sit too close to the the database in an ActiveRecord model or in the controller.


Now breaking down business rules into <u>entities</u>, <u>use cases</u> and <u>adapters</u> a fairer split of labour than simply lifting and shifting controller code into a single service object. That said, in many cases where an application is made up of (mostly) simple CRUD, this extra layer of complexity wasn't needed at all.

**Introducing Clean Architecture: Services (and other friends)**
    **Command Pattern**
        A Command pattern is **an object **<u>**behavioral pattern**</u>** that allows us to achieve complete decoupling between the sender and the receiver**. (A sender is an object that invokes an operation, and a receiver is an object that receives the request to execute a certain operation.

    **Adapter Pattern**
        An Adapter Pattern says that just "**converts the interface of a class into another interface that a client wants**". In other words, to provide the interface according to client requirement while using the services of a class with a different interface. The Adapter Pattern is also known as Wrapper.

    **The active record design pattern** (considered an architectural pattern) is an approach to accessing data in a database.
        **The active record** is an object that wraps a row in the database table or view, encapsulates the database access and adds domain logic on that data. An object carries both data and behavior. Much of this data is persistent and needs to be stored in a database.
        Active Record uses the most obvious approach, putting data access logic in the domain object. This way all people know how to read and write their data to and from the database. The interface on an object conforming to this pattern would include functions such as Insert, Update, and Delete, and properties that correspond more or less directly to the columns in the underlying database table.

    The <u>Services convention</u> in Rails clearly matches that of <u>use case classes</u> that represent actions a user can make on a system. This especially rings true for me when taking the Command pattern approach to Services which is the same convention I see used in Clean Architecture use cases. Just put your use cases in `app/services`!

    <u>Entities</u> are use to represent enterprise-level business rules. Code that will likely be shared across use cases and business functions. These need only introducing when you want to share behaviour between use cases, or when you want to abstract your use cases from the database and the <u>ActiveRecord</u> pattern. There are plenty of libraries including ActiveModel that provide helpers to make the definition of these classes easier. You may need to debate with your team whether these can sit beside database representations in `app/models` or whether you split them out into `app/domains`.

    <u>Adapters</u> are already known to Rails developers as the <u>Adapter pattern</u> is rife there too. Plenty of applications have adapters for connecting to external APIs or databases. These can go in `app/adapters`.


**Fat Model, Skinny Controller**
    “Fat Model, Skinny Controller” refers to how the **M** and **C** parts of **MVC** ideally work together. Namely, <u>any non-response-related logic should go in the model</u>, ideally in a nice, testable method. Meanwhile, the “skinny” controller is simply a nice <u>interface between the view and model</u>.
