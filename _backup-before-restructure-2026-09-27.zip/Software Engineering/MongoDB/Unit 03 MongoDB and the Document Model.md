---
notion-id: 0f8b85dd-3e05-4580-b6db-2d2b65518391
---
In this unit, you’ll learn how MongoDB stores data and how MongoDB fits into Atlas, the developer data platform. You'll also review common use cases for MongoDB. Next, you'll learn the value types that MongoDB supports, how MongoDB creates unique identifiers, and what it means that MongoDB has a “flexible schema.” Finally, you’ll begin to manage databases, collections, and documents in the MongoDB Atlas Data Explorer. This unit will give you a solid foundation in the concepts and skills that you'll need to work with MongoDB.

**MongoDB** is a General purpose document database

Structure data in documents like JSON, documents is flexable. Model data of any shape. we can use one format to query and create the document.

**The Document** is the basic data unit in mongodb

**Collection** is a grouping of the documents, and they don’t have to follow the same schema.

**Database** A container of the collections

The document model structures like that

```bash
{
	"key": value,
	"key": value,
	...
}
```

The document is stored in BSON (binary json which is an extend on json that mongodb can leverage and use, bson also supports datatypes that unavailable in json like dates number and objectIds) and Displayed as JSON

**ObjectId** is a special data type to create a unique identifier for the required _id field.

Mongodb support **polymorphic data** (Polymorphic data means that in one collection you have many versions of document schema)

If we want to control the schema we can add a **optional schema validation** to set constraints on the structure of the document.

