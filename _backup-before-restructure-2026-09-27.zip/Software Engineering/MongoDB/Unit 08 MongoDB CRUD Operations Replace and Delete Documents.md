---
notion-id: 2190997e-1726-471e-97bc-46e7d2a53952
---
In this unit, you’ll learn how to update, replace, and delete documents in MongoDB. These commands will help you manipulate data in your database and will prepare you to build MongoDB into your own apps. We will replace entire documents, update individual fields in a document, insert new documents, and remove documents from a database. By the end of this unit, you'll be able to execute most of the common database operations.

**Replacing documents**

replaceOne()

```bash
db.collection.replaceOne(filter,
 replacement, option)
```

- `filter`: A query that matches the document to replace.
- `replacement`: The new document to replace the old one with.
- `options`: An object that specifies options for the update.

**Update documents**

updateOne()

```bash
db.collection.updateOne(
	<filter>,
	<update>,
	{options}
)
```

- `filter`: A query that matches the document to replace.
- `update`: the fields you want to update with the value
	- $**set** adds a new fields and values to the document or replace the value of a specified field value
	- $**push** appends a value to an array, if absent the $push will add the array field with the value as its element.
- `options`: An object that specifies options for the update.
	- **upsert**, insert a document with the provided information if matching documents don’t exists.
```bash
db.collection.updateOne(
	<filter>,
	<update>,
	{ upsert: true }
)
```

```bash
db.birds.updateOne(
{common_name: "Robin Redbreast"},
 { $inc: {"sightings": 1},
 $set: {"last_updated": new Date() }},
 {upsert: true})
```

Update and return the same document

findAndModify()

```bash
db.collection.findAndModify(query, update, new)
```

the new: so that the new document is retuned.

```bash
db.podcasts.findAndModify({
  query: { _id: ObjectId("6261a92dfee1ff300dc80bf1") },
  update: { $inc: { subscribers: 1 } },
  new: true,
})
```

Update multiple documents

updateMany() - will not roll back updates and not isolated

```bash
db.collection.updateMany(filter, update, filter)
```

Deleting a document

deleteOne()

```bash
db.collection.deleteOne(filter, options)
```

deleteMany()

```bash
db.collection.deleteMany(filter, options)
```
