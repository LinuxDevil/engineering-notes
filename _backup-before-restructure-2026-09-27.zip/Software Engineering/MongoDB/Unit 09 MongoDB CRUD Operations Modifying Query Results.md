---
notion-id: 2d4f2236-98e2-406a-af10-1da6be752a36
---

Sorting and Limiting query results

We will take advantage of the cursor.

**What is a cursor in MongoDB?**

A pointer to the result set of a query

cursor.sort()

```bash
db.collection.find(<expression>).sort({
	<how to sort> like name: 1
})
1 --> Asc
-1 --> Desc
```

cursor.limit()

```bash
db.collection.find(<expression>).limit({
	<how many to see in the result>
})
```

you can get only the name field using projection

```bash
db.collection.find(<expression>, <projection>).sort({
	<how to sort> like name: 1
})
1 --> Asc
-1 --> Desc
```

```bash
db.sales
	.find(
		{ storeLocation: "London",
			items: 
				{ $elemMatch:
					 { "name":
							 { $in:
	 ["paper", "laptop", "backpack", "printer"]
	} } } }
).sort({saleDate: -1}).limit(3)
```

Return a specific data from a query

By default we can improve bandwidth by using projection (select some properties on the document)

```bash
db.collection
	.find({<expression>, <projection>})
```

include projection when you set the field to 1, exclude when you don’t want the field and set it to 0. you can’t combine them together, the only exception is the _id field.

```bash
db.sales.find({"customer.age": { $lt: 30 }, "customer.satisfaction": { $gt: 3 }}, { "customer.age": 1, "customer.satisfaction": 1, _id: 0})
```

Counting documents

```bash
db.collection.countDocuments(<query>, <options>)
```

```bash
db.sales.countDocuments({ storeLocation: "Denver", couponUsed: true})
```
