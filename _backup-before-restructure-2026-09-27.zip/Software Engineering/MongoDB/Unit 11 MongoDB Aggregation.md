---
notion-id: bc9c408f-ac28-456b-ac22-ade365d33404
---

**Aggregation** is an analysis and summary of data.

Stage is single an operation performed on the data.

**Aggregation pipeline**, is a series of stages completed one at a time in order, where data can be filtered, sorted, grouped and transformed. 

The aggregate method is a superset of find()

```bash
db.collection.aggregate([])
```

1. `**$match**`: Filters the documents based on the specified condition(s). It's similar to the `**find()**` method in MongoDB.
2. `**$project**`: Selects or modifies specific fields in the documents, similar to the projection parameter in the `**find()**` method.
3. `**$group**`: Groups documents by a specified expression or key, and performs various aggregation operations on the grouped data.
4. `**$sort**`: Sorts the documents based on the specified field(s) and sort order (ascending or descending).
5. `**$limit**`: Limits the number of documents passed to the next stage in the pipeline.
6. `**$skip**`: Skips a specified number of documents before passing them to the next stage in the pipeline.
7. `**$unwind**`: Deconstructs an array field from input documents to output a document for each element in the array.
8. `**$lookup**`: Performs a left outer join with another collection, adding the matched documents as a new field in the input documents.

```bash
$set: {
	defaultUsername: {
		$concat: ["$first_name", "$last_name"]
	}
}
```

```bash
const pipeline = [
  // Stage 1: match the accounts with a balance lesser than $1,000
  { $match: { balance: { $lt: 1000 } } },
  // Stage 2: Calculate average balance and total balance for each type of account
  {
    $group: {
      _id: "$account_type",
      total_balance: { $sum: "$balance" },
      avg_balance: { $avg: "$balance" },
    },
  },
]
```