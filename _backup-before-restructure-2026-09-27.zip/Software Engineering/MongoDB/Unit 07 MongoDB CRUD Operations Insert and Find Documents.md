---
notion-id: 7da4a53e-1ad2-4444-bc6d-c47b820429f8
---
In this unit, you will be introduced to CRUD operations in MongoDB by inserting and finding documents. Inserting and finding documents will help you discover the ease and usability of MongoDB. You'll also build your own queries that use comparison and logical operators. Using operators will make your queries more precise and, in turn, make your application easier to develop. Finally, you'll learn how to query elements in an array. Arrays are a crucial data type that you will encounter frequently, so it's important that you have a solid understanding of how to work with them.

**Inserting documents**

We can insert documents using:

insertOne()

```bash
db.<collection>.insertOne(<data>);
```

if the collection doesn’t exists the monogdb will create it automatically for you.

insertMany()

```bash
db.<collection>.insertMany([...]);
```

**Find documents in a collection**

find()

```bash
db.<collection>.find()
```

it will return a cursor with the results.

to retrieve a specific document we can use the 

explicit syntax { field: { $eq: <value> } } or the shorter implicit syntax {field: <value> }

```bash
db.<collection>.find({
	field: { $eq: <value> }
})
```

$in allows us to select all documents that have a field value equal to any of the values specified in the array.

```bash
db.<collection>.find({
	field: { $in: [
		...
	]}
})
```

Comparison operation

- $gt greater than
- $gte greater than or equal
- $lt less than
- $lte less than or equal

```bash
db.<collection>.find({
	field: {
		<operator>: <value>
	}
})
```

we can also do this

```bash
db.<collection>.find({
	"subdocument.field": {
		<operator>: <value>
	}
})
```

Querying on Array elements

$elemMatch make sure that it is an array and the element is in the array

```bash
db.<collection>.find({
	document: {
		$elemMatch: {
			$eq: <value>,
			$lt: <value>,
			...
		}
	}
})
```

```bash
db.transactions.find({
 "transactions": { 
		$elemMatch: 
			{ "amount": { $lte: 4500 },
				 "transaction_code": { $eq: "sell" }
 }}})
```

Logical operator

$and

```bash
db.<collection>.find({
	$and: [
		{ expression },
		...
	]
})
// Or we can use this
db.<collection>.find(
		{ expression },
		{ expression },
		...
)
```

$or

```bash
db.<collection>.find({
	$or: [
		{ expression },
		{ expression },
		...
	]
})
```

and we can use them together

```bash
db.<collection>.find({
	$and: [
		{ $or: [ {expression}, {expression} ] },
		{ $or: [ {expression}, {expression} ] },
		...
	]
})
```