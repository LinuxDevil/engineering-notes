---
notion-id: 1969d5ad-c6e0-4ec1-8a73-4717882e7176
---

Conneting from MongoDB

What are driver?
A middleware that workds in tandem with the built-in Nodejs BSON package to interact with your MongoDB server. It simplifies the connection and work with the db.

Install it 

```bash
npm install mongodb
```

Get the connection string

```bash
mongodb+srv://admin:admin@cluster0.rvygg17.mongodb.net/?retryWrites=true&w=majority
```

then in your IDE

```javascript
const { MongoClient } = require('mongodb');
const uri = require('./atlas_uri.js');

const client = new MongoClient(uri);
const dbName = "bank";

const connectToDB = async () => {
    try {
        await client.connect();
        console.log("Connected to DB");
    } catch (error) {
        console.log(error);
    }
};

const main = async () => {
    try {
        await connectToDB();
    } catch (error) {
        console.log(error);
    } finally {
        await client.close();
        console.log("Disconnected from DB");
    }
}

main();
```

