---
notion-id: 4fda4b5c-7243-4bee-af58-37edb467fbcd
---

MongoDB connection string allows us to connect to our cluster and work with it, it describe the host and the options used to connect to a mongodb.

There’s two formats for the connection string:

1. **Standard format
**Used to connect to standalone clusters, replica set, or a sharded clusters.
2. **DNS seed list format**
Provides a DNS Server list to our connection string, and gives more flexibility of deployment and gives us the ability to change servers in rotation without reconfiguring clients.

**The components of a connection string**

```bash
mongodb+srv://admin:<password>
	@cluster0.rvygg17.mongodb.net/
	?retryWrites=true&w=majority
```

3. prefix: mongodb which use a DNS seed list for the servers which we can connect to.
4. +srv: sets the security option to true and tells mongodb to use the DNS seed list.
5. cluster0.rvygg17.mongodb.net: host and port to our database, if the port is not specified mongodb will default to 27017
6. options (retryWrites=true&w=majority) 
	retryWrites: it tells mongodb to retry the failed writes automatically.


Mongodb shell using the Nodejs REPL environment which gives us access to JS inside the shell

![[Screenshot_2023-04-22_at_9.32.08_PM.png]]

```bash
mongosh "mongodb+srv://cluster0.rvygg17.mongodb.net/myFirstDatabase" --apiVersion 1 --username admin
```

![[Screenshot_2023-04-22_at_9.30.08_PM.png]]

To get the connection string in CLI

```bash
atlas clusters connectionStrings 
	describe myAtlasClusterEDU
```

**Connect to Compass to connect**

**Compass** is a GUI that allows us to query and analyze our data, and compose aggregation pipelines.

Connecting to Application Drivers

Application drivers allows us to connect to our database with our application by a connection string.

visit the developers mongodb page for more insight.

Troubleshooting MongoDB Altas Connection errors

**Network access errors**

failure of your application to connect to the database.

**User authentication errors**

username or password errors or check your database connection string.
