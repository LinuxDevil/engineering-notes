---
notion-id: 1039b876-7a70-49cb-8fcb-21d2f7bee5ef
---
Atlas Search is an incredibly powerful tool that is surprisingly easy to set up and use. In this unit, you'll learn how to get started with Atlas Search and add search functionality to your application.

```bash
mongosh -u myAtlasDBUser -p myatlas-001 $MY_ATLAS_CONNECTION_STRING/sample_supplies
```

Relevance-based search vs database search

**Relevance search** is when the users wants to search for surface record based on a search term. like the search bar in websites (Keyword based).

**Database search** is when the developers wants to query against a criteria.

**Search indexes** is used to specify how the search algorithm will work. and defines how a search should be performed on the records to match relevancy.

Search index vs database index

- **Database indexes** used by developer to make queries easier and more efficient.
- **Search Indexes** used to specify how records are referenced for relevance based search.

**Components** of a search index

- Analyzers used (Index analyzer, Search Analyzer)
- Type of mapping
- Store documents 
- field mapping

Search index with dynamic mapping

Dynamic mapping is all field will be **indexed** except for (booleans, objectIds and timestamps).

Creating a search index:

From the cli:

create search_index.json file

```bash
{
    "name": "sample_supplies-sales-dynamic",
    "searchAnalyzer": "lucene.standard",
    "analyzer": "lucene.standard",
    "collectionName": "sales",
    "database": "sample_supplies",
    "mappings": {
        "dynamic": true
    }
}
```

then do 

```bash
atlas clusters search indexes create
	 --clusterName myAtlasClusterEDU
	 -f /app/search_index.json
```

To see your search indexes

```bash
atlas clusters search indexes list
	 --clusterName myAtlasClusterEDU
	 --db sample_supplies
	 --collection sales
```

To search inside the atlas:

```bash
db.sales.aggregate([
  {
    $search: {
      index: 'sample_supplies-sales-dynamic',
      text: {
        query: 'notepad', path: { 'wildcard': '*' }
      } } },
  {
    $set: {
      score: { $meta: "searchScore" }
      }
  }
])
```

From the Website:

Go to the search tab in your database

![[Screenshot_2023-04-27_at_4.15.34_PM.png]]

![[Screenshot_2023-04-27_at_4.16.06_PM.png]]

![[Screenshot_2023-04-27_at_4.16.38_PM.png]]

And that’s how you create a search index!

Static indexing on field mapping: the fields being queried are always the same.

To create one in the cli

create search_index.json

```bash
{
    "name": "sample_supplies-sales-static",
    "searchAnalyzer": "lucene.standard",
    "analyzer": "lucene.standard",
    "collectionName": "sales",
    "database": "sample_supplies",
    "mappings": {
        "dynamic": false,
        "fields": {
            "storeLocation": {
                "type": "string"
            }
        }
    }
}
```

then

```bash
atlas clusters search indexes create --clusterName myAtlasClusterEDU -f /app/search_index.json
```

then to list the indexes 

```bash
atlas clusters search indexes list --clusterName myAtlasClusterEDU --db sample_supplies --collection sales
```

$search and $compound operator for better scoring

$compound is used for how the results should be sorted (scored)

- must will score the record that match exactly
- must not negation of must
- should assign weight for records match the clause
- filter eliminate search results 

![[Screenshot_2023-04-27_at_5.19.34_PM.png]]

```bash
$search {
  "compound": {
    "must": [{
      "text": {
        "query": "field",
        "path": "habitat"
      }
    }],
    "should": [{
      "range": {
        "gte": 45,
        "path": "wingspan_cm",
        "score": {"constant": {"value": 5}}
      }
    }]
  }
}
```

```bash
db.sales.aggregate([
  {
    $search: {
      index: 'sample_supplies-sales-dynamic',
      "compound": {
        "filter": [
          {
            "text": {
              "query": "Online",
              "path": "purchaseMethod"
            }
          }
        ],
        "should": [
          {
            "text": {
              "query": "notepad",
              "path": "items.name",
              "score": { "constant": { "value": 5 } }
            }
          }
      ]
      }
    }
  },
  {
    $project: {
    "items.name": 1,
    "purchaseMethod": 1,
    "score": { $meta: "searchScore" }
    }
  }
])
```

$FACETS: Buckets that we group our search results into.

( numbers, dates and strings )

we need to use $searchMeta (information of the search)

```bash
{
  facet: {
    operator: {
      text: {
        query: ['machine'],
        path: 'author'
      }
    },
    facets: {
      'weeklyFacet': {
        type: 'date',
        path: 'date',
        boundaries: [
          ISODate('2022-01-01'),
          ISODate('2022-01-08'),
          ISODate('2022-01-015'),
          ISODate('2022-01-022'),
        ],
        default: 'other'
      }
    }
  }
}
```

in the cli

create search_index.json

```bash
{
    "name": "sample_supplies-sales-facets",
    "searchAnalyzer": "lucene.standard",
    "analyzer": "lucene.standard",
    "collectionName": "sales",
    "database": "sample_supplies",
    "mappings": {
        "dynamic": true,
        "fields": {
        "purchaseMethod": [
            {
            "dynamic": true,
            "type": "document"
            },
            {
            "type": "string"
            }
        ],
        "storeLocation": [
            {
            "dynamic": true,
            "type": "document"
            },
            {
            "type": "stringFacet"
            }
        ]
        }
    }
}
```

then

```bash
atlas clusters search indexes create --clusterName myAtlasClusterEDU -f /app/search_index.json
```

then to see them

```bash
atlas clusters search indexes list --clusterName myAtlasClusterEDU --db sample_supplies --collection sales
```

```bash
db.sales.aggregate([
  {
    $searchMeta: {
      index: 'sample_supplies-sales-facets',
        "facet": {
            "operator": {
                "text": {
                    "query": "In store",
                    "path": "purchaseMethod"
                }
            },
            "facets": {
                "locationFacet": {
                    "type": "string",
                    "path": "storeLocation",
                }
            }
        }
    }
  }
])
```
