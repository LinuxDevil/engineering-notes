---
notion-id: 975445ad-b9dd-4f4c-b73e-3adcc5883981
---

Data modeling is the process of defining how the data is stored and what relations in among your entities.

We refer to the organization of the data as a schema.

To create your schema, think in your application:

1. What does my application do?
2. What data will I store?
3. How will users access this data
4. What data will be valuable to me ?

<u>**Data that is accessed together should be stored together.**</u>

You can also normalize your data by using database references.

We start with the app in mongodb.

Types of data relationships

![[Screenshot_2023-04-22_at_7.12.39_PM.png]]

**one-to-one
**Where data entity in one set is connected to exactly one data entity in another set.

We can have One-to-One in a single document.

**one-to-many**

A relationshio where a data entity in one set is connected to any number of data entities in another set.

One way you can model them is with nested arrays.

![[Screenshot_2023-04-22_at_7.14.56_PM.png]]

**many-to-many**

A relationship where any number of data entities in one set are connected to any number of data entities in another set.

**Two ways to model relationships**

![[Untitled 34.png]]

![[Screenshot_2023-04-22_at_7.16.53_PM.png]]

**Embedding**
Is where we take related data and insert it into our document.

Embedding is used when you have one-to-many or many-to-many relationships in the data that’s being stored.

Embedding avoids application joins and provides better performance for read operations and it allows developers to update related data in a single write operation.

**Warring:** it can make your document large and make it slow in the read operations, <u>as the documents have to read in memory in FULL, which can result in a slow application performance for your end user.</u>

And continuously adding data without limit creates an unbounded document which is a BSON document that exceed the 16 MB (unbounded means that it can grow infinitely) <u>as when adding a new record, the entire document must be rewritten by mongodb).</u>

<u>**Both large documents and unbounded documents is a schema anti-pattern.**</u>

**Referencing**
Where we refer to documents in another collection in our document.

The referencing saves the _id field of one document in another document as a <u>link</u> between the two.

Referencing is called **Linking** or **data normalization**.

Querying from multiple documents costs extra resources and impact the read performance.

When we create a data model we should avoid

5. Unbounded documents when we use document embedding.
6. Poor query performance.
7. Poor write performance.
8. Too much memory being used.

**Schema design patterns** are guidelines that helps developers plan, organize, and model data.

<u>Common schema anti-patterns:</u>

9. Massive arrays
10. Massive number of collections
11. Bloated documents
12. Unnecessary indexes.
13. Queries without indexes.
14. Data that’s accessed together, but stored in different collections.

You can identify them in Atlas using:

15. Data Explorer.
16. Performance Advisor.
