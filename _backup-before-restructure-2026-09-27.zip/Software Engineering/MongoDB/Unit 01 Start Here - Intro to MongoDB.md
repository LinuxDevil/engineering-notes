---
notion-id: 2be11a57-5819-4696-85fc-6b9a8914da03
---

In this section, we learn how to use the IDE instruqt

We also tackle the db.help() command
