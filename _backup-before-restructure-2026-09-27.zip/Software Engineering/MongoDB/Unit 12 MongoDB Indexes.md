---
notion-id: 65fd8aff-d708-4afd-872a-de3df5407f4e
---
In this unit, you will learn about indexes, how indexes support the efficient execution of queries in MongoDB, the trade-offs associated with using indexes, how to create Single Field and Compound Index, what Multikey indexes are, and how to see if queries are using indexes. Finally, you will learn how to delete an index.

**What indexes are**

A special ordered data structure that store a small portion of data, they point to the document identity and allow you to lookup and access data faster.

Index are ordered and easy to search efficiently.

Without indexes, mongodb will read all documents (collection scan) to match a query and mongodb will sort the result in memory.

with indexes, it only fetch the documents identified by the index based on the query, as it won’t read the whole document.

Every query should use an index.

but it comes with **write** performance cost.

Too many index are not good. delete unnecessary indexes.

Index types:

1. Single field indexes: On a single field
	Creating an index: 
```bash
createIndex({ fieldname: 1}, { unique: true })
// 1 asc index
// unique constraint 
//   specifies that the values are unique
```

    Identify indexes by using getIndexes() it will return a list of used indexes in this collection.

    Determine the indexes being used in a query by using explain() it returns the query plan, in the winning plan is how it execute with the index in stages.
	- The `IXSCAN` stage indicates the query is using an index and what index is being selected.
	- The `COLLSCAN` stage indicates a collection scan is perform, not using any indexes.
	- The `FETCH` stage indicates documents are being read from the collection.
	- The `SORT` stage indicates documents are being sorted in memory.
	- `PROJECTION_COVERED` - All the information needed is returned by the index, no need to fetch from memory

2. Multi-key index operate on arrays, can be created on permitted, sub documents and sub arrays. and can be a single or a compound index.
You can create it by the createIndex(), same as the single Index.
    We can create only one array field per index. Mongodb decompose the array and store each unique value as a index entry. 
    The multi-key need to fetch the document (FETCH stage) after the IXSCAN stage.
![[Screenshot_2023-04-27_at_3.31.33_PM.png]]

3. Compound indexes: combination of multiple indexes
	It supports queries that match on the prefix of the index fields.
	like if the query was 
```bash
db.accounts.createIndex({ active: 1, 
		birthday: -1,
		name: 1 
})
```
    the <u>prefix</u> index here is **active, ** now any query that use active or sort by active can use that index
```bash
db.accounts.find({active: true})
db.accounts.find({name: 'Ali'}, {active: true})
```
    Queries that doesn’t include the prefix index can’t use the compound index, even if they include other indexes
```bash
db.accounts.find({name: 'Ali'},
	 {birthday: ISODate("1998-04-30")}}
```

    Follow this order when creating a compound index:
```bash
Equality, Sort, Range
db.accounts.createIndex({ active: 1,
	birthdate: -1,
	name: 1
})
```
    Equality: So it retrieves fewer documents and reduce query processing time.
    Sort: Index sort eliminates the need for in-memory sorts.
    Range: This should be last to remove any in-memory sort.
    The sort order of the field values in the index matters.
    if we used the projection with the indexed filed, the query executor will run PROJECTION_COVERED and will be faster than queries with no projection.

    Deleting Indexes
    Make sure the index is not being used.
    We can delete any index but not the _id.
```bash
// one index
db.collection.dropIndex(<index>)

// multiple indexes
db.collection.dropIndexes(
	[Optional array of indexes]
)
```
    Recreating and index will take more time and resources.
    We can hide the index to see the effect of it
```bash
db.collection.hideIndex(<index>)
```
    unhiding the index is faster than recreating the index.
