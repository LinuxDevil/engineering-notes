---
notion-id: 2ddf2997-a8d0-4b92-971e-962618b53f47
---

Altas is the comprehensive data platform, at its core is the Database as a service (DBaaS), as atlas will manage the database and its lifecycle for you.

When you deploy your database, it automatically gets replica set (a group of servers that hold your data).
There’s two types of database deployments:

1. Serverless
Scales on demand and charges you for the resources you use.
It’s a great use for applications that sparks activity overtime.
2. Clusters
Is a several mongodb servers working together
	1. Dedicated
Larger and can be customized for high and low and scales automatically
	2. Shared
Smaller and include Free tier 

Atlas includes operational insights and backups with point-in-time restore and online archive.

Atlas search enables you to to write a great search experience in the cloud.
**Atlas Device sync** enables you to keep the data synced between the cloud and mobile.

**Atlas data** lake automatically extract data from the database to your own low price environment.

**Atlas**

**Organizations** allows you to group and define users and teams and grant access to projects

**Projects** allows you to define and organize resources

Atlas CLI

We can use the altlas cli to register 

```bash
altlas auth register
```

then copy the verification code and paste it in the web page

You can setup an atlas in the cli

```bash
atlas setup --clusterName myAtlasClusterEDU 
	--provider AWS 
	--currentIp 
	--skipSampleData 
	--username myAtlasDBUser 
	--password myatlas-001 | 
	tee atlas_cluster_details.txt
```

this step will leave you connected to the sh for mongo

![[Screenshot_2023-04-22_at_5.56.16_PM.png]]


You can load sample data set 

```bash
atlas clusters loadSampleData myAtlasClusterEDU
```