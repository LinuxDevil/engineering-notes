---
notion-id: 662aa979-38b2-4a0d-a12c-6ee53a946365
cover: "[[Supervised vs Unsupervised Machine learning.jpeg]]"
---

> The more runs the better (More time to learn)

Types of machine learning

- Supervised Learning (Mostly used)
- Unsupervised Learning
- Recommendation System
- Reinforcement learning

## Supervised Learning

Algorithms that learn from examples that provides correct answers

Maps the Input to output label 

For example if the input was

| Input (X) | Output (Y) | Application |
| --- | --- | --- |
| Email | Spam | Spam filter |
| Image, Radar info | position of other cars | Self-driving cars |
| Ad, user info | Click (0/1) | Online advertising |

Types of supervised learning

- Regression
- Classification

**Regression **→ Predict a number from infinitely many possible outputs

![[image 1.png]]


**Classification **→ Predict classes/categories from a selected range of outputs (Images, numbers, string, …etc) What it makes it different from regression is that it works with a small number or possibilities.

![[image 2.png]]


## Unsupervised Learning

Algorithms that learns from data without labeling the right answer,

So you need to find structure in the unlabeled data. (Figure it out yourself).

![[image 3.png]]


Types of unsupervised learning

- Clustering


**Clustering **→  (Cluster is a group of data that are together).

![[image 4.png]]

Example is google news

![[image 5.png]]

