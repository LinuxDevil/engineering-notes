---
notion-id: ea00cbdf-6e59-4269-9c0c-ffd01c4b42ee
cover: "[[Step 2 Building Dataset.jpeg]]"
---
*Working with data is perhaps the most overlooked—yet most important—step of the machine learning process.*

![[Screenshot_2023-03-29_at_12.50.44_AM.png]]

Building the dataset that can be used to solve your ML-based problem

Working with data:
![[Screenshot_2023-03-29_at_12.52.44_AM.png]]
    There are 4 ways to break the data for ML
    **Data collection **
        Gather data related to the problem (Labeled, Unlabeled)
        Data collection can be as straightforward as running the appropriate SQL queries or as complicated as building custom web scraper applications to collect data for your project. You might even have to run a model over your data to generate needed labels. Here is the fundamental question:
        *Does the data you've collected match the machine learning task and problem you have defined?*
    **Data inspection**
        Explore your dataset, look for
		- Outliers
		- Missing or incomplete data
		- Data that needs to be transformed or preprocessed so it's in the correct format to be used by your model
    **Summary Statistics**
        Now that you have some data in hand, it is a good best practice to check that your data is in line with the underlying assumptions of the machine learning model that you chose.
        Using statistical tools, you can calculate things like the mean, inner-quartile range (IQR), and standard deviation. These tools can give you insights into the scope, scale, and shape of a dataset
        Summary statics can identify: 
		- Trends in the data
		- Scale of the data
		- Shape of the data

    **Data Visualization**
        Great data visualizations communicate the finds to a project stakeholder


**One**

You learned that having good data is key to being able to successfully answer the problem you have defined in your machine learning problem.

**Two**

To build a good dataset, there are four key aspects to be considered when working with your data. First, you need to collect the data. Second, you should inspect your data to check for outliers, missing or incomplete values, and to see if any kind of data reformatting is required. Third, you should use summary statistics to understand the scope, scale, and shape of the dataset. Finally, you should use data visualizations to check for outliers, and to see trends in your data.

**Key terms from this lesson:**

- **Impute** is a common term referring to different statistical tools that can be used to calculate missing values from your dataset.
- **Outliers** are data points that are significantly different from other date in the same sample.

[https://scikit-learn.org/stable/auto_examples/applications/plot_outlier_detection_wine.html#sphx-glr-auto-examples-applications-plot-outlier-detection-wine-py](https://scikit-learn.org/stable/auto_examples/applications/plot_outlier_detection_wine.html#sphx-glr-auto-examples-applications-plot-outlier-detection-wine-py)
