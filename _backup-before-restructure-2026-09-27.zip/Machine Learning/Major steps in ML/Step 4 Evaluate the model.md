---
notion-id: f3d5b381-acc4-4e24-b9cf-8bc2187399ef
cover: "[[Step 4 Evaluate the model.jpeg]]"
---
*After you have collected your data and trained a model, you can start to evaluate how well your model is performing. The metrics used for evaluation are likely to be very specific to the problem you defined. As you grow in your understanding of machine learning, you will be able to explore a wide variety of metrics that can enable you to evaluate effectively.*

Evaluating your model
    We can evaluate the model based on the:
    **Model accuracy**: How often your model predicts the correct species
    Metrics are tailored to use-case:
		1. **Precision**
Precision is a metric used to measure the **accuracy** of a classifier when it predicts positive instances. It is calculated by dividing the number of true positive predictions by the total number of positive predictions.
Example: Consider a binary classification problem where we want to predict whether a person is diabetic or not based on some input features. Suppose our model predicted that 100 people are diabetic, out of which 80 are actually diabetic. Then the precision of our model would be 80/100 = 0.8.
		2. **Recall**
Recall is a metric used to measure the **sensitivity** of a classifier when it correctly identifies positive instances. It is calculated by dividing the number of true positive predictions by the total number of positive instances in the dataset.
Example: Suppose our model predicted that 100 people are diabetic, out of which 80 are actually diabetic. But there are a total of 120 diabetic people in the dataset. Then the recall of our model would be 80/120 = 0.67.
		3. **Log Loss
**Let's say you're trying to predict how likely a customer is to buy either a jacket or t-shirt.
            Log loss could be used to understand your model's **uncertainty** about a given prediction. In a single instance, your model could predict with 5% certainty that a customer is going to buy a t-shirt. In another instance, your model could predict with 80% certainty that a customer is going to buy a t-shirt. Log loss enables you to measure how strongly the model believes that its prediction is accurate.
            In both cases, the model predicts that a customer will buy a t-shirt, but the model's certainty about that prediction can change.
		4. **Mean Absolute Error
**MAE is a metric used to measure the **average** difference between the predicted and actual values in a regression model. It is calculated by taking the absolute difference between the predicted and actual values, and then taking the mean of all these differences.
Example: Consider a regression problem where we want to predict the price of a house based on its size. Suppose our model predicted the price of 10 houses, and the actual prices of those houses were $200,000, $250,000, $300,000, $350,000, $400,000, $450,000, $500,000, $550,000, $600,000, and $650,000. The predicted prices of those houses were $180,000, $240,000, $290,000, $360,000, $410,000, $480,000, $510,000, $560,000, $610,000, and $640,000. Then the MAE of our model would be (|200,000-180,000| + |250,000-240,000| + ... + |650,000-640,000|) / 10 = $15,000.
		5. **Hinge Loss
**Hinge loss is a metric used to evaluate the **performance** of a binary classification model. It is defined as the maximum of zero and the difference between the true label and the predicted score multiplied by the opposite of the true label.
Example: Consider a binary classification problem where we want to predict whether a credit card transaction is fraudulent or not based on some input features. Suppose our model predicted a score of 2 for a fraudulent transaction and a score of -1 for a non-fraudulent transaction. The hinge loss for this example would be max(0, 1 - 2 * 1) + max(0, 1 + 1 * (-1)) = 1 + 0 = 1.
		6. **R^2
**R^2 is a metric used to evaluate the **goodness** of fit of a regression model. It is defined as the proportion of the variance in the dependent variable that is predictable from the independent variable.
Example: Consider a regression problem where we want to predict the price of a house based on its size. Suppose our model predicted the price of 10 houses, and the actual prices of those houses were $200,000, $250,000, $300,000, $350,000, $400,000, $450,000, $500,000, $550,000, $600,000, and $650,000. The predicted prices of those houses were $180,000, $240,000, $290,000, $360,000, $410,000, $480,000, $510,000, $560,000, $610,000, and $640,000. The R-squared value of our model would be calculated based on how much variance of the actual prices is explained by the predicted prices.
		7. **Quantile Loss
**Quantile loss is a metric used to evaluate the **accuracy** of a quantile regression model. It measures the difference between the predicted quantile and the actual value at a certain quantile level.
Example: Consider a quantile regression problem where we want to predict the 0.5 quantile (median) of the housing prices based on its size. Suppose our model predicted the median price of 10 houses, and the actual median prices of those houses were $250,000, $270,000, $300,000, $320,000, $360,000, $400,000, $450,000, $500,000, $550,000, and $600,000. The predicted median prices of those houses were $240,000, $260,000, $310,000, $330,000, $370,000, $410,000, $460,000, $520,000, $560,000, and $610,000. The quantile loss would be the average of the absolute differences between the predicted and actual values at the 0.5 quantile level.
		8. **F1 Score
**F1 score is a metric used to evaluate the **performance** of a binary classification model. It is the harmonic mean of precision and recall.
Example: Consider a binary classification problem where we want to predict whether a person has a disease or not based on some input features. Suppose our model predicted that 100 people have the disease, out of which 80 actually have the disease. The F1 score of our model would be calculated based on the precision and recall values.
		9. **KL Divergence
**KL Divergence is a metric used to evaluate the **difference** between two probability distributions. It measures the amount of information lost when one probability distribution is used to approximate another probability distribution.
