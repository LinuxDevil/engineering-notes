---
notion-id: 616360ed-37bb-4aba-8d9c-a2fc92db8a1c
cover: "[[Step 5 Use the model.jpeg]]"
---
Model inference: Use your model to solve real problems, always monitor the results.

Once you have trained your model, have evaluated its effectiveness, and are satisfied with the results, you're ready to generate predictions on real-world problems using unseen data in the field. In machine learning, this process is often called **inference.**

![[Untitled 3.png]]

Even after you deploy your model, you're always monitoring to make sure your model is producing the kinds of results that you expect. There may be times where you reinvestigate the data, modify some of the parameters in your model training algorithm, or even change the model type used for training.

**One**

*Solving problems using machine learning is an evolving and iterative process.*

**Two**

*To solve a problem successfully in machine learning finding high quality data is essential.*

**Three**

*To evaluate models, you often use statistical metrics. The metrics you choose are tailored to a specific use case.*