---
notion-id: 21d93733-8bf0-4f40-813a-b61509c13cd6
cover: "[[Step 3 Train the model.png]]"
---
*Modeling training is a process whereby the model's parameters are iteratively updated to minimize some loss function that has been previously defined.*


We have 3 types of models: 
    **Linear Models**
        One of the most common models covered in introductory coursework, linear models simply describe the relationship between a set of input numbers and a set of output numbers through a linear function (think of *y = mx + b* or a line on a *x vs y chart*). Classification tasks often use a strongly related logistic model, which adds an additional transformation mapping the output of the linear function to the range [0, 1], interpreted as “probability of being in the target class.” Linear models are fast to train and give you a great baseline against which to compare more complex models. A lot of media buzz is given to more complex models, but for most new problems, consider starting with a simple model.
    **Tree-based models**
        Tree-based models are probably the second most common model type covered in introductory coursework. They learn to categorize or regress by building an extremely large structure of nested *if/else* blocks, splitting the world into different regions at each *if/else* block. Training determines exactly where these splits happen and what value is assigned at each leaf region. For example, if you’re trying to determine if a light sensor is in sunlight or shadow, you might train tree of depth 1 with the final learned configuration being something like *if (sensor_value > 0.698)*, *then return 1; else return 0;*. The tree-based model XGBoost is commonly used as an off-the-shelf implementation for this kind of model and includes enhancements beyond what is discussed here. Try tree-based models to quickly get a baseline before moving on to more complex models.
    **Deep learning models**
        Extremely popular and powerful, deep learning is a modern approach that is based around a conceptual model of how the human brain functions. The model (also called a neural network) is composed of collections of neurons (very simple computational units) connected together by weights (mathematical representations of how much information thst is allowed to flow from one neuron to the next). The process of training involves finding values for each weight. Various neural network structures have been determined for modeling different kinds of problems or processing different kinds of data.A short (but not complete!) list of noteworthy examples includes:
		- **FFNN**: The most straightforward way of structuring a neural network, the Feed Forward Neural Network (FFNN) structures neurons in a series of layers, with each neuron in a layer containing *weights* to all neurons in the previous layer.
		- **CNN**: Convolutional Neural Networks (CNN) represent nested filters over grid-organized data. They are by far the most commonly used type of model when processing images.
		- **RNN/LSTM**: Recurrent Neural Networks (RNN) and the related Long Short-Term Memory (LSTM) model types are structured to effectively represent for loops in traditional computing, collecting state while iterating over some object. They can be used for processing sequences of data.
		- **Transformer**: A more modern replacement for RNN/LSTMs, the transformer architecture enables training over larger datasets involving sequences of data.
    **Machine learning using Python libraries**
	- For more classical models (linear, tree-based) as well as a set of common ML-related tools, take a look at *scikit-learn*. The web documentation for this library is also organized for those getting familiar with space and can be a great place to get familiar with some extremely useful tools and techniques.
	- For deep learning, *mxnet*, *tensorflow*, and *pytorch* are the three most common libraries. For the purposes of the majority of machine learning needs, each of these is feature-paired and equivalent.


**The first step in model training is to randomly split the dataset.**
    This allows you to keep some data hidden during training, so that the data can be used to evaluate your model before you put it into production. Specifically, you do this to test against the bias-variance trade-off. If you're interested in learning more, see the optional **Extended learning** section.
    Before you begin training your model you should split your dataset
	- Majority will be held in the training dataset (80%)
		- *Training dataset*: The data on which the model will be trained. Most of your data will be here. Many developers estimate about 80%.
	- The test dataset will be used during model evaluation
		- *Test dataset*: The data withheld from the model during training, which is used to test how well your model will generalize to new data.

What does a model training algorithm actually do?
    Iteratively update **model parameters** to minimize some **loss function**.
	- Model parameters (Weights, Bioses)
		Configuration that changes how the model behaves
		They are trained in a slowly changing model parameters
Model parameters are settings or configurations that the training algorithm can update to change how the model behaves. Depending on the context, you’ll also hear other specific terms used to describe model parameters such as weights and biases. Weights, which are values that change as the model learns, are more specific to neural networks.
	- Loss function
		Used to measure the model distance from the required goal (how close is the model to its goal)
		For example the loss function = *( Predicted snow cons sold - how many snow cones got sold ) which is seek to minimize.
*A loss function is used to codify the model’s distance from a goal. For example, if you were trying to predict the number of snow cone sales based on the day’s weather, you would care about making predictions that are as accurate as possible. So you might define a loss function to be “the average distance between your model’s predicted number of snow cone sales and the correct number.” You can see in the snow cone example; this is the difference between the two purple dots.
    ## Putting it all together
    The end-to-end training process is:
	- Feed the training data into the model.
	- Compute the loss function on the results.
	- Update the model parameters in a direction that reduces loss.

    How do i actually implement model training ?
        You can implement them from scratch, but the idea is to use one that is already there.
    How do i determine which model to use? (Model selection)
        Trial and error ya habibi
    Training algorithm hyper-parameters
        They can’t be changed when the model is training and can highly effect how quickly and reliably a model is trained 
		1. Practitioners often use machine learning frameworks that already have working implementations of models and model training algorithms. You could implement these from scratch, but you probably won't need to do so unless you’re developing new models or algorithms.
		2. Practitioners use a process called model selection to determine which model or models to use. The list of established models is constantly growing, and even seasoned machine learning practitioners try many different types of models while solving a problem with machine learning.
		3. *Hyper-parameters* are settings on the model that are not changed during training, but can affect how quickly or how reliably the model trains, such as the number of clusters the model should identify.
		4. Be prepared to iterate.

    **One**
    The model training algorithm iteratively updates a model's parameters to minimize some loss function.
    **Two**
    During model training, the training data is fed into the model, and then the loss function is computed based on the results. The model parameters are then updated in a direction that reduces loss. You will continue to cycle through these steps until your reach a predefined stop condition.
    **Key terms from this lesson:**
	- **Hyperparameters** are settings on the model that are not changed during training but can affect how quickly or how reliably the model trains, such as the number of clusters the model should identify.
	- A **loss function** is used to codify the model’s distance from this goal.
	- **Training dataset**: The data on which the model will be trained. Most of your data will be here.
	- **Test dataset**: The data withheld from the model during training, which is used to test how well your model will generalize to new data.
	- **Model parameters** are settings or configurations the training algorithm can update to change how the model behaves.