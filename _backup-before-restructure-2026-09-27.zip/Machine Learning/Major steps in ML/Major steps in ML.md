---
notion-id: a315a993-0ab6-4105-83d2-4ea1011c7e1d
cover: "[[Major steps in ML.jpeg]]"
---
![[Untitled 2.png]]

These steps are iterative. In practice, that means that at each step along the process, you review how the process is going. Are things operating as you expected? If not, go back and revisit your current step or previous steps to try and identify the breakdown.

**Covariance** is a statistical measure that quantifies the degree to which two variables in a dataset change together. More specifically, covariance measures the joint variability of two variables.

If two variables have a positive covariance, it means that they tend to increase or decrease together. For example, height and weight of a person may have a positive covariance, because taller people tend to be heavier. On the other hand, if two variables have a negative covariance, it means that they tend to vary in opposite directions. For example, hours of exercise per week and body weight may have a negative covariance, because people who exercise more tend to have lower body weight.

The magnitude of covariance depends on the scale of the variables, and it is not necessarily bounded between -1 and 1. Therefore, covariance is often normalized by dividing it by the product of the standard deviations of the two variables, which gives rise to the correlation coefficient. The correlation coefficient ranges between -1 and 1, and it measures the strength and direction of the linear relationship between two variables.

**Minimum Covariance Determinant** (MCD) is a statistical method used to estimate the parameters of a multivariate normal distribution when the data contains outliers. In other words, it is a robust estimator of the covariance matrix of a dataset that is able to handle the presence of outliers.

The MCD is based on the idea of finding the smallest subset of the data that has a covariance matrix with a small determinant. This subset is known as the Minimum Covariance Determinant set. The MCD estimator then computes the covariance matrix based on this subset, which is less sensitive to outliers than the traditional maximum likelihood estimator.

The MCD is widely used in applications where data outliers can significantly affect the results, such as in finance, engineering, and geology. However, it is important to note that the MCD assumes that the data is normally distributed, and may not be appropriate for non-normal data distributions.

**In statistics, deviation** is a measure of how much a data point differs from the average or typical value of a dataset. The deviation of a data point xi from the mean of a dataset x̄ is given by:

```javascript
deviation of xi = xi - x̄
```

The deviation of a data point can be positive or negative, depending on whether the data point is above or below the mean of the dataset.

**The mean**, or average, of a dataset is a measure of the central tendency of the data. It is computed by taking the sum of all the data points and dividing by the number of data points. The mean of a dataset x with n observations is given by:

```javascript
x̄ = (x1 + x2 + ... + xn) / n
```

Now, let's look at the formula for **empirical covariance**. Suppose we have a dataset with n observations of two variables x and y. To compute the empirical covariance between x and y, we first calculate the deviations of each observation of x and y from their respective means:

```javascript
deviation of xi = xi - x̄
deviation of yi = yi - ȳ
```

Then, we multiply these deviations for each observation and take the average over all n observations:

```javascript
Cov(x,y) = 1/n * Σ(xi - x̄)(yi - ȳ)
```

This gives us the empirical covariance between x and y, which measures how the two variables vary together in the sample.

**Empirical covariance** is a statistical measure that estimates the covariance between two variables based on a sample of data. It is sometimes also called sample covariance.

Empirical covariance is computed by taking the mean of the product of the deviations of each variable from its respective mean. More specifically, if we have a dataset with n observations and two variables x and y, the empirical covariance between x and y is given by:

```javascript
Cov(x,y) = 1/n * Σ(xi - x̄)(yi - ȳ)
```

where xi and yi are the i-th observations of x and y, x̄ and ȳ are the sample means of x and y, and Σ denotes the sum of the terms inside the parentheses over all n observations.

Empirical covariance is an important measure in statistics because it is used to estimate the parameters of a multivariate normal distribution, which is a commonly used probability distribution in statistical modeling. It is also used in machine learning and data analysis to measure the relationship between two variables and to detect patterns in the data.

[[Step 1 Define The problem]]

[[Step 2 Building Dataset]]

[[Step 3 Train the model]]

[[Step 4 Evaluate the model]]

[[Step 5 Use the model]]