---
notion-id: 33c9bbce-e83a-48db-9acf-d265c2b8dde7
cover: "[[Step 1 Define The problem.jpeg]]"
---

- **Clustering** is an unsupervised learning task that helps to determine if there are any naturally occurring groupings in the data.
- A **categorical label** has a discrete set of possible values, such as "is a cat" and "is not a cat."
- A **continuous (regression) label** does not have a discrete set of possible values, which means there are potentially an unlimited number of possibilities.
- **Discrete** is a term taken from statistics referring to an outcome that takes only a finite number of values (such as days of the week).
- A **label** refers to data that already contains the solution.
- Using **unlabeled data** means you don't need to provide the model with any kind of label or solution while the model is being trained.


**How do you start a machine learning task?**

Step 1: Define the problem:
	- Be very specific
	- Identify the machine learning task

**What exactly is a machine learning task?**

The presence or absence of labeling in your data is often used to identify a machine learning task.

![[Screenshot_2023-03-29_at_12.31.50_AM.png]]

All model training algorithms, and the model themselves take data as their input. their output can be very different and are classified into a few different groups, based on the task they are designed to solve.
    Step A: Define a very specific task:
        As the question arises, “How do i increase sales?” It’s a valid question, but it is the complete opposite of a very specific task. the ML practitioner might attempt to answer that question like: does adding a 0.5 charge for organic flavors in your snow cone increase the sales of snow cones ?
    Step B: Identify the ML task we might use to solve the problem (to better understand the data you need for a project)

**Supervised Learning**
    A task is supervised if you are using labeled data. We use the term labeled to refer to data that already contains the solutions, called *labels.*
    Labeled Data: Data for which you already know the target answer is called labeled data.

![[Screenshot_2023-03-29_at_12.38.22_AM.png]]
    **Classification (Categorial label) like for example seeing only cat images .**
A **categorical** label has a discrete set of possible values. In a machine learning problem in which you want to identify the type of flower based on a picture, you would train your model using images that have been labeled with the categories of the flower that you want to identify. Furthermore, when you work with categorical labels, you often carry out classification tasks, which are part of the supervised learning family.
    **Continuous label (Regression) like predict how many snow cons got sold in a day (number)**
        A **continuous** (regression) label does not have a discrete set of possible values, which often means you are working with numerical data. In the snow cone sales example, we are trying to predict the number of snow cones sold. Here, our label is a number that could, in theory, be any value.

**Unsupervised Learning**
    A task is considered to be unsupervised if you are using *unlabeled data*
. This means you don't need to provide the model with any kind of label or solution while the model is being trained.
    Unlabeled data: Data that can be used for training, which does not contain the labels or solutions.
![[Screenshot_2023-03-29_at_12.38.59_AM.png]]
    Clustering:  to see if you don’t have labels and want to extract information based on the block of data, like for example see the micro genre from a book description.
    Clustering helps to determine if there are any naturally occurring groupings in the data.
    **Example: Identifying book micro-genres with unsupervised learning**
    Imagine that you work for a company that recommends books to readers.The assumption is that you are fairly confident that micro-genres exist, and that there is one called *Teen Vampire Romance*. However, you don’t know which micro-genres exist specifically, so you can't use **supervised learning** techniques.This is where the **unsupervised learning** clustering technique might be able to detect some groupings in the data. The words and phrases used in a book's description might provide some guidance on its micro-genre.


	- **Clustering**, an unsupervised learning task that helps to determine if there are any naturally occurring groupings in the data.
	- A **categorical label** has a discrete set of possible values, such as "is a cat" and "is not a cat".
	- A **continuous (regression) label** does not have a discrete set of possible values, which means there are potentially possibly an unlimited number of possibilities.
	- **Discrete**: A term taken from statistics referring to an outcome taking on only a finite number of values (such as days of the week).
	- A **label** refers to data that already contains the solution.
	- Using **unlabeled data means you don't need to provide the model with any kind of label or solution while the model is being trained.**