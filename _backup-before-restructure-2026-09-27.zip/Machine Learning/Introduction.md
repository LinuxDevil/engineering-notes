---
notion-id: c7c9cef0-3392-4108-9258-0e6fd4a1e1c6
cover: "[[Introduction.jpeg]]"
---

What is machine learning ?
    It is a modern software development technique, and a type of AI, that enables computers to solve problems by using real-world examples data. It allows computers to automatically learn and improve from experience without being explicitly programmed to do so.
    It is a part of the broader field of AI,  this field is concerned with the capability of machines to perform activities using human-like intelligence.

![[Screenshot_2023-03-28_at_8.25.39_PM.png]]

ML has different kind of tasks/techniques: 

1. Supervised learning: every training sample from the dataset has a corresponding label or output value associated with it. As a result the algorithm learns to predict labels or output values.
2. Unsupervised learning: there’s no labels for the training data, the ML algorithm tries to learn the underlying patterns or distributions that govern the data.
3. Reinforcement learning: like training your pet, the algorithm figures out which actions to take in situations to maximize a reward (number reward) on the way to reaching a specific goal. 

Traditional Vs Machine learning in problem solving:
    In traditional problem-solving with software the person analyzes problem and engineer a solution in code to solve that problem, for many real-world problems this process can be laborious or even impossible in some cases; because a correct solution would need to take a vast number of edge cases into consideration
    For example imagine the task of writing a solution to detect if a cat is present in an image. Solving it traditionally, would require a lot of attention to details like varying lighting, cats and poses that cats can be in.
    In machine learning, the problem solver abstracts away part of their solution as flexible component called MODEL, and uses a special solution called model training algorithm to adjust that model to real-world data. the result is trained model which can be use to predict the outcomes that are not part of the dataset it used to train it.
    In a way, ml automates some of the statistical reasoning and pattern matching the problem solver would traditionally do. 
![[Untitled.png]]
