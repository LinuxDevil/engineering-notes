---
notion-id: 5b96943b-d352-4a52-96ea-e3701042b353
---

AWS 1. [Introduction to machine learning](https://student.deepracer.com/learn/85a3a216-703b-40c8-ad70-374767eba381) course

[[Concepts]]

[[Machine Learning/Introduction|Introduction]]

[[Components of ML]]

[[Major steps in ML]]

[[Case Studies that use ML]]

— Coursera Deep ai - Introduction to Machine Learning

[[Supervised vs Unsupervised Machine learning]]