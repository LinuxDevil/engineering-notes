---
notion-id: c31b8cf3-4f4d-4f90-a85a-2e7fd33f1059
cover: "[[Components of ML.jpeg]]"
---

Nearly all tasks solved with machine learning involve three primary components:
	1. ML model
block of code or framework that can be modified to solve different but related problems based on the data provided.
*A model is an extremely generic program (or block of code), made specific by the data used to train it. It is used to solve different problems.*
	2. Model training algorithm
An iterative process that 
		1. determine what changes need to be made 
		2. make them to the model so it shapes it as required
		3. repeat the process
	3. Model inference algorithm 
Process to use the trained model to generate prediction or solve problem

The machine learning stages can be imagined like crafting a teapot from a clay

![[Untitled 1.png]]

1. First, you start with a block of raw clay. At this stage, the clay can be molded into many different forms and be used to serve many different purposes. You decide to use this lump of clay to make a teapot.
2. So how do you create this teapot? You inspect and analyze the raw clay and decide how to change it to make it look more like the teapot you have in mind.
3. Next, you mold the clay to make it look more like the teapot that is your goal.

