---
notion-id: 69d8239d-a766-427d-b644-3ce0f4f0f97e
cover: "[[Case Studies that use ML.jpeg]]"
---
Through the remainder of the lesson, we will walk through three different case studies. In each example, you will see how machine learning can be used to solve real-world problems.

Supervised learning

- Using machine learning to predict housing prices in a neighborhood, based on lot size and the number of bedrooms.

Unsupervised learning

- Using machine learning to isolate micro-genres of books by analyzing the wording on the back cover description.

Deep neural network

- While this type of task is beyond the scope of this lesson, we wanted to show you the power and versatility of modern machine learning. You will see how it can be used to analyze raw images from lab video footage from security cameras, trying to detect chemical spills.

First, we’ll start with the supervised learning, predicting home prices

[[Example 1 Predicting Home Prices]]

Second we’ll go to unsupervised learning and try to 

[[Example 2 Micro-genre Book Genre]]

Third, we’ll jump into deep neural network, and we’ll try to detect chemical spills in a lab

[[Example 3 Detecting Spills]]

 