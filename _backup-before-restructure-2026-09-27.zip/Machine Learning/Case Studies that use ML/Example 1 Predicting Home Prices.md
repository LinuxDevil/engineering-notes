---
notion-id: 95bfeca4-2b4b-4f17-9c30-77a72e0a1a4a
cover: "[[Example 1 Predicting Home Prices.jpeg]]"
---
House price prediction is one of the most common examples used to introduce machine learning.

Traditionally, real estate appraisers use many quantifiable details about a home (such as number of rooms, lot size, and year of construction) to help them estimate the value of a house.

You detect this relationship and believe that you could use machine learning to predict home prices.

Traditionally, real estate appraisers use many quantifiable details about a home (such as number of rooms, lot size, and year of construction) to help them estimate the value of a house.You detect this relationship and believe that you could use machine learning to predict home prices.

![[Untitled 4.png]]

Step 1: Define the problem:
    *Can we estimate the price of a house based on lot size or the number of bedrooms?*
    Predicting home prices for my neighbourhood, and because we have 
    Because you can get the accurate sold number for houses or think that you can accurately generate the number, you are working with supervised learning task, and because you are working with continues numeric values this is a regression task.
![[Untitled 5.png]]
    You access the sale prices for recently sold homes or have them appraised. Since you have this data, this is a supervised learning task. You want to predict a continuous numeric value, so this task is also a regression task.

Step 2: Build the dataset:
    Dataset: 
		- Collect the data: You collect numerous examples of homes sold in your neighborhood within the past year, and pay a real estate appraiser to appraise the homes whose selling price is not known.
		- Explore the data: You confirm that all of your data is numerical because most machine learning models operate on sequences of numbers. If there is textual data, you need to transform it into numbers.
		- Clean the data: Look for things such as missing information or outliers, such as the 10-room mansion. You can use several techniques to handle outliers, but you can also just remove them from your dataset.
		- Visualization
		- Split into training and testing the data: Prior to actually training your model, you need to split your data. The standard practice is to put 80% of your dataset into a training dataset and 20% into a test dataset.


Step 3: Train the model
    Dataset: Collected explored, cleaned and split
Model:
		- Linear model, single input parameter (line)
			As you see in the preceding chart, when lot size increases, home values increase too. This relationship is simple enough that a linear model can be used to represent this relationship.A linear model across a single input variable can be represented as a line. It becomes a plane for two variables, and then a hyperplane for more than two variables. The intuition, as a line with a constant slope, doesn't change.
		- ML library


Step 4: Evaluation
	- Root mean square (RMS): Average error across the dataset
evaluation metrics in a regression scenario is called *root mean square*
 or <u>***RMS***</u>
. The math is beyond the scope of this lesson, but RMS can be thought of roughly as the "average error" across your test dataset, so you want this value to be low.
![[Untitled 6.png]]
        In the following chart, you can see where the data points are in relation to the blue line. You want the data points to be as close to the "average" line as possible, which would mean less net error.You compute the root mean square between your model’s prediction for a data point in your test dataset and the true value from your data. This actual calculation is beyond the scope of this lesson, but it's good to understand the process at a high level.
![[Untitled 7.png]]
	- Manual threshold check
		**Interpreting Results**
		In general, as your model improves, you see a better RMS result. You may still not be confident about whether the specific value you’ve computed is good or bad.Many machine learning engineers manually count how many predictions were off by a threshold (for example, $50,000 in this house pricing problem) to help determine and verify the model's accuracy.

Step 5: Use the model:
![[Screenshot_2023-03-29_at_11.12.48_PM.png]]
	- Inference: Try your model with real data



In this example, you saw how you can use machine learning to help predict home prices.

**One**

Solving problems using machine learning is an evolving and iterative process.

**Two**

To solve a problem successfully in machine learning, finding high quality data is essential.

**Three**

To evaluate models, you often use statistical metrics. The metrics you choose are tailored to a specific use case.

**Terminology**

- **Regression:** A common task in supervised machine learning used to understand the relationship between multiple variables from a dataset.
- **Continuous:** Floating-point values with an infinite range of possible values. This is the opposite of categorical or discrete values, which take on a limited number of possible values.
- **Hyperplane:** A mathematical term for a surface that contains more than two planes
- **Plane:** A mathematical term for a flat surface (like a piece of paper) on which two points can be joined by drawing a straight line.

[https://scikit-learn.org/stable/auto_examples/linear_model/plot_ols.html#sphx-glr-auto-examples-linear-model-plot-ols-py](https://scikit-learn.org/stable/auto_examples/linear_model/plot_ols.html#sphx-glr-auto-examples-linear-model-plot-ols-py)
