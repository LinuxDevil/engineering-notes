---
notion-id: bb7d4574-c083-45c2-86df-d3cd9b60a380
cover: "[[Example 3 Detecting Spills.jpeg]]"
---
In the previous two examples, we used classical methods like linear models and k-means to solve machine learning tasks. In this example, we’ll use a more modern model type.

**Note** *This example uses a neural network. The algorithm for how a neural network works is beyond the scope of this lesson. However, there is still value in seeing how machine learning applies, in this case.*

**Step 1: Defining the problem**

Imagine you run a company that offers specialized on-site janitorial services. One client - an industrial chemical plant - requires a fast response for spills and other health hazards. You realize if you could *automatically* detect spills using the plant's surveillance system, you could mobilize your janitorial team faster.Machine learning could be a valuable tool to solve this problem.

![[Untitled 10.png]]

**Choosing a model**

As shown in the image above, your goal will be to predict if each image belongs to one of the following classes:

- Contains spill
- Does not contain spill

![[Untitled 11.png]]

**Step 2: Building a dataset**

**Collecting**

- Using historical data, as well as safely staged spills, quickly build a collection of images that contain both spills and non-spills in multiple lighting conditions and environments.

**Exploring and cleaning**

- Go through all of the photos to ensure that the spill is clearly in the shot. There are Python tools and other techniques available to improve image quality, which you can use later if you determine that you need to iterate.

**Data vectorization (converting to numbers)**

- Many models require numerical data, so you must transform all of your image data needs to be transformed into a numerical format. Python tools can help you do this automatically.
- In the following image, you can see how each pixel in the image immediately below can be represented in the image beneath it using a number between 0 and 1, with 0 being completely black and 1 being completely white.

![[Untitled 12.png]]

![[Untitled 13.png]]

**Split the data**

- Split your image data into a training dataset and a test dataset.


**Step 3: Model Training**

Traditionally, solving this problem would require hand-engineering features on top of the underlying pixels (for example, locations of prominent edges and corners in the image), and then training a model on these features.Today, deep neural networks are the most common tool used for solving this kind of problem. Many deep neural network models are structured to learn the features on top of the underlying pixels so you don’t have to learn them. You’ll have a chance to take a deeper look at this in the next lesson, so we’ll keep things high-level for now.

**CNN (convolutional neural network)**

Neural networks are beyond the scope of this lesson, but you can think of them as a collection of very simple models connected together. These simple models are called *neurons*, and the connections between these models are trainable model parameters called *weights*.Convolutional neural networks are a special type of neural network that is particularly good at processing images.

**Step 4: Model evaluation**

As you saw in the last example, there are many different statistical metrics that you can use to evaluate your model. As you gain more experience in machine learning, you will learn how to research which metrics can help you evaluate your model most effectively. Here's a list of common metrics:

- Accuracy
- Confusion matrix
- F1 score
- False positive rate
- False negative rate
- Log loss
- Negative predictive value
- Precession
- Recall
- ROC Curve
- Specificity

In cases such as this, accuracy might not be the best evaluation mechanism.**Why not?** The model will see the *does not contain spill'* class almost all the time, so any model that just predicts *no spill* most of the time will seem pretty accurate.

What you really care about is an evaluation tool that rarely misses a real spill.After doing some internet sleuthing, you realize this is a common problem and that *precision* and *recall* will be effective. Think of *precision* as answering the question, "Of all predictions of a spill, how many were right?" and *recall* as answering the question, "Of all actual spills, how many did we detect?"

Manual evaluation plays an important role. If you are unsure if your staged spills are sufficiently realistic compared to actual spills, you can get a better sense how well your model performs with actual spills by finding additional examples from historical records. This allows you to confirm that your model is performing satisfactorily.

**Step 5: Model inference**

The model can be deployed on a system that enables you to run machine learning workloads such as AWS Panorama.Thankfully, most of the time, the results will be from the class *does not contain spill*.

![[Untitled 14.png]]

But, when the class *contains spill'* is detected, a simple paging system could alert the team to respond.

![[Untitled 15.png]]

In this example, you saw how you can use machine learning to help detect spills in a work environment. This example also used a modern machine learning technique called a convolutional neural network (CNN).Here is summary of key moments from the lesson that you just finished.

**One**

For some applications of machine learning, you need to use more complicated techniques to solve the problem. While modern neural networks are a powerful tool, don’t forget their cost in terms of being easily explained.

**Two**

High quality data once again was very important to the success of this application, to the point where even staging some fake data was required. Once again, the process of data vectorization was required so it was important to convert the images into numbers so that they could be used by the neural network.
    **Three**
    During model inference you continued to inspect the predictions for accuracy. It is especially important in this case because you created some fake data to use when training your model.

**Terminology**

**Neural networks:** a collection of very simple models connected together.

- These simple models are called **neurons**.
- The connections between these models are trainable model parameters called **weights**.

**Convolutional neural networks(CNN)**: a special type of neural network particularly good at processing images.