---
notion-id: 282cbd79-82bc-481b-9e27-51e598e3a8af
cover: "[[Example 2 Micro-genre Book Genre.jpeg]]"
---
In this video, you saw how the machine learning process can be applied to an unsupervised machine learning task that uses book description text to identify different micro-genres.Additionally, this case study uses the same 5 steps of machine learning that were outlined in the previous case study and lesson. In the follow sections, you can review each of the 5 steps and how they apply to this specific case study.

You do editorial work for a book recommendation company, and you want to write an article on the largest book trends of the year. You believe that a trend called "micro-genres" exists, and you have confidence that you can use the book description text to identify these micro-genres.

By using an unsupervised machine learning technique called *clustering*, you can test your hypothesis that the book description text can be used to identify these "hidden" micro-genres.

**Step 1: identify the problem**

*Is it possible to find clusters of similar books based on the presence of common words in the book descriptions?*

![[Screenshot_2023-03-31_at_6.11.45_PM.png]]

We want to get the micro-genre of the book from the back description of the book.

**Step 2: Build the dataset**

**Vectorization** is a process whereby words are converted into numbers.

To test the hypothesis, you gather book description text for 800 romance books published in the current year. You plan to use this text as your dataset.

![[Screenshot_2023-03-31_at_6.12.48_PM.png]]

Dataset (800 Romance books)

- Collected
- Explored
- Cleaned 
- Vectorized (transformed into numbers)

**Data cleaning and exploration**

For this project, you believe capitalization and verb tense will not matter, and therefore you remove capitals and convert all verbs to the same tense using a Python library built for processing human language. You also remove punctuation and words you don’t think have useful meaning, like *'a' *and *'the'*. The machine learning community refers to these words as *stop words*.

**Data preprocessing**

Before you can train the model, you need to do a type of data preprocessing called *data vectorization,* which is used to convert text into numbers.

As shown in the following image, you transform this book description text into what is called a *bag of words representation*, so that it is understandable by machine learning models.


**Step 3: Train the model**

You pick a common cluster-finding model called *k-means*. In this model, you can change a model parameter, *k*, to be equal to how many clusters the model will try to find in your dataset.Your data is unlabeled and you don't how many micro-genres might exist. So, you train your model multiple times using different values for *k* each time.What does this even mean? In the following graphs, you can see examples of when *k=2* and when *k=3*.

![[Untitled 8.png]]

Model: K-means (K → How many the clusters will find)

**Step 4: Evaluate the model**

In machine learning, numerous statistical metrics or methods are available to evaluate a model. In this use case, the *silhouette coefficient* is a good choice. This metric describes how well your data was clustered by the model. To find the optimal number of clusters, you plot the silhouette coefficient as shown in the following image below. You find the optimal value is when *k=19.*

![[Untitled 9.png]]

Often, machine learning practitioners do a manual evaluation of the model's findings.You find one cluster that contains a large collection of books that you can categorize as "paranormal teen romance." This trend is known in your industry, and therefore you feel somewhat confident in your machine learning approach. You don’t know if every cluster is going to be as cohesive as this, but you decide to use this model to see if you can find anything interesting about which to write an article.

Silhouette coefficient → How well your data was clustered

Manual inspection

** Step 5: Use the model**



In this example, you saw how you can use machine learning to help find micro-genres in books by using the text found on the back of the book. Here is summary of key moments from the lesson you just finished.

**One**

For some applications of machine learning, you need to not only clean and preprocess the data but also convert the data into a format that is machine readable. In this example, the words were converted into numbers through a process called data vectorization.

**Two**

Solving problems in machine learning requires iteration. In this example you saw how it was necessary to train the model multiples times for different values of k. After training your model over multiple iterations you saw how the silhouette coefficient could be use to determine the optimal value for **k**.

**Three**

During model inference you continued to inspect the clusters for accuracy to ensure that your model was generative useful predictions.

**Terminology**

- **Bag of words**: A technique used to extract features from text. It counts how many times a word appears in a document (corpus), and then transforms that information into a dataset.
- **Data vectorization**: A process that converts non-numeric data into a numerical format so that it can be used by a machine learning model.
- **Silhouette coefficients**: A score from -1 to 1 describing the clusters found during modeling. A score near zero indicates overlapping clusters, and scores less than zero indicate data points assigned to incorrect clusters. A score approaching 1 indicates successful identification of discrete non-overlapping clusters.
- **Stop words**: A list of words removed by natural language processing tools when building your dataset. There is no single universal list of stop words used by all-natural language processing tools.